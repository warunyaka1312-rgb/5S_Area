<?php
require_once __DIR__ . '/config.php';
$p = db();
$month = (int)($_GET['month'] ?? (int)date('n'));
$year = (int)($_GET['year'] ?? ((int)date('Y') + 543));
if ($month < 1 || $month > 12) $month = (int)date('n');
if ($year < 2500 || $year > 2700) $year = (int)date('Y') + 543;
$months = [1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$q = $p->prepare("SELECT id, auditor_name, department, inspection_date, inspection_time, area_5s, unit_count, sort_no, status, note FROM audit_plans WHERE month=? AND year=? AND team=? AND active=1 ORDER BY sort_no, id LIMIT 20");
$teams = [];
foreach (['A','B'] as $teamKey) {
    $q->execute([$month,$year,$teamKey]);
    $teams[$teamKey] = $q->fetchAll(PDO::FETCH_ASSOC);
}
$allDates = [];
foreach ($teams as $teamRows) {
    foreach ($teamRows as $r) {
        $raw = trim((string)($r['inspection_date'] ?? ''));
        if ($raw !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) $allDates[$raw] = true;
    }
}
$dates = array_keys($allDates);
sort($dates, SORT_STRING);
// Keep the sheet readable and ensure at least one sign-off date column if the plan has no dates.
if (!$dates) $dates = [''];
function signoff_h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function signoff_date($raw){
    if (!$raw || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $raw, $m)) return '';
    $y = (int)$m[1]; if ($y < 2400) $y += 543;
    return sprintf('%02d/%02d/%04d', (int)$m[3], (int)$m[2], $y);
}
function signoff_month_date($raw){ return signoff_date($raw); }
$totalNames = count($teams['A']) + count($teams['B']);
$maxRows = max(13, count($teams['A']), count($teams['B']));
$colCount = count($dates);
$nameWidth = $colCount >= 6 ? 20 : ($colCount >= 4 ? 24 : 30);
$dateWidth = max(7, (84 - $nameWidth) / $colCount);
?>
<!doctype html>
<html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>แบบลงชื่อ Auditor 5ส. - <?=signoff_h($months[$month].' '.$year)?></title>
<style>
*{box-sizing:border-box}body{margin:0;background:#edf1f6;color:#15213b;font-family:Tahoma,"Noto Sans Thai",Arial,sans-serif}.wrap{max-width:1450px;margin:16px auto;padding:0 12px}.toolbar{display:flex;gap:8px;flex-wrap:wrap;align-items:end;background:#fff;border:1px solid #d5deeb;border-radius:10px;padding:10px;margin-bottom:12px}.toolbar label{display:block;font-size:12px;font-weight:bold;margin-bottom:4px}.toolbar select,.btn{height:34px;border:1px solid #cbd5e1;border-radius:6px;padding:0 10px;background:#fff;font-weight:bold}.btn{cursor:pointer;background:#ff6500;border-color:#ff6500;color:#fff;text-decoration:none;display:inline-flex;align-items:center}.btn.green{background:#059669;border-color:#059669}.btn.navy{background:#172238;border-color:#172238}.sheet{background:#fff;border:1px solid #cbd5e1;border-radius:8px;padding:14px;box-shadow:0 5px 20px #0f172a10}.brand{display:grid;grid-template-columns:1fr 2fr 1fr;gap:10px;align-items:center;background:#ff6500;color:#fff;padding:9px 12px;border-radius:4px;margin-bottom:7px}.brand .logo{font-size:12px;font-weight:bold;line-height:1.5}.brand .title{text-align:center;font-size:21px;font-weight:900;line-height:1.3}.brand .period{text-align:right;font-weight:bold;font-size:13px}.brand .period strong{display:block;font-size:17px}.subline{font-size:10px;text-align:center;margin-top:2px}.summary{display:flex;justify-content:space-between;gap:8px;border:1px solid #d6deea;padding:5px 8px;margin-bottom:7px;font-size:10px}.team-title{background:#f4c542;color:#172238;border:1px solid #7d8796;font-weight:900;text-align:center;padding:7px;font-size:16px;display:flex;justify-content:space-between;align-items:center}.team-title span{flex:1}.team-title .team-label{font-size:17px}.sign-table{width:100%;border-collapse:collapse;table-layout:fixed;margin-bottom:8px}.sign-table th,.sign-table td{border:1.3px solid #526783;padding:4px 6px;font-size:12px;line-height:1.25;vertical-align:middle}.sign-table th{background:#f4c542;color:#172238;text-align:center;font-weight:bold;height:30px}.sign-table td{height:27px}.sign-table td.seq{text-align:center;width:4%;}.sign-table td.person{font-weight:600;overflow-wrap:anywhere;font-size:12px}.sign-table td.sign{text-align:center}.signline{display:block;height:21px;border-bottom:1.5px solid #334b70;margin:0 4px}.sign-table td.note{width:12%}.footer{display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin-top:2px}.footer section{border:1px solid #91a0b4;padding:5px 7px;min-height:42px;font-size:9px}.footer .line{border-bottom:1px solid #64748b;height:13px;margin:0 10px}.smallnote{font-size:8px;color:#526176;margin-top:5px}
@media print{@page{size:A4 landscape;margin:7mm}body{background:#fff}.wrap{max-width:none;margin:0;padding:0}.toolbar{display:none!important}.sheet{border:0;border-radius:0;box-shadow:none;padding:0}.brand{padding:6px 10px;margin-bottom:5px}.brand .title{font-size:18px}.brand .period{font-size:11px}.brand .period strong{font-size:14px}.summary{padding:4px 7px;margin-bottom:5px;font-size:10px}.team-title{padding:5px;font-size:13px}.team-title .team-label{font-size:14px}.sign-table{margin-bottom:0}.sign-table th,.sign-table td{font-size:10.5px;padding:3px 5px;line-height:1.2}.sign-table th{height:25px}.sign-table td{height:25px}.signline{height:19px;margin:0 3px}.footer{gap:6px;margin-top:2px}.footer section{min-height:42px;padding:5px 7px;font-size:9px}.footer .line{height:12px}.smallnote{font-size:8px;margin-top:4px}.team-block{break-after:page;page-break-after:always}.team-block:last-of-type{break-after:auto;page-break-after:auto}.team-block .team-title{margin-top:0}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style></head><body><div class="wrap">
<form class="toolbar" method="get">
 <div><label for="month">เดือน</label><select id="month" name="month"><?php foreach($months as $m=>$name):?><option value="<?=$m?>" <?=$month===$m?'selected':''?>><?=signoff_h($name)?></option><?php endforeach;?></select></div>
 <div><label for="year">ปี พ.ศ.</label><select id="year" name="year"><?php for($y=2568;$y<=2575;$y++):?><option value="<?=$y?>" <?=$year===$y?'selected':''?>><?=$y?></option><?php endfor;?></select></div>
 <button class="btn" type="submit">แสดงรายชื่อ</button><button class="btn green" type="button" onclick="window.print()">พิมพ์แบบลงชื่อ / Save PDF</button><a class="btn navy" href="schedule_manage.php?month=<?=$month?>&year=<?=$year?>">กลับหน้าแผนตรวจ</a>
</form>
<div class="sheet">
 <div class="brand"><div class="logo">5S SMART | ALUMET<br><span class="subline">CLEAN WORKPLACE • BRIGHT TOMORROW</span></div><div class="title">ใบลงชื่อ Auditor 5 ส. สำหรับการตรวจติดตามประจำเดือน<br><span style="font-size:11px">5S SMART | ALUMET</span></div><div class="period">เดือน / ปี<strong><?=signoff_h($months[$month].' '.$year)?></strong></div></div>
 <div class="summary"><span>จำนวนรายชื่อในแผน: <b><?=count($teams['A'])?> คน (ทีม A) / <?=count($teams['B'])?> คน (ทีม B)</b></span><span>กรุณาลงชื่อในวันที่เข้าตรวจจริง</span><span>วันที่ตามแผน: <?=count(array_filter($dates))?> วัน</span></div>
 <?php foreach(['A'=>'Auditor Team A','B'=>'Auditor Team B'] as $teamKey=>$teamTitle): ?>
 <div class="team-block">
 <div class="team-title"><span class="team-label"><?=signoff_h($teamTitle)?></span><span>ทีม <?=signoff_h($teamKey)?></span><span style="font-size:9px">เดือน <?=signoff_h($months[$month].' '.$year)?></span></div>
 <table class="sign-table"><colgroup><col style="width:3%"><col style="width:<?=$nameWidth?>%"><?php foreach($dates as $d):?><col style="width:<?=$dateWidth?>%"><?php endforeach;?><col style="width:13%"></colgroup>
 <thead><tr><th>ลำดับ</th><th>ชื่อผู้ตรวจ</th><?php foreach($dates as $d):?><th><?=signoff_h($d ? signoff_date($d) : 'วันที่ตรวจ')?></th><?php endforeach;?><th>หมายเหตุ</th></tr></thead><tbody>
 <?php for($i=0;$i<$maxRows;$i++): $r=$teams[$teamKey][$i]??null; ?><tr><td class="seq"><?=$i+1?></td><td class="person"><?=signoff_h($r['auditor_name']??'')?></td><?php foreach($dates as $d):?><td class="sign"><span class="signline"></span></td><?php endforeach;?><td class="note"></td></tr><?php endfor; ?>
 </tbody></table>
 <div class="footer"><section><b>ผู้รับรองการตรวจ / หัวหน้าทีม <?=signoff_h($teamKey)?></b><div class="line"></div>ลงชื่อ __________________________ วันที่ ____ / ____ / ______</section><section><b>วันที่ตรวจจริง (ทีม <?=signoff_h($teamKey)?>)</b><div class="line"></div>วันที่ ____ / ____ / ______ เวลา __________</section><section><b>หมายเหตุ / กรณีไม่ได้เข้าตรวจ</b><div class="line"></div><div class="line"></div></section></div>
 <div class="smallnote">รายชื่อดึงจากแผนตรวจ 5 ส. ของเดือนที่เลือกโดยตรง ไม่แก้ไขข้อมูลแผนหรือประวัติการตรวจ ช่องวันที่ในหัวตารางเรียงจากวันเก่าไปวันใหม่ และใช้สำหรับลงชื่อยืนยันการเข้าตรวจจริง</div>
 </div>
 <?php endforeach; ?>
</div></div></body></html>
