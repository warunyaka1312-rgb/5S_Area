<?php
require_once 'config.php';
$title='รายเดือน / รายปี';$p=db();
$months=['มกราคม'=>1,'กุมภาพันธ์'=>2,'มีนาคม'=>3,'เมษายน'=>4,'พฤษภาคม'=>5,'มิถุนายน'=>6,'กรกฎาคม'=>7,'สิงหาคม'=>8,'กันยายน'=>9,'ตุลาคม'=>10,'พฤศจิกายน'=>11,'ธันวาคม'=>12];
$month=$_GET['month']??'กันยายน';$year=(int)($_GET['year']??date('Y'));$view=$_GET['view']??'month';$dept=$_GET['department']??'Production';
if(!isset($months[$month]))$month='กันยายน';if(!in_array($dept,['Production','Office'],true))$dept='Production';
$monthNo=$months[$month];$scoreTable=$dept==='Office'?'office_scores':'scores';$critTable=$dept==='Office'?'office_criteria':'criteria';$target=target_pct($dept);
function period_data(PDO $p,string $dept,string $st,string $en,string $scoreTable,string $critTable):array{
 $q=$p->prepare("SELECT a.group_name,au.id audit_id,s.score1,s.score2,s.score3,c.max_score FROM audits au JOIN areas a ON a.id=au.area_id JOIN {$scoreTable} s ON s.audit_id=au.id JOIN {$critTable} c ON c.id=s.criterion_id WHERE au.department=? AND au.audit_date BETWEEN ? AND ?");
 $q->execute([$dept,$st,$en]);$g=[];
 foreach($q as $r){$v=score_avg($r['score1'],$r['score2'],$r['score3']);if($v===null)continue;$k=$r['audit_id'].'|'.$r['group_name'];if(!isset($g[$k]))$g[$k]=['group_name'=>$r['group_name'],'s'=>0,'m'=>0];$g[$k]['s']+=(float)$v;$g[$k]['m']+=(float)$r['max_score'];}
 $out=[];foreach($g as $r)$out[]=['group_name'=>$r['group_name'],'avg'=>$r['m']?round($r['s']/$r['m']*100,2):0,'n'=>1];$by=[];foreach($out as $r){$by[$r['group_name']][]=$r['avg'];}$final=[];foreach($by as $name=>$vals)$final[]=['group_name'=>$name,'avg'=>round(array_sum($vals)/count($vals),2),'n'=>count($vals)];usort($final,fn($a,$b)=>$b['avg']<=>$a['avg']);return $final;
}
$groups=[];$trend=[];$summary=['avg'=>0,'n'=>0];
if($view==='month'){
 $st=sprintf('%04d-%02d-01',$year,$monthNo);$en=date('Y-m-t',strtotime($st));$groups=period_data($p,$dept,$st,$en,$scoreTable,$critTable);
 $vals=array_column($groups,'avg');$summary['avg']=$vals?round(array_sum($vals)/count($vals),2):0;$summary['n']=count($groups);
}else{
 for($m=1;$m<=12;$m++){ $st=sprintf('%04d-%02d-01',$year,$m);$en=date('Y-m-t',strtotime($st));$g=period_data($p,$dept,$st,$en,$scoreTable,$critTable);$vals=array_column($g,'avg');$trend[]=['month'=>array_search($m,$months,true),'avg'=>$vals?round(array_sum($vals)/count($vals),2):null,'n'=>count($g)];}
 $all=array_values(array_filter(array_column($trend,'avg'),fn($v)=>$v!==null));$summary['avg']=$all?round(array_sum($all)/count($all),2):0;$summary['n']=count($all);
 $groups=period_data($p,$dept,sprintf('%04d-01-01',$year),sprintf('%04d-12-31',$year),$scoreTable,$critTable);
}
require 'includes/header.php';
?>
<div class="hero"><div class="hero-copy"><h1>รายงาน <span>รายเดือน / รายปี</span></h1><p>ดึงจากคะแนน Manual และ Import ที่บันทึกในฐานข้อมูลเดียวกัน</p></div><div class="hero-right"><strong><?=number_format($target,1)?>%</strong><small>เป้าหมายปัจจุบัน</small></div></div>
<div class="card p-5 mb-5 no-print"><form class="grid md:grid-cols-5 gap-3 items-end"><div><label class="text-xs font-bold">รูปแบบ</label><select name="view" class="w-full border rounded-xl p-3"><option value="month" <?=$view==='month'?'selected':''?>>รายเดือน</option><option value="year" <?=$view==='year'?'selected':''?>>รวมรายปี</option></select></div><div><label class="text-xs font-bold">ประเภท</label><select name="department" class="w-full border rounded-xl p-3"><option value="Production" <?=$dept==='Production'?'selected':''?>>Production</option><option value="Office" <?=$dept==='Office'?'selected':''?>>Office</option></select></div><div><label class="text-xs font-bold">เดือน</label><select name="month" class="w-full border rounded-xl p-3"><?php foreach($months as $m=>$n):?><option <?=$month===$m?'selected':''?>><?=h($m)?></option><?php endforeach;?></select></div><div><label class="text-xs font-bold">ปี</label><input type="number" name="year" value="<?=$year?>" class="w-full border rounded-xl p-3"></div><button class="bg-slate-900 text-white rounded-xl p-3 font-black">🔎 แสดงผล</button></form></div>
<div class="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-5"><div class="card p-5"><div class="text-xs text-slate-500">ประเภท</div><div class="text-2xl font-black"><?=h($dept)?></div></div><div class="card p-5"><div class="text-xs text-slate-500">ช่วงเวลา</div><div class="text-2xl font-black"><?=h($view==='month'?$month.' '.$year:'ปี '.$year)?></div></div><div class="card p-5"><div class="text-xs text-slate-500">คะแนนเฉลี่ย</div><div class="text-3xl font-black"><?=number_format($summary['avg'],2)?>%</div></div><div class="card p-5"><div class="text-xs text-slate-500">Target</div><div class="text-3xl font-black"><?=number_format($target,1)?>%</div></div></div>
<div class="card p-5 mb-5"><div class="section-title mb-3">📊 คะแนนเฉลี่ย <?=h($dept)?> — <?=h($view==='month'?$month.' '.$year:'ปี '.$year)?></div><div style="height:480px"><canvas id="mainChart"></canvas></div></div>
<?php if($view==='year'):?><div class="card p-5 mb-5"><div class="section-title mb-3">📈 แนวโน้มรายเดือน</div><div style="height:390px"><canvas id="trendChart"></canvas></div></div><?php endif;?>
<div class="card p-5"><div class="section-title mb-3">📋 ตารางข้อมูล</div><div class="overflow-x-auto"><table class="w-full border-collapse"><thead><tr class="bg-slate-100"><th class="p-3 border">อันดับ</th><th class="p-3 border text-left">กลุ่ม</th><th class="p-3 border">จำนวนครั้งตรวจ</th><th class="p-3 border">คะแนนเฉลี่ย</th><th class="p-3 border">สถานะ</th></tr></thead><tbody><?php foreach($groups as $i=>$g):?><tr><td class="p-3 border"><?=$i+1?></td><td class="p-3 border font-bold"><?=h($g['group_name'])?></td><td class="p-3 border text-center"><?=$g['n']?></td><td class="p-3 border text-center font-black"><?=number_format($g['avg'],2)?>%</td><td class="p-3 border text-center"><?=h(status_text((float)$g['avg'],$dept))?></td></tr><?php endforeach;?></tbody></table></div></div>
<script>
const groups=<?=json_encode($groups,JSON_UNESCAPED_UNICODE)?>,TARGET=<?=json_encode($target)?>,trend=<?=json_encode($trend??[],JSON_UNESCAPED_UNICODE)?>;
new Chart(document.getElementById('mainChart'),{type:'bar',data:{labels:groups.map(x=>x.group_name),datasets:[{label:'คะแนนเฉลี่ย %',data:groups.map(x=>Number(x.avg)),backgroundColor:'rgba(255,90,0,.8)',borderRadius:8},{label:'Target '+TARGET+'%',type:'line',data:groups.map(()=>TARGET),borderColor:'#ef4444',borderDash:[7,5],pointRadius:0}]},options:{responsive:true,maintainAspectRatio:false,scales:{y:{min:0,max:100,ticks:{callback:v=>v+'%'}}}}});
<?php if($view==='year'):?>new Chart(document.getElementById('trendChart'),{type:'line',data:{labels:trend.map(x=>x.month),datasets:[{label:'คะแนนเฉลี่ย %',data:trend.map(x=>x.avg),borderColor:'#ff5a00',backgroundColor:'rgba(255,90,0,.10)',fill:true,tension:.25,pointRadius:4},{label:'Target '+TARGET+'%',data:trend.map(()=>TARGET),borderColor:'#ef4444',borderDash:[7,5],pointRadius:0}]},options:{responsive:true,maintainAspectRatio:false,scales:{y:{min:0,max:100,ticks:{callback:v=>v+'%'}}}}});<?php endif;?>
</script>
<?php require 'includes/footer.php';?>
