<?php
/* TAG access control; additive and isolated from existing 5S scoring data. */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__.'/config.php';
function tag_auth_init(PDO $p): void {
 $p->exec("CREATE TABLE IF NOT EXISTS tag_users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','department','viewer')), department TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
}
function tag_user(): ?array { return $_SESSION['tag_user'] ?? null; }
function tag_require_login(): void { if (!tag_user()) { header('Location: tag_login.php'); exit; } }
function tag_is_admin(): bool { return (tag_user()['role'] ?? '') === 'admin'; }
function tag_can_edit(): bool { return in_array(tag_user()['role'] ?? '', ['admin','department'], true); }
function tag_department(): string { return trim((string)(tag_user()['department'] ?? '')); }
function tag_can_access_department(string $department): bool { return tag_is_admin() || ((tag_user()['role'] ?? '') === 'department' && tag_department() !== '' && hash_equals(tag_department(), trim($department))) || (($u=tag_user()) && $u['role']==='viewer' && ($u['department']==='' || hash_equals(tag_department(), trim($department)))); }
function tag_require_edit(): void { tag_require_login(); if (!tag_can_edit()) { http_response_code(403); exit('บัญชีนี้มีสิทธิ์ดูข้อมูลเท่านั้น'); } }
function tag_require_admin(): void { tag_require_login(); if (!tag_is_admin()) { http_response_code(403); exit('เฉพาะผู้ดูแลระบบเท่านั้น'); } }
function tag_require_row_department(PDO $p, int $id): void { if (tag_is_admin()) return; $q=$p->prepare('SELECT department FROM tags WHERE id=?'); $q->execute([$id]); $d=$q->fetchColumn(); if ($d===false || !tag_can_access_department((string)$d) || (tag_user()['role']??'')!=='department') { http_response_code(403); exit('ไม่มีสิทธิ์แก้ไขรายการของแผนกนี้'); } }
