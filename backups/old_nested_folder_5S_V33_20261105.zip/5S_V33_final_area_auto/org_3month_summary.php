<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'config.php';
$title = 'สรุปภาพรวมองค์กร / 3 เดือนล่าสุด';
$p = db();

$p->exec("CREATE TABLE IF NOT EXISTS excel_monthly (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_month TEXT NOT NULL,
    source_year INTEGER NOT NULL,
    department TEXT NOT NULL,
    group_name TEXT NOT NULL,
    unit_no TEXT NOT NULL,
    score REAL NOT NULL,
    target REAL NOT NULL,
    actual REAL NOT NULL,
    section TEXT NOT NULL DEFAULT '',
    auditor TEXT NOT NULL DEFAULT '',
    UNIQUE(source_month,source_year,department,group_name,unit_no)
)");
$p->exec("CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '')");
if (empty($_SESSION['org3_csrf'])) { $_SESSION['org3_csrf'] = bin2hex(random_bytes(24)); }
$csrf = $_SESSION['org3_csrf'];
$thaiMonths = [1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$thaiShort = [1=>'ม.ค.',2=>'ก.พ.',3=>'มี.ค.',4=>'เม.ย.',5=>'พ.ค.',6=>'มิ.ย.',7=>'ก.ค.',8=>'ส.ค.',9=>'ก.ย.',10=>'ต.ค.',11=>'พ.ย.',12=>'ธ.ค.'];
$engShort = [1=>'JAN',2=>'FEB',3=>'MAR',4=>'APR',5=>'MAY',6=>'JUN',7=>'JUL',8=>'AUG',9=>'SEP',10=>'OCT',11=>'NOV',12=>'DEC'];
$importMonths = [
    ['label'=>'กรกฎาคม','key'=>'jul','month_no'=>7],
    ['label'=>'สิงหาคม','key'=>'aug','month_no'=>8],
];
$importYear = 2569;
$flash = $_SESSION['org3_flash'] ?? null;
unset($_SESSION['org3_flash']);

/* Historical Excel import remains an explicit action. It only updates July/August 2569 snapshots. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import_history') {
    try {
        if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
            throw new RuntimeException('รหัสยืนยันหมดอายุ กรุณารีเฟรชหน้าแล้วลองใหม่');
        }
        $sourcePath = __DIR__ . '/data/history_comparison_3months_2569.json';
        if (!is_file($sourcePath)) { throw new RuntimeException('ไม่พบไฟล์ข้อมูลย้อนหลังที่แนบมากับโปรแกรม'); }
        $sourceRows = json_decode((string)file_get_contents($sourcePath), true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($sourceRows) || count($sourceRows) < 1) { throw new RuntimeException('ไฟล์ข้อมูลย้อนหลังไม่มีรายการข้อมูล'); }
        $areaRows = $p->query("SELECT id,department,group_name,unit_no FROM areas WHERE active=1 ORDER BY id")->fetchAll();
        $byUnit = [];
        foreach ($areaRows as $area) { $unitKey=trim((string)$area['unit_no']); $byUnit[$unitKey] ??=[]; $byUnit[$unitKey][]=$area; }
        $mapped=[]; $unmapped=[];
        foreach ($sourceRows as $sourceRow) {
            $unit=trim((string)($sourceRow['unit']??'')); $candidates=$byUnit[$unit]??[];
            if (count($candidates)!==1) {
                $unmapped[]=['group'=>(string)($sourceRow['group']??''),'unit'=>$unit,'reason'=>count($candidates)===0?'ไม่มีหน่วยที่เปิดใช้งานใน Master':'เลขหน่วยซ้ำใน Master'];
                continue;
            }
            $area=$candidates[0];
            $canonicalGroup=function_exists('display_area_group')?display_area_group($area['group_name']):trim((string)$area['group_name']);
            $mapped[]=['department'=>(string)$area['department'],'group_name'=>$canonicalGroup,'unit_no'=>trim((string)$area['unit_no']),'target'=>(float)($sourceRow['target']??($area['department']==='Office'?87:85)),'scores'=>['กรกฎาคม'=>(float)($sourceRow['jul']??0),'สิงหาคม'=>(float)($sourceRow['aug']??0)]];
        }
        if (!$mapped) { throw new RuntimeException('จับคู่ข้อมูลย้อนหลังกับ Master ไม่ได้ จึงยังไม่เปลี่ยนฐานข้อมูล'); }
        $monthNames=array_column($importMonths,'label'); $in=implode(',',array_fill(0,count($monthNames),'?'));
        $backupQuery=$p->prepare("SELECT * FROM excel_monthly WHERE source_year=? AND source_month IN ($in) ORDER BY department,group_name,unit_no");
        $backupQuery->execute(array_merge([$importYear],$monthNames)); $oldRows=$backupQuery->fetchAll();
        $backupDir=__DIR__.'/backups';
        if (!is_dir($backupDir)&&!@mkdir($backupDir,0775,true)&&!is_dir($backupDir)) throw new RuntimeException('สร้างโฟลเดอร์ backups ไม่ได้');
        $backupFile=$backupDir.'/before_3month_import_'.date('Ymd_His').'.json';
        $backupPayload=['created_at'=>date('c'),'source'=>'เทียบ3เดือน.xlsx','scope'=>'excel_monthly เฉพาะ กรกฎาคม-สิงหาคม 2569','rows'=>$oldRows];
        if (@file_put_contents($backupFile,json_encode($backupPayload,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT))===false) throw new RuntimeException('สำรองข้อมูลย้อนหลังเดิมไม่ได้ จึงยกเลิกการนำเข้า');
        $p->beginTransaction();
        $delete=$p->prepare("DELETE FROM excel_monthly WHERE source_year=? AND source_month IN ($in)");
        $delete->execute(array_merge([$importYear],$monthNames));
        $insert=$p->prepare("INSERT INTO excel_monthly(source_month,source_year,department,group_name,unit_no,score,target,actual,section,auditor) VALUES(?,?,?,?,?,?,?,?,?,?)");
        foreach ($importMonths as $month) foreach ($mapped as $item) {
            $score=$item['scores'][$month['label']];
            $insert->execute([$month['label'],$importYear,$item['department'],$item['group_name'],$item['unit_no'],$score,$item['target'],$score,$item['department'],'']);
        }
        $verify=$p->prepare("SELECT COUNT(*) FROM excel_monthly WHERE source_year=? AND source_month=?");
        foreach ($importMonths as $month) { $verify->execute([$importYear,$month['label']]); if((int)$verify->fetchColumn()!==count($mapped)) throw new RuntimeException('ตรวจสอบจำนวนข้อมูลเดือน'.$month['label'].'ไม่ผ่าน'); }
        $p->commit();
        $_SESSION['org3_flash']=['type'=>'success','message'=>'นำเข้าข้อมูลย้อนหลัง ก.ค.–ส.ค. 2569 เรียบร้อย: '.count($mapped).' หน่วย × 2 เดือน','backup'=>basename($backupFile),'unmapped'=>$unmapped];
    } catch(Throwable $e) {
        if($p->inTransaction()) $p->rollBack();
        $_SESSION['org3_flash']=['type'=>'error','message'=>'นำเข้าข้อมูลไม่สำเร็จ: '.$e->getMessage()];
    }
    header('Location: org_3month_summary.php'); exit;
}

/* Detect every month that has actual scored audits or imported historical data. */
$livePeriods=[];
$livePeriodSql="SELECT DISTINCT substr(au.audit_date,1,7) AS ym
 FROM audits au JOIN areas a ON a.id=au.area_id
 WHERE a.department IN ('Production','Office') AND length(au.audit_date)>=7
 AND ((a.department='Production' AND EXISTS(SELECT 1 FROM scores s WHERE s.audit_id=au.id AND (s.score1 IS NOT NULL OR s.score2 IS NOT NULL OR s.score3 IS NOT NULL)))
   OR (a.department='Office' AND EXISTS(SELECT 1 FROM office_scores os WHERE os.audit_id=au.id AND (os.score1 IS NOT NULL OR os.score2 IS NOT NULL OR os.score3 IS NOT NULL))) )";
foreach ($p->query($livePeriodSql)->fetchAll(PDO::FETCH_COLUMN) as $ym) if (preg_match('/^\d{4}-\d{2}$/',(string)$ym)) $livePeriods[(string)$ym]=true;
$excelPeriods=[];
$monthNameToNo=array_flip($thaiMonths);
$monthNameToNo['Jan']=1;$monthNameToNo['January']=1;$monthNameToNo['Feb']=2;$monthNameToNo['February']=2;$monthNameToNo['Mar']=3;$monthNameToNo['March']=3;$monthNameToNo['Apr']=4;$monthNameToNo['April']=4;$monthNameToNo['May']=5;$monthNameToNo['Jun']=6;$monthNameToNo['June']=6;$monthNameToNo['Jul']=7;$monthNameToNo['July']=7;$monthNameToNo['Aug']=8;$monthNameToNo['August']=8;$monthNameToNo['Sep']=9;$monthNameToNo['September']=9;$monthNameToNo['Oct']=10;$monthNameToNo['October']=10;$monthNameToNo['Nov']=11;$monthNameToNo['November']=11;$monthNameToNo['Dec']=12;$monthNameToNo['December']=12;
foreach ($p->query("SELECT DISTINCT source_year,source_month FROM excel_monthly")->fetchAll() as $er) {
    $m=(int)($monthNameToNo[(string)$er['source_month']]??(is_numeric($er['source_month'])?(int)$er['source_month']:0));
    $y=(int)$er['source_year']; if($y>=2400) $y-=543;
    if($m>=1&&$m<=12&&$y>=2000) $excelPeriods[sprintf('%04d-%02d',$y,$m)]=true;
}
$availablePeriods=array_unique(array_merge(array_keys($livePeriods),array_keys($excelPeriods)));
sort($availablePeriods,SORT_STRING);
$latestPeriod=$availablePeriods?end($availablePeriods):date('Y-m');
$latestDate=DateTimeImmutable::createFromFormat('!Y-m-d',$latestPeriod.'-01') ?: new DateTimeImmutable('first day of this month');
$periodList=[];
$firstDate=$latestDate->modify('-2 months');
for($i=0;$i<3;$i++) {
    $d=$firstDate->modify('+'.$i.' months'); $ym=$d->format('Y-m'); $monthNo=(int)$d->format('n'); $yearDb=(int)$d->format('Y');
    $source=isset($livePeriods[$ym])?'live':(isset($excelPeriods[$ym])?'excel':'none');
    $periodList[]=['period'=>$ym,'label'=>$thaiMonths[$monthNo],'short'=>$thaiShort[$monthNo],'key'=>'m'.$d->format('Ym'),'month_no'=>$monthNo,'year_db'=>$yearDb,'year_thai'=>$yearDb+543,'tag'=>$engShort[$monthNo].' '.$yearDb,'source'=>$source,'sourceLabel'=>$source==='live'?'คะแนนจริงจากระบบ':($source==='excel'?'ข้อมูลย้อนหลังจาก Excel':'ยังไม่มีข้อมูล')];
}
$months=$periodList;
$monthByPeriod=[]; foreach($months as $m) $monthByPeriod[$m['period']]=$m;
$rangeTitle=$months[0]['short'].'–'.$months[2]['short'].' '.$months[2]['year_thai'];
$rangeLong=$months[0]['label'].' '.$months[0]['year_thai'].' – '.$months[2]['label'].' '.$months[2]['year_thai'];

/* Active master is the reference list for coverage; previously audited inactive units are retained in the historical rows. */
$masterAreaRows=$p->query("SELECT id,department,group_name,unit_no,area_name FROM areas WHERE active=1 AND department IN ('Production','Office') ORDER BY department,group_name,CAST(unit_no AS INTEGER),unit_no")->fetchAll();
$activeByDept=['Production'=>0,'Office'=>0]; $activeKeys=[]; $masterByDeptUnit=[]; $comparisonItems=[];
foreach($masterAreaRows as $a) {
    $dep=(string)$a['department']; if(!isset($activeByDept[$dep])) continue;
    $activeByDept[$dep]++;
    $g=function_exists('display_area_group')?display_area_group($a['group_name']):trim((string)$a['group_name']); $g=trim((string)$g); $unit=trim((string)$a['unit_no']);
    $key=$dep.'|'.$g.'|'.$unit; $activeKeys[$key]=true;
    $masterByDeptUnit[$dep.'|'.$unit]??=[]; $masterByDeptUnit[$dep.'|'.$unit][]=$a;
    if(!isset($comparisonItems[$key])) $comparisonItems[$key]=['department'=>$dep,'group_name'=>$g,'unit_no'=>$unit,'scores'=>[],'targets'=>[],'sources'=>[],'auditDates'=>[],'inActiveMaster'=>true];
}
$activeTotal=array_sum($activeByDept);

/* Load only selected-period Excel snapshots when the live audit system has no data for that period. */
$excelRows=$p->query("SELECT department,group_name,unit_no,score,target,source_month,source_year FROM excel_monthly ORDER BY source_year,source_month")->fetchAll();
$monthRowCount=[];
foreach($excelRows as $r) {
    $m=(int)($monthNameToNo[(string)$r['source_month']]??(is_numeric($r['source_month'])?(int)$r['source_month']:0)); $y=(int)$r['source_year']; if($y>=2400)$y-=543;
    if($m<1||$m>12||$y<2000) continue; $period=sprintf('%04d-%02d',$y,$m);
    if(!isset($monthByPeriod[$period]) || $monthByPeriod[$period]['source']!=='excel') continue;
    $dep=(string)$r['department']; if(!in_array($dep,['Production','Office'],true)) continue;
    $unit=trim((string)$r['unit_no']); $matches=$masterByDeptUnit[$dep.'|'.$unit]??[];
    if(count($matches)===1) $group=function_exists('display_area_group')?display_area_group($matches[0]['group_name']):trim((string)$matches[0]['group_name']);
    else $group=function_exists('display_area_group')?display_area_group($r['group_name']):trim((string)$r['group_name']);
    $group=trim((string)$group); $key=$dep.'|'.$group.'|'.$unit;
    if(!isset($comparisonItems[$key])) $comparisonItems[$key]=['department'=>$dep,'group_name'=>$group,'unit_no'=>$unit,'scores'=>[],'targets'=>[],'sources'=>[],'auditDates'=>[],'inActiveMaster'=>isset($activeKeys[$key])];
    $label=$monthByPeriod[$period]['label']; $comparisonItems[$key]['scores'][$label]=(float)$r['score']; $comparisonItems[$key]['targets'][$label]=(float)$r['target']; $comparisonItems[$key]['sources'][$label]='Excel';
    $monthRowCount[$period]=($monthRowCount[$period]??0)+1;
}

/* For live periods, use the latest scored audit for each unit and keep the exact audit date. */
foreach($months as $month) {
    if($month['source']!=='live') continue;
    $start=$month['period'].'-01'; $end=date('Y-m-t',strtotime($start));
    $q=$p->prepare("SELECT au.id AS audit_id,au.area_id,au.audit_date,a.department,a.group_name,a.unit_no,a.area_name
        FROM audits au JOIN areas a ON a.id=au.area_id
        WHERE a.department IN ('Production','Office') AND au.audit_date BETWEEN ? AND ?
          AND ((a.department='Production' AND EXISTS(SELECT 1 FROM scores s WHERE s.audit_id=au.id AND (s.score1 IS NOT NULL OR s.score2 IS NOT NULL OR s.score3 IS NOT NULL)))
            OR (a.department='Office' AND EXISTS(SELECT 1 FROM office_scores os WHERE os.audit_id=au.id AND (os.score1 IS NOT NULL OR os.score2 IS NOT NULL OR os.score3 IS NOT NULL))))
        ORDER BY a.id,au.audit_date DESC,au.id DESC");
    $q->execute([$start,$end]); $latestByArea=[];
    foreach($q->fetchAll() as $ar) { $aid=(int)$ar['area_id']; if(!isset($latestByArea[$aid])) $latestByArea[$aid]=$ar; }
    foreach($latestByArea as $ar) {
        $dep=(string)$ar['department']; $group=function_exists('display_area_group')?display_area_group($ar['group_name']):trim((string)$ar['group_name']); $group=trim((string)$group); $unit=trim((string)$ar['unit_no']); $key=$dep.'|'.$group.'|'.$unit;
        $sum=$dep==='Office'?office_audit_summary($p,(int)$ar['audit_id']):production_audit_summary($p,(int)$ar['audit_id']);
        if((float)($sum['max']??0)<=0) continue;
        $matches=$masterByDeptUnit[$dep.'|'.$unit]??[]; $inMaster=count($matches)===1 && isset($activeKeys[$key]);
        if(!isset($comparisonItems[$key])) $comparisonItems[$key]=['department'=>$dep,'group_name'=>$group,'unit_no'=>$unit,'scores'=>[],'targets'=>[],'sources'=>[],'auditDates'=>[],'inActiveMaster'=>$inMaster];
        $comparisonItems[$key]['scores'][$month['label']]=round((float)$sum['pct'],2);
        $comparisonItems[$key]['targets'][$month['label']]=target_pct($dep);
        $comparisonItems[$key]['sources'][$month['label']]='ระบบจริง';
        $comparisonItems[$key]['auditDates'][$month['label']]=(string)$ar['audit_date'];
        $comparisonItems[$key]['inActiveMaster']=$inMaster;
    }
}

/* Monthly organization/department aggregates are recalculated from the selected three periods. */
$monthStats=[];
foreach($months as $month) {
    $label=$month['label']; $vals=['all'=>[],'Production'=>[],'Office'=>[]]; $pass=['all'=>0,'Production'=>0,'Office'=>0]; $below=['all'=>0,'Production'=>0,'Office'=>0]; $seen=['all'=>0,'Production'=>0,'Office'=>0];
    foreach($comparisonItems as $item) {
        if(!array_key_exists($label,$item['scores'])) continue;
        $score=(float)$item['scores'][$label]; $target=(float)($item['targets'][$label]??($item['department']==='Office'?87:85)); $dep=$item['department'];
        $vals['all'][]=$score; $seen['all']++; if($score>=$target)$pass['all']++;else$below['all']++;
        if(isset($vals[$dep])) { $vals[$dep][]=$score; $seen[$dep]++; if($score>=$target)$pass[$dep]++;else$below[$dep]++; }
    }
    $avg=fn($a)=>count($a)?round(array_sum($a)/count($a),2):null;
    $monthStats[$label]=['allAvg'=>$avg($vals['all']),'prodAvg'=>$avg($vals['Production']),'officeAvg'=>$avg($vals['Office']),'allN'=>$seen['all'],'prodN'=>$seen['Production'],'officeN'=>$seen['Office'],'allPass'=>$pass['all'],'allBelow'=>$below['all'],'prodPass'=>$pass['Production'],'prodBelow'=>$below['Production'],'officePass'=>$pass['Office'],'officeBelow'=>$below['Office'],'source'=>$month['source']];
}
$firstLabel=$months[0]['label']; $latestMonth=$months[2]; $latestLabel=$latestMonth['label']; $latestStats=$monthStats[$latestLabel];
$overallChange=($monthStats[$firstLabel]['allAvg']!==null&&$latestStats['allAvg']!==null)?round($latestStats['allAvg']-$monthStats[$firstLabel]['allAvg'],2):null;
$liveStats=[];
foreach(['all','Production','Office'] as $dep) {
    $avgKey=$dep==='all'?'allAvg':($dep==='Production'?'prodAvg':'officeAvg'); $nKey=$dep==='all'?'allN':($dep==='Production'?'prodN':'officeN'); $passKey=$dep==='all'?'allPass':($dep==='Production'?'prodPass':'officePass'); $belowKey=$dep==='all'?'allBelow':($dep==='Production'?'prodBelow':'officeBelow');
    $master=$dep==='all'?$activeTotal:($activeByDept[$dep]??0); $scored=(int)$latestStats[$nKey];
    $liveStats[$dep]=['avg'=>$latestStats[$avgKey],'n'=>$scored,'master'=>$master,'missing'=>max(0,$master-$scored),'pass'=>(int)$latestStats[$passKey],'below'=>(int)$latestStats[$belowKey]];
}
$orgLatest=$liveStats['all']['avg']; $liveMonthLabel=$latestLabel; $liveMonthTag=$latestLabel.' ('.$latestMonth['year_thai'].')'; $liveYearThai=$latestMonth['year_thai'];

/* Build group-level and unit-level comparisons dynamically for the selected periods. */
$groupSummary=[]; $unitRows=array_values($comparisonItems);
foreach($comparisonItems as $item) {
    $key=$item['department'].'|'.$item['group_name'];
    if(!isset($groupSummary[$key])) $groupSummary[$key]=['department'=>$item['department'],'group_name'=>$item['group_name'],'units'=>[],'scores'=>[],'targets'=>[],'passLatest'=>0,'belowLatest'=>0,'missingLatest'=>0,'latestScores'=>[]];
    $groupSummary[$key]['units'][]=$item['unit_no'];
    foreach($months as $month) { $label=$month['label']; if(isset($item['scores'][$label])) { $groupSummary[$key]['scores'][$label][]=(float)$item['scores'][$label]; $groupSummary[$key]['targets'][$label][]=(float)($item['targets'][$label]??($item['department']==='Office'?87:85)); } }
    if(($item['inActiveMaster']??false)) {
        if(isset($item['scores'][$latestLabel])) { $sc=(float)$item['scores'][$latestLabel]; $tg=(float)($item['targets'][$latestLabel]??($item['department']==='Office'?87:85)); $groupSummary[$key]['latestScores'][]=$sc; if($sc>=$tg)$groupSummary[$key]['passLatest']++;else$groupSummary[$key]['belowLatest']++; }
        else $groupSummary[$key]['missingLatest']++;
    }
}
foreach($groupSummary as &$g) {
    $unique=array_values(array_unique(array_filter(array_map('strval',$g['units']),fn($x)=>trim($x)!=='')));
    usort($unique,fn($a,$b)=>(is_numeric($a)&&is_numeric($b)?(int)$a<=>(int)$b:strnatcasecmp($a,$b)));
    $g['unitCount']=count($unique); $g['unitList']=$unique?implode(', ',$unique):'—';
    foreach($months as $month) { $vals=$g['scores'][$month['label']]??[]; $g['avg_'.$month['key']]=count($vals)?round(array_sum($vals)/count($vals),2):null; }
    $g['avg_latest']=count($g['latestScores'])?round(array_sum($g['latestScores'])/count($g['latestScores']),2):null;
    $g['change']=($g['avg_'.$months[0]['key']]!==null&&$g['avg_latest']!==null)?round($g['avg_latest']-$g['avg_'.$months[0]['key']],2):null;
    unset($g['units'],$g['scores'],$g['targets'],$g['latestScores']);
}
unset($g);
$deptOrder=['Production'=>0,'Office'=>1];
usort($groupSummary,function($a,$b)use($deptOrder){$d=($deptOrder[$a['department']]??9)<=>($deptOrder[$b['department']]??9);return $d!==0?$d:strcasecmp($a['group_name'],$b['group_name']);});
usort($unitRows,function($a,$b)use($deptOrder){$d=($deptOrder[$a['department']]??9)<=>($deptOrder[$b['department']]??9);if($d!==0)return $d;$g=strcmp($a['group_name'],$b['group_name']);return $g!==0?$g:(int)$a['unit_no']<=>(int)$b['unit_no'];});
$chartLabels=array_map(fn($m)=>$m['short'].' '.$m['year_thai'],$months);
$chartOverall=array_map(fn($m)=>$monthStats[$m['label']]['allAvg'],$months);
$chartProd=array_map(fn($m)=>$monthStats[$m['label']]['prodAvg'],$months);
$chartOffice=array_map(fn($m)=>$monthStats[$m['label']]['officeAvg'],$months);
$chartPass=array_map(fn($m)=>$monthStats[$m['label']]['allPass'],$months);
$chartBelow=array_map(fn($m)=>$monthStats[$m['label']]['allBelow'],$months);
$monthSourceSummary=implode(' • ',array_map(fn($m)=>$m['short'].' '.$m['year_thai'].': '.$m['sourceLabel'],$months));
$hasData=false; foreach($monthStats as $st) if($st['allN']>0) {$hasData=true;break;}
$flash=$flash;
if(isset($_GET['board'])) { $boardMode=(string)$_GET['board']; if(!in_array($boardMode,['organization','Production','Office'],true))$boardMode='organization'; require __DIR__.'/org_3month_board_template.php'; exit; }
require 'includes/header.php';
?>
<style>
.org3{max-width:1700px;margin:0 auto;padding:16px}.org3-panel{background:#fff;border:1px solid #dbe4ef;border-radius:15px;padding:18px;box-shadow:0 5px 17px rgba(15,23,42,.05);margin-bottom:16px}.org3-toolbar{display:flex;gap:12px;flex-wrap:wrap;align-items:center;justify-content:space-between}.org3-title{font-size:24px;font-weight:950;color:#172238}.org3-sub{font-size:13px;color:#64748b;margin-top:5px}.org3-btn{display:inline-flex;align-items:center;gap:7px;background:#1769e8;color:#fff;border:0;border-radius:9px;padding:10px 14px;font-weight:900;cursor:pointer;text-decoration:none}.org3-btn.orange{background:#ff5a00}.org3-note{background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;padding:12px;border-radius:10px;font-size:13px}.org3-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin:14px 0}.org3-kpi{border:1px solid #dce5f0;background:#fff;border-radius:13px;padding:13px}.org3-kpi .label{font-size:12px;font-weight:800;color:#64748b}.org3-kpi .value{font-size:25px;font-weight:950;color:#173b70;margin-top:4px}.org3-grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}.org3-chart{position:relative;height:340px}.org3-section{font-size:19px;font-weight:950;color:#172238;margin-bottom:12px}.org3-table{border-collapse:collapse;width:100%;font-size:13px}.org3-table th{background:#172238;color:#fff;padding:10px 8px;text-align:left;white-space:nowrap}.org3-table td{padding:9px 8px;border-bottom:1px solid #e2e8f0;vertical-align:top}.org3-table .num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.org3-table .unit-list{min-width:130px;max-width:320px;white-space:normal;line-height:1.65}.org3-table tr.dept-break td{border-top:4px solid #ff5a00;background:#fff1e8!important;font-weight:950}.org3-table tr.dept-break.office td{border-top-color:#2563eb;background:#eff6ff!important}.org3-message{padding:12px 14px;border-radius:10px;margin-bottom:12px;font-weight:700}.org3-success{background:#dcfce7;color:#166534}.org3-error{background:#fee2e2;color:#991b1b}.source-chip{display:inline-block;padding:5px 9px;border-radius:20px;background:#f1f5f9;color:#475569;font-size:11px;font-weight:800;margin:3px}.org3-table tr:nth-child(even) td{background:#f8fafc}@media(max-width:1100px){.org3-kpis{grid-template-columns:repeat(3,1fr)}.org3-grid2{grid-template-columns:1fr}}@media(max-width:640px){.org3-kpis{grid-template-columns:repeat(2,1fr)}.org3-kpi .value{font-size:20px}.org3{padding:8px}.org3-table{font-size:11px}}@media print{.no-print{display:none!important}.org3{max-width:none;padding:0}.org3-panel{box-shadow:none;break-inside:avoid}.org3-grid2{grid-template-columns:1fr 1fr}}
</style>
<div class="org3">
 <section class="org3-panel">
  <div class="org3-toolbar"><div><div class="org3-title">📊 สรุปภาพรวมองค์กร 5 ส. — 3 เดือนล่าสุด: <?=h($rangeTitle)?></div><div class="org3-sub">ระบบเลือก 3 เดือนล่าสุดที่มีข้อมูลจริงให้อัตโนมัติ • <?=h($rangeLong)?></div></div>
   <div class="flex gap-2 flex-wrap no-print"><a class="org3-btn orange" href="org_3month_summary.php?board=organization">📌 รายงานติดบอร์ด / ส่ง LINE</a><button class="org3-btn" onclick="window.print()">🖨 พิมพ์ / PDF</button></div></div>
  <div class="mt-2"><?php foreach($months as $m): ?><span class="source-chip"><?=h($m['short'].' '.$m['year_thai'])?> • <?=h($m['sourceLabel'])?></span><?php endforeach; ?></div>
 </section>
 <?php if($flash): ?><div class="org3-message <?=$flash['type']==='success'?'org3-success':'org3-error'?>"><?=h($flash['message'])?><?php if(!empty($flash['backup'])): ?><div class="text-xs mt-1">สำรองข้อมูลเดิมไว้ที่ backups/<?=h($flash['backup'])?></div><?php endif; ?></div><?php endif; ?>
 <section class="org3-panel no-print"><div class="org3-toolbar"><div><b class="text-lg">นำเข้าข้อมูลย้อนหลังจาก Excel</b><div class="org3-sub">ใช้สำหรับเดือนย้อนหลังที่ยังไม่มีใบตรวจในระบบเท่านั้น • การนำเข้าจะสำรองข้อมูลเดิมก่อนเสมอ</div></div><form method="post" onsubmit="return confirm('ระบบจะสำรองข้อมูลเดิมก่อน แล้วแทนที่ข้อมูลย้อนหลังเดือนกรกฎาคม–สิงหาคม 2569 ในตาราง Excel เท่านั้น ดำเนินการหรือไม่?')"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="import_history"><button class="org3-btn orange">📥 นำเข้าข้อมูลย้อนหลัง ก.ค.–ส.ค. 2569</button></form></div></section>
 <div class="org3-kpis">
  <div class="org3-kpi"><div class="label">หน่วยใน Master ปัจจุบัน</div><div class="value"><?=number_format($activeTotal)?></div><div class="text-xs text-slate-500">Production <?=number_format($activeByDept['Production'])?> • Office <?=number_format($activeByDept['Office'])?></div></div>
  <div class="org3-kpi"><div class="label">คะแนนเฉลี่ยองค์กร • <?=h($latestMonth['short'].' '.$latestMonth['year_thai'])?></div><div class="value"><?=$liveStats['all']['avg']===null?'—':number_format($liveStats['all']['avg'],2).'%'?></div><div class="text-xs text-slate-500">มีคะแนน <?=number_format($liveStats['all']['n'])?> หน่วย</div></div>
  <div class="org3-kpi"><div class="label">เปลี่ยนจาก <?=h($months[0]['short'])?> → <?=h($months[2]['short'])?></div><div class="value" style="color:<?=($overallChange??0)<0?'#b91c1c':'#15803d'?>"><?=$overallChange===null?'—':(($overallChange>0?'+':'').number_format($overallChange,2).' จุด')?></div><div class="text-xs text-slate-500">เปรียบเทียบเดือนแรกกับเดือนล่าสุด</div></div>
  <div class="org3-kpi"><div class="label">Production • <?=h($latestMonth['short'].' '.$latestMonth['year_thai'])?></div><div class="value"><?=$liveStats['Production']['avg']===null?'—':number_format($liveStats['Production']['avg'],2).'%'?></div><div class="text-xs text-slate-500">มีคะแนน <?=number_format($liveStats['Production']['n'])?> / <?=number_format($activeByDept['Production'])?> หน่วย</div></div>
  <div class="org3-kpi"><div class="label">Office • <?=h($latestMonth['short'].' '.$latestMonth['year_thai'])?></div><div class="value"><?=$liveStats['Office']['avg']===null?'—':number_format($liveStats['Office']['avg'],2).'%'?></div><div class="text-xs text-slate-500">มีคะแนน <?=number_format($liveStats['Office']['n'])?> / <?=number_format($activeByDept['Office'])?> หน่วย</div></div>
 </div>
 <div class="org3-grid2"><section class="org3-panel"><div class="org3-section">แนวโน้มคะแนนเฉลี่ย 3 เดือนล่าสุด</div><div class="org3-chart"><canvas id="org3Trend"></canvas></div></section><section class="org3-panel"><div class="org3-section">จำนวนหน่วยผ่าน / ต่ำกว่าเป้าหมาย</div><div class="org3-chart"><canvas id="org3Pass"></canvas></div></section></div>
 <section class="org3-panel"><div class="org3-section">สรุปคะแนนองค์กรรายเดือน</div><div class="overflow-x-auto"><table class="org3-table"><thead><tr><th>ประเภท</th><?php foreach($months as $m): ?><th class="num"><?=h($m['short'].' '.$m['year_thai'])?><br><small><?=h($m['sourceLabel'])?></small></th><?php endforeach; ?><th class="num">เปลี่ยนแปลง<br>เดือนแรก→ล่าสุด</th><th class="num">ผ่านเป้าล่าสุด</th><th class="num">ต่ำกว่าเป้า</th><th class="num">มีคะแนน</th></tr></thead><tbody>
 <?php foreach(['Production','Office'] as $dep): $field=$dep==='Production'?'prodAvg':'officeAvg'; $change=null; $f=$monthStats[$months[0]['label']][$field]; $l=$monthStats[$months[2]['label']][$field]; if($f!==null&&$l!==null)$change=round($l-$f,2); $passKey=$dep==='Production'?'prodPass':'officePass';$belowKey=$dep==='Production'?'prodBelow':'officeBelow';$nKey=$dep==='Production'?'prodN':'officeN'; ?>
 <tr class="dept-break <?=$dep==='Office'?'office':''?>"><td><b><?=$dep==='Production'?'🏭':'🏢'?> <?=h($dep)?></b></td><?php foreach($months as $m): $v=$monthStats[$m['label']][$field]; ?><td class="num"><?=$v===null?'—':number_format($v,2).'%'?></td><?php endforeach; ?><td class="num"><?=$change===null?'—':(($change>0?'+':'').number_format($change,2).' จุด')?></td><td class="num"><?=number_format($latestStats[$passKey])?></td><td class="num"><?=number_format($latestStats[$belowKey])?></td><td class="num"><?=number_format($latestStats[$nKey])?> / <?=number_format($activeByDept[$dep])?></td></tr>
 <?php endforeach; ?>
 <tr><td><b>🌐 รวมองค์กร</b></td><?php foreach($months as $m): $v=$monthStats[$m['label']]['allAvg']; ?><td class="num"><?=$v===null?'—':number_format($v,2).'%'?></td><?php endforeach; ?><td class="num"><?=$overallChange===null?'—':(($overallChange>0?'+':'').number_format($overallChange,2).' จุด')?></td><td class="num"><?=number_format($latestStats['allPass'])?></td><td class="num"><?=number_format($latestStats['allBelow'])?></td><td class="num"><?=number_format($latestStats['allN'])?> / <?=number_format($activeTotal)?></td></tr>
 </tbody></table></div></section>
 <section class="org3-panel"><div class="org3-section">เปรียบเทียบคะแนนรายกลุ่มและหน่วย</div><div class="overflow-x-auto"><table class="org3-table"><thead><tr><th>แผนก</th><th>กลุ่ม</th><th>หน่วยในกลุ่ม</th><th class="num">จำนวน</th><?php foreach($months as $m): ?><th class="num"><?=h($m['short'].' '.$m['year_thai'])?></th><?php endforeach; ?><th class="num">เปลี่ยนแปลง</th><th class="num">ผ่านเป้าล่าสุด</th></tr></thead><tbody>
 <?php $lastDept=null; foreach($groupSummary as $g): if($lastDept!==$g['department']):$lastDept=$g['department']; ?><tr class="dept-break <?=$lastDept==='Office'?'office':''?>"><td colspan="<?=8+count($months)?>"><?=$lastDept==='Production'?'🏭 Production':'🏢 Office'?> — แยกกลุ่มและหน่วย</td></tr><?php endif; ?>
 <tr><td><?=h($g['department'])?></td><td><b><?=h($g['group_name'])?></b></td><td class="unit-list"><?=h($g['unitList'])?></td><td class="num"><?=number_format($g['unitCount'])?></td><?php foreach($months as $m): $v=$g['avg_'.$m['key']]; ?><td class="num"><?=$v===null?'—':number_format($v,2).'%'?></td><?php endforeach; ?><td class="num"><?=$g['change']===null?'—':(($g['change']>0?'+':'').number_format($g['change'],2).' จุด')?></td><td class="num"><?=number_format($g['passLatest'])?> / <?=number_format($g['passLatest']+$g['belowLatest']+$g['missingLatest'])?></td></tr>
 <?php endforeach; ?>
 <?php if(!$groupSummary): ?><tr><td colspan="<?=8+count($months)?>" class="text-center">ยังไม่มีข้อมูลในช่วง 3 เดือนล่าสุด</td></tr><?php endif; ?>
 </tbody></table></div></section>
 <section class="org3-panel"><div class="org3-section">คะแนนเปรียบเทียบรายหน่วย (<?=number_format(count($unitRows))?> หน่วย)</div><div class="overflow-x-auto"><table class="org3-table"><thead><tr><th>แผนก</th><th>กลุ่ม - หน่วย</th><?php foreach($months as $m): ?><th class="num"><?=h($m['short'].' '.$m['year_thai'])?></th><?php endforeach; ?><th>วันที่ตรวจล่าสุด</th><th>แหล่งข้อมูลล่าสุด</th></tr></thead><tbody>
 <?php $lastDept=null; foreach($unitRows as $u): if($lastDept!==$u['department']):$lastDept=$u['department']; ?><tr class="dept-break <?=$lastDept==='Office'?'office':''?>"><td colspan="<?=4+count($months)?>"><?=$lastDept==='Production'?'🏭 Production':'🏢 Office'?> — รายหน่วย</td></tr><?php endif; ?>
 <tr><td><?=h($u['department'])?></td><td><b><?=h($u['group_name'])?> - หน่วย <?=h($u['unit_no'])?></b></td><?php foreach($months as $m): $v=$u['scores'][$m['label']]??null; ?><td class="num"><?=$v===null?'—':number_format((float)$v,2).'%'?></td><?php endforeach; ?><td><?=h($u['auditDates'][$latestLabel]??'—')?></td><td><?=h($u['sources'][$latestLabel]??'ไม่มีข้อมูล')?></td></tr>
 <?php endforeach; ?></tbody></table></div></section>
 <div class="org3-note mb-3">หมายเหตุ: หน้าสรุปจะเลือกช่วง 3 เดือนล่าสุดจากเดือนที่มีคะแนนจริงในระบบหรือมีข้อมูลย้อนหลังใน Excel โดยอัตโนมัติ เมื่อมีคะแนนเดือนใหม่เข้าระบบ ช่วงเดือนจะเลื่อนไปเองโดยไม่ต้องแก้โค้ด • ไม่สร้างคะแนนย้อนหลังแทนข้อมูลที่ไม่มี</div>
</div>
<script>
const org3Labels=<?=json_encode($chartLabels,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
const org3Overall=<?=json_encode($chartOverall,JSON_UNESCAPED_UNICODE)?>,org3Prod=<?=json_encode($chartProd,JSON_UNESCAPED_UNICODE)?>,org3Office=<?=json_encode($chartOffice,JSON_UNESCAPED_UNICODE)?>;
const org3Pass=<?=json_encode($chartPass,JSON_UNESCAPED_UNICODE)?>,org3Below=<?=json_encode($chartBelow,JSON_UNESCAPED_UNICODE)?>;
new Chart(document.getElementById('org3Trend'),{type:'line',data:{labels:org3Labels,datasets:[{label:'รวมองค์กร',data:org3Overall,borderColor:'#172238',backgroundColor:'#172238',borderWidth:3,tension:.22,pointRadius:5,spanGaps:false},{label:'Production',data:org3Prod,borderColor:'#ff5a00',backgroundColor:'#ff5a00',borderWidth:3,tension:.22,pointRadius:5,spanGaps:false},{label:'Office',data:org3Office,borderColor:'#16a34a',backgroundColor:'#16a34a',borderWidth:3,tension:.22,pointRadius:5,spanGaps:false}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:ctx=>ctx.dataset.label+': '+(ctx.raw===null?'ไม่มีข้อมูล':Number(ctx.raw).toFixed(2)+'%')}}},scales:{y:{min:0,max:100,ticks:{callback:v=>v+'%'},title:{display:true,text:'คะแนนเฉลี่ย'}}}}});
new Chart(document.getElementById('org3Pass'),{type:'bar',data:{labels:org3Labels,datasets:[{label:'ผ่านเป้าหมาย',data:org3Pass,backgroundColor:'#16a34a',borderRadius:6,stack:'units'},{label:'ต่ำกว่าเป้าหมาย',data:org3Below,backgroundColor:'#dc2626',borderRadius:6,stack:'units'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}},scales:{x:{stacked:true},y:{stacked:true,beginAtZero:true,ticks:{precision:0},title:{display:true,text:'จำนวนหน่วย'}}}}});
</script>
<?php require 'includes/footer.php'; ?>
