<?php
$title = 'ป้ายชื่อบอร์ดกิจกรรม 5ส.';
$thaiMonths = [1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$month = isset($_GET['month']) ? (int)$_GET['month'] : 9;
$year = isset($_GET['year']) ? (int)$_GET['year'] : 2569;
if ($month < 1 || $month > 12) $month = 9;
if ($year < 2560 || $year > 2585) $year = 2569;
require_once __DIR__.'/includes/header.php';
?>
<style>
.board-page{max-width:1500px;margin:0 auto;padding-bottom:24px}
.board-controls{display:flex;align-items:end;gap:14px;flex-wrap:wrap;padding:18px;margin-bottom:18px}
.board-control{display:flex;flex-direction:column;gap:6px;min-width:150px}.board-control label{font-size:13px;font-weight:800;color:#334155}.board-control select{border:1px solid #cbd5e1;border-radius:10px;background:#fff;padding:10px 12px;min-height:42px;color:#172238;font-weight:700}
.board-action{border:0;border-radius:10px;padding:11px 15px;font-weight:900;cursor:pointer;box-shadow:0 3px 8px rgba(15,23,42,.10)}.btn-print{background:#172238;color:#fff}.btn-a4{background:#2563eb;color:#fff}.btn-png{background:#0f9f5a;color:#fff}.btn-copy{background:#ff6500;color:#fff}
.board-hint{font-size:13px;color:#475569;padding:0 4px 14px}
.poster-section{background:#fff;border:1px solid #dbe4f0;border-radius:18px;padding:22px;box-shadow:0 8px 28px rgba(15,23,42,.07)}
.poster-preview-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px;color:#173b70;font-weight:900}
.print-stage{width:100%;display:flex;align-items:center;justify-content:center}
.board-poster{position:relative;isolation:isolate;width:100%;max-width:1420px;aspect-ratio:4.12/1;min-height:220px;overflow:hidden;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:clamp(5px,1.3vw,17px);padding:2.5% 10%;color:#fff;background:radial-gradient(ellipse at 50% 0%,#b30000 0%,#850000 53%,#650000 100%);border:clamp(4px,.6vw,9px) solid #efbd32;box-shadow:inset 0 0 0 3px #ffd95d,inset 0 0 50px rgba(0,0,0,.3),0 8px 24px rgba(0,0,0,.22)}
.board-poster:before,.board-poster:after{content:"";position:absolute;z-index:-1;width:46%;height:180%;top:-40%;background:repeating-linear-gradient(135deg,rgba(255,183,0,.10) 0 22px,transparent 22px 70px);transform:skewX(-12deg)}.board-poster:before{left:-25%}.board-poster:after{right:-25%;transform:skewX(12deg)}
.poster-corners{position:absolute;top:7%;width:7%;height:86%;display:flex;align-items:center;justify-content:center;color:#ffe16b;font-size:clamp(22px,3.8vw,58px);text-shadow:0 3px 3px rgba(0,0,0,.35)}.poster-corners.left{left:1.5%}.poster-corners.right{right:1.5%}
.poster-main{width:100%;text-align:center;background:linear-gradient(180deg,#fff58e 0%,#ffd83e 45%,#f6b91c 100%);border:clamp(2px,.35vw,5px) solid #a96300;border-radius:999px;color:#7c0000;padding:.8% 2%;box-shadow:inset 0 3px 0 rgba(255,255,255,.8),0 5px 0 rgba(0,0,0,.18)}
.poster-title{font-size:clamp(26px,4.2vw,66px);line-height:1.12;letter-spacing:.01em;font-weight:1000;text-shadow:0 2px 0 #fff,0 4px 0 rgba(92,0,0,.3)}
.poster-month{display:flex;align-items:center;justify-content:center;gap:.35em;flex-wrap:wrap;max-width:92%;background:linear-gradient(180deg,#fff 0%,#f2f5f9 100%);color:#132743;border:clamp(2px,.32vw,5px) solid #f4c64a;border-radius:999px;padding:.6% 3%;font-weight:1000;line-height:1.12;box-shadow:0 5px 0 rgba(0,0,0,.22);font-size:clamp(19px,2.8vw,42px)}
.poster-month .month-value{color:#bc0000}.poster-month .year-value{color:#cf1f18}
.poster-brand{display:flex;align-items:center;justify-content:center;gap:clamp(8px,1.2vw,18px);width:72%;font-size:clamp(14px,1.8vw,26px);font-weight:1000;letter-spacing:.04em;color:#fff;text-shadow:0 2px 5px rgba(0,0,0,.4)}.poster-brand:before,.poster-brand:after{content:"";height:3px;flex:1;background:#ffd54a}
.poster-brand .smart{color:#ffbf22}
.poster-caption{position:absolute;bottom:2.4%;left:0;right:0;text-align:center;font-size:clamp(8px,.8vw,12px);font-weight:700;letter-spacing:.12em;color:#ffe9a0;opacity:.88}
@media(max-width:700px){.poster-section{padding:10px}.board-poster{min-height:190px;padding-left:9%;padding-right:9%}.poster-corners{font-size:23px}.board-controls{padding:12px}.board-action{flex:1}}
@media print{
  @page{size:A3 landscape;margin:8mm}
  html,body{background:#fff!important;margin:0!important;padding:0!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
  .no-print,.topbar,.sidebar,.footer{display:none!important}
  .main{margin:0!important;padding:0!important;width:100%!important;min-height:0!important}
  .main>.wrap{max-width:none!important;width:100%!important;margin:0!important;padding:0!important}
  .board-page{max-width:none!important;margin:0!important;padding:0!important;width:100%!important}
  .poster-section{border:0!important;border-radius:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important}
  .poster-preview-head{display:none!important}
  .print-stage{width:100%!important;min-height:calc(var(--paper-height,297mm) - 16mm)!important;display:flex!important;align-items:center!important;justify-content:center!important}
  .board-poster{width:100%!important;max-width:none!important;min-height:0!important;height:auto!important;aspect-ratio:4.12/1!important;break-inside:avoid!important;page-break-inside:avoid!important;box-shadow:none!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
  .poster-title{font-size:22mm!important}.poster-month{font-size:15mm!important}.poster-brand{font-size:8mm!important}.poster-corners{font-size:25mm!important}.poster-caption{font-size:3mm!important}
}
</style>
<div class="board-page">
  <section class="card board-controls no-print">
    <div class="board-control"><label for="monthSelect">เดือนที่ต้องการแสดง</label><select id="monthSelect" onchange="updateBoardText()">
      <?php foreach($thaiMonths as $m=>$name): ?><option value="<?=$m?>" <?=$m===$month?'selected':''?>><?=$name?></option><?php endforeach; ?>
    </select></div>
    <div class="board-control"><label for="yearSelect">ปี พ.ศ.</label><select id="yearSelect" onchange="updateBoardText()">
      <?php for($y=2565;$y<=2580;$y++): ?><option value="<?=$y?>" <?=$y===$year?'selected':''?>><?=$y?></option><?php endfor; ?>
    </select></div>
    <button type="button" class="board-action btn-print" onclick="printBanner('A3')">🖨 พิมพ์ป้าย A3 แนวนอน</button>
    <button type="button" class="board-action btn-a4" onclick="printBanner('A4')">🖨 พิมพ์ A4</button>
    <button type="button" class="board-action btn-png" onclick="downloadBannerPng()">⬇ ดาวน์โหลด PNG</button>
    <button type="button" class="board-action btn-copy" onclick="copyBannerPng()">📋 คัดลอกรูปส่ง LINE</button>
  </section>
  <div class="board-hint no-print">เลือกเดือนและปี แล้วป้ายจะเปลี่ยนข้อความให้อัตโนมัติ จากนั้นพิมพ์หรือบันทึกเป็นภาพเพื่อนำไปติดบอร์ด/ส่ง LINE ได้</div>
  <section class="poster-section">
    <div class="poster-preview-head no-print"><span>ตัวอย่างป้ายชื่อบอร์ด 5ส.</span><span>ตัวอย่างปรับตามเดือนที่เลือก</span></div>
    <div id="printStage" class="print-stage">
      <article id="boardPoster" class="board-poster" aria-label="ป้ายชื่อบอร์ดกิจกรรม 5ส.">
        <div class="poster-corners left" aria-hidden="true">🧹<br>▤</div>
        <div class="poster-corners right" aria-hidden="true">☑<br>✓</div>
        <div class="poster-main"><div class="poster-title">สรุปผลกิจกรรม 5ส.</div></div>
        <div class="poster-month"><span>ประจำเดือน</span><span class="month-value" id="posterMonth"><?=h($thaiMonths[$month])?></span><span class="year-value" id="posterYear"><?=$year?></span></div>
        <div class="poster-brand"><span>5S <span class="smart">SMART</span> | ALUMET</span></div>
        <div class="poster-caption">CLEAN TODAY • BETTER TOMORROW</div>
      </article>
    </div>
  </section>
</div>
<style id="dynamicPrintPage">@page{size:A3 landscape;margin:8mm}</style>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<script>
const monthNamesTh=['','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
function updateBoardText(){
  const month=parseInt(document.getElementById('monthSelect').value,10);
  const year=parseInt(document.getElementById('yearSelect').value,10);
  document.getElementById('posterMonth').textContent=monthNamesTh[month];
  document.getElementById('posterYear').textContent=year;
  const u=new URL(window.location.href);u.searchParams.set('month',month);u.searchParams.set('year',year);history.replaceState({},'',u.toString());
}
function printBanner(paper){
  updateBoardText();
  const isA3=paper==='A3';
  document.getElementById('dynamicPrintPage').textContent='@page{size:'+paper+' landscape;margin:8mm}';
  document.getElementById('printStage').style.setProperty('--paper-height',isA3?'297mm':'210mm');
  document.title='5S SMART ALUMET - '+document.getElementById('posterMonth').textContent+' '+document.getElementById('posterYear').textContent;
  window.print();
}
async function renderPosterBlob(){
  updateBoardText();
  if(!window.html2canvas){throw new Error('โหลดเครื่องมือสร้างภาพไม่สำเร็จ กรุณาตรวจการเชื่อมต่ออินเทอร์เน็ต');}
  const el=document.getElementById('boardPoster');
  const canvas=await html2canvas(el,{scale:4,backgroundColor:null,useCORS:true,logging:false,width:el.scrollWidth,height:el.scrollHeight});
  return await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
}
async function downloadBannerPng(){
  try{const blob=await renderPosterBlob();if(!blob)throw new Error('สร้างภาพไม่สำเร็จ');const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='5S_SMART_ALUMET_'+document.getElementById('posterMonth').textContent+'_'+document.getElementById('posterYear').textContent+'.png';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);}catch(e){alert(e.message||'ไม่สามารถบันทึกภาพได้');}
}
async function copyBannerPng(){
  try{const blob=await renderPosterBlob();if(!blob)throw new Error('สร้างภาพไม่สำเร็จ');if(navigator.clipboard&&window.ClipboardItem){await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);alert('คัดลอกรูปแล้ว เปิด LINE แล้วกด Ctrl+V เพื่อวางภาพได้เลยครับ');}else{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='5S_SMART_ALUMET_board.png';a.click();alert('เบราว์เซอร์นี้ไม่รองรับการคัดลอกรูปโดยตรง จึงดาวน์โหลด PNG ให้แล้ว นำไฟล์ไปแนบใน LINE ได้ครับ');}}catch(e){downloadBannerPng();alert('คัดลอกภาพโดยตรงไม่สำเร็จ ระบบกำลังดาวน์โหลด PNG ให้แทนครับ');}
}
updateBoardText();
</script>
<?php require_once __DIR__.'/includes/footer.php'; ?>
