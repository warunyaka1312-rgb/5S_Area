<?php
require_once 'config.php';
$title='ตั้งค่าเป้าหมาย 5 ส.';
$p=db();$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $prod=(float)($_POST['production_target_pct']??85); $off=(float)($_POST['office_target_pct']??87);
 if($prod<1||$prod>100||$off<1||$off>100)$msg='เป้าหมายต้องอยู่ระหว่าง 1–100%';
 else{save_app_setting('production_target_pct',number_format($prod,2,'.',''));save_app_setting('office_target_pct',number_format($off,2,'.',''));save_app_setting('target_pct',number_format($prod,2,'.',''));$msg='บันทึกเป้าหมาย Production และ Office เรียบร้อยแล้ว';}
}
$prodTarget=target_pct('Production');$officeTarget=target_pct('Office');
require 'includes/header.php';
?>
<div class="hero"><div class="hero-copy"><h1>ตั้งค่า <span>เป้าหมาย</span></h1><p>กำหนดเป้าหมายแยกกันระหว่าง Production และ Office</p></div><div class="hero-right"><strong>P <?=number_format($prodTarget,1)?>% / O <?=number_format($officeTarget,1)?>%</strong><small>เป้าหมายปัจจุบัน</small></div></div>
<?php if($msg):?><div class="card p-4 mb-5 bg-emerald-50 text-emerald-800 font-bold">✅ <?=h($msg)?></div><?php endif;?>
<div class="grid md:grid-cols-2 gap-5">
 <div class="card p-6 border-l-8 border-orange-500"><div class="section-title mb-4">🏭 Production</div><form method="post"><input type="hidden" name="office_target_pct" value="<?=h($officeTarget)?>"><label class="font-bold">เป้าหมาย (%)</label><input type="number" name="production_target_pct" step="0.1" min="1" max="100" value="<?=h($prodTarget)?>" class="w-full border rounded-xl p-4 text-2xl font-black mt-2"><p class="text-sm text-slate-500 mt-2">ค่าเริ่มต้น 85%</p><button class="bg-orange-500 text-white rounded-xl px-7 py-3 font-black mt-4">💾 บันทึก</button></form></div>
 <div class="card p-6 border-l-8 border-blue-500"><div class="section-title mb-4">🏢 Office</div><form method="post"><input type="hidden" name="production_target_pct" value="<?=h($prodTarget)?>"><label class="font-bold">เป้าหมาย (%)</label><input type="number" name="office_target_pct" step="0.1" min="1" max="100" value="<?=h($officeTarget)?>" class="w-full border rounded-xl p-4 text-2xl font-black mt-2"><p class="text-sm text-slate-500 mt-2">ค่าเริ่มต้น 87%</p><button class="bg-blue-600 text-white rounded-xl px-7 py-3 font-black mt-4">💾 บันทึก</button></form></div>
</div>
<div class="card p-5 mt-5 bg-blue-50 text-blue-900">ระบบจะใช้เป้าหมายของแต่ละประเภทกับหน้า Manual, Import, Dashboard, Ranking, รายงาน และกราฟแยกประเภท</div>
<?php require 'includes/footer.php';?>