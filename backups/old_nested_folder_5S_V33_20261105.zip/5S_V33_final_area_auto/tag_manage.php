<?php
require_once 'config.php';
$title='รับ Tag / ปิด Tag';
$p=db();
/* Additive migration for before/after evidence photos; preserves existing Tag records. */
$tagCols = $p->query("PRAGMA table_info(tags)")->fetchAll(PDO::FETCH_ASSOC);
$tagColNames = array_column($tagCols, 'name');
foreach (['before_photo','after_photo','source_photo'] as $photoCol) {
    if (!in_array($photoCol, $tagColNames, true)) {
        $p->exec("ALTER TABLE tags ADD COLUMN $photoCol TEXT NOT NULL DEFAULT ''");
    }
}
/* Department corrective-action fields: additive migration, keeps existing records intact. */
$tagCols = $p->query("PRAGMA table_info(tags)")->fetchAll(PDO::FETCH_ASSOC);
$tagColNames = array_column($tagCols, 'name');
foreach (['corrective_action','corrective_by','corrective_date','verification_note','tag_type','defect_types','suggestion','issued_by','receiver'] as $col) {
    if (!in_array($col, $tagColNames, true)) {
        $p->exec("ALTER TABLE tags ADD COLUMN $col TEXT NOT NULL DEFAULT ''");
    }
}
$uploadDir = __DIR__ . '/uploads/tag_photos';
if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0755, true); }
$notice='';
$noticeType='success';
function save_tag_photos(string $field, string $uploadDir): string {
    if (!isset($_FILES[$field])) return '';
    $f = $_FILES[$field];
    $names = is_array($f['name'] ?? null) ? $f['name'] : [$f['name'] ?? ''];
    $tmpNames = is_array($f['tmp_name'] ?? null) ? $f['tmp_name'] : [$f['tmp_name'] ?? ''];
    $errors = is_array($f['error'] ?? null) ? $f['error'] : [$f['error'] ?? UPLOAD_ERR_NO_FILE];
    $sizes = is_array($f['size'] ?? null) ? $f['size'] : [$f['size'] ?? 0];
    $paths = [];
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $count = 0;
    foreach ($names as $i => $originalName) {
        $err = $errors[$i] ?? UPLOAD_ERR_NO_FILE;
        if ($err === UPLOAD_ERR_NO_FILE || $originalName === '') continue;
        if ($err !== UPLOAD_ERR_OK) throw new RuntimeException('อัปโหลดรูปไม่สำเร็จ กรุณาลองใหม่ (รหัส ' . (int)$err . ')');
        if (($sizes[$i] ?? 0) > 5 * 1024 * 1024) throw new RuntimeException('รูปแต่ละภาพต้องมีขนาดไม่เกิน 5 MB');
        $tmp = $tmpNames[$i] ?? '';
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
        if (!isset($allowed[$mime]) || @getimagesize($tmp) === false) throw new RuntimeException('รองรับเฉพาะรูป JPG, PNG หรือ WEBP ที่ถูกต้อง');
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) throw new RuntimeException('ไม่สามารถสร้างโฟลเดอร์เก็บรูปได้');
        $name = 'tag_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '_' . $field . '.' . $allowed[$mime];
        if (!move_uploaded_file($tmp, $uploadDir . '/' . $name)) throw new RuntimeException('บันทึกรูปลงโฟลเดอร์ไม่สำเร็จ กรุณาตรวจสิทธิ์โฟลเดอร์ uploads/tag_photos');
        $paths[] = 'uploads/tag_photos/' . $name;
        $count++;
        if ($count > 10) throw new RuntimeException('แนบได้ไม่เกิน 10 รูปต่อช่อง');
    }
    return $paths ? json_encode($paths, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';
}
function tag_photo_paths($raw): array {
    if (!$raw) return [];
    $decoded = json_decode((string)$raw, true);
    if (is_array($decoded)) return array_values(array_filter($decoded, 'is_string'));
    // Compatibility with older records that store one image path as plain text.
    return [(string)$raw];
}


/* Build dropdown options from the live 5S database without rewriting history. */
$departments = [];
foreach (["SELECT DISTINCT department AS v FROM areas WHERE TRIM(department)<>''",
           "SELECT DISTINCT department AS v FROM audit_plans WHERE TRIM(department)<>''",
           "SELECT DISTINCT department AS v FROM tags WHERE TRIM(department)<>''"] as $sqlOpt) {
    try { foreach ($p->query($sqlOpt)->fetchAll(PDO::FETCH_COLUMN) as $v) if (trim((string)$v)!=='') $departments[] = trim((string)$v); } catch(Throwable $e) {}
}
$departments = array_values(array_unique($departments)); natcasesort($departments); $departments = array_values($departments);
$unitMap = [];
try { foreach ($p->query("SELECT department, unit_no AS unit FROM areas WHERE TRIM(department)<>'' AND TRIM(unit_no)<>''")->fetchAll() as $r) { $d=trim((string)$r['department']); $u=trim((string)$r['unit']); if($d!==''&&$u!=='') $unitMap[$d][]=$u; } } catch(Throwable $e) {}
try { foreach ($p->query("SELECT department, unit_no AS unit FROM tags WHERE TRIM(department)<>'' AND TRIM(unit_no)<>''")->fetchAll() as $r) { $d=trim((string)$r['department']); $u=trim((string)$r['unit']); if($d!==''&&$u!=='') $unitMap[$d][]=$u; } } catch(Throwable $e) {}
try { foreach ($p->query("SELECT department, area_5s AS unit FROM audit_plans WHERE TRIM(department)<>'' AND TRIM(area_5s)<>''")->fetchAll() as $r) { $d=trim((string)$r['department']); $u=trim((string)$r['unit']); if($d!==''&&$u!=='') $unitMap[$d][]=$u; } } catch(Throwable $e) {}
foreach($unitMap as $d=>$units){
  $expanded=[];
  foreach($units as $unitValue){
    foreach(preg_split('/\s*[,;，、]\s*/u',trim((string)$unitValue),-1,PREG_SPLIT_NO_EMPTY) as $unitPart){
      $unitPart=trim($unitPart); if($unitPart!=='') $expanded[]=$unitPart;
    }
  }
  $units=array_values(array_unique($expanded));natcasesort($units);$unitMap[$d]=array_values($units);
}
$auditors=[];
foreach ([
"SELECT DISTINCT auditor_name AS v FROM audit_plans WHERE TRIM(auditor_name)<>''",
"SELECT DISTINCT auditor AS v FROM audits WHERE TRIM(auditor)<>''",
"SELECT DISTINCT auditor2 AS v FROM audits WHERE TRIM(auditor2)<>''",
"SELECT DISTINCT auditor3 AS v FROM audits WHERE TRIM(auditor3)<>''",
"SELECT DISTINCT auditor_name AS v FROM auditor_monthly_history WHERE TRIM(auditor_name)<>''",
"SELECT DISTINCT auditor_name AS v FROM auditor_monthly_history_unified WHERE TRIM(auditor_name)<>''",
"SELECT DISTINCT auditor AS v FROM tags WHERE TRIM(auditor)<>''"
] as $sqlOpt) { try { foreach($p->query($sqlOpt)->fetchAll(PDO::FETCH_COLUMN) as $v) if(trim((string)$v)!=='') $auditors[]=trim((string)$v); } catch(Throwable $e) {} }
$auditors=array_values(array_unique($auditors)); natcasesort($auditors); $auditors=array_values($auditors);
$editId=(int)($_GET['edit']??0); $editTag=null;
if($editId>0){$qEdit=$p->prepare("SELECT * FROM tags WHERE id=?");$qEdit->execute([$editId]);$editTag=$qEdit->fetch()?:null;}
$savedDefectTypes = json_decode((string)($editTag['defect_types'] ?? '[]'), true);
if (!is_array($savedDefectTypes)) $savedDefectTypes = [];

if($_SERVER['REQUEST_METHOD']==='POST'){
 $action=$_POST['action']??'';
 if($action==='save'){
   try {
     $tag=trim($_POST['tag_no']??'');$dept=trim($_POST['department']??'');$unit=trim($_POST['unit_no']??'');
     $td=$_POST['tag_date']??date('Y-m-d');$due=$_POST['due_date']??'';$closed=$_POST['closed_date']??'';
     $status=($closed!=='')?'CLOSED':'OPEN';
     $aud=trim($_POST['auditor']??'');$note=trim($_POST['note']??'');
     $correctiveAction=trim($_POST['corrective_action']??'');$correctiveBy=trim($_POST['corrective_by']??'');$correctiveDate=trim($_POST['corrective_date']??'');$verificationNote=trim($_POST['verification_note']??'');
     $tagType=strtoupper(trim((string)($_POST['tag_type']??''))); if(!in_array($tagType,['RED','WHITE'],true)) $tagType='';
     $rawDefects=$_POST['defect_types']??[]; if(!is_array($rawDefects)) $rawDefects=[]; $defectOptions=['1','2','3','4','5','6','7','8','9','10']; $rawDefects=array_values(array_unique(array_intersect($defectOptions,array_map('strval',$rawDefects))));
     $defectTypes=json_encode($rawDefects,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
     $suggestion=trim((string)($_POST['suggestion']??'')); $issuedBy=trim((string)($_POST['issued_by']??'')); $receiver=trim((string)($_POST['receiver']??''));
     if($tag==='' || $dept==='') throw new RuntimeException('กรุณากรอก Tag No. และแผนก');
     $editId=(int)($_POST['id']??0);
     $dup=$p->prepare('SELECT id FROM tags WHERE UPPER(TRIM(tag_no))=UPPER(TRIM(?)) AND id<>? LIMIT 1');
     $dup->execute([$tag,$editId]);
     if($dup->fetchColumn()) throw new RuntimeException('Tag No. นี้มีอยู่แล้วในระบบ กรุณาใช้หมายเลข Tag ที่ไม่ซ้ำ หรือเปิดรายการเดิมเพื่อแก้ไข');
     $before=save_tag_photos('before_photo',$uploadDir);
     $after=save_tag_photos('after_photo',$uploadDir);
     $sourcePhoto=save_tag_photos('source_photo_file',$uploadDir);
     if($editId>0){
       $oldQ=$p->prepare("SELECT before_photo,after_photo,source_photo FROM tags WHERE id=?");$oldQ->execute([$editId]);$old=$oldQ->fetch();
       if(!$old) throw new RuntimeException('ไม่พบรายการ Tag ที่ต้องการแก้ไข');
       if($before==='') $before=(string)$old['before_photo'];
       if($after==='') $after=(string)$old['after_photo'];
       if($sourcePhoto==='') $sourcePhoto=(string)($old['source_photo']??'');
       $q=$p->prepare("UPDATE tags SET tag_no=?,department=?,unit_no=?,tag_date=?,due_date=?,closed_date=?,status=?,auditor=?,note=?,before_photo=?,after_photo=?,source_photo=?,corrective_action=?,corrective_by=?,corrective_date=?,verification_note=?,tag_type=?,defect_types=?,suggestion=?,issued_by=?,receiver=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
       $q->execute([$tag,$dept,$unit,$td,$due,$closed,$status,$aud,$note,$before,$after,$sourcePhoto,$correctiveAction,$correctiveBy,$correctiveDate,$verificationNote,$tagType,$defectTypes,$suggestion,$issuedBy,$receiver,$editId]);$notice='แก้ไข Tag และข้อมูลตามแบบฟอร์มเรียบร้อย';
     }else{
       $q=$p->prepare("INSERT INTO tags(tag_no,department,unit_no,tag_date,due_date,closed_date,status,auditor,note,before_photo,after_photo,source_photo,corrective_action,corrective_by,corrective_date,verification_note,tag_type,defect_types,suggestion,issued_by,receiver,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)");
       $q->execute([$tag,$dept,$unit,$td,$due,$closed,$status,$aud,$note,$before,$after,$sourcePhoto,$correctiveAction,$correctiveBy,$correctiveDate,$verificationNote,$tagType,$defectTypes,$suggestion,$issuedBy,$receiver]);$notice='บันทึก Tag และข้อมูลตามแบบฟอร์มเรียบร้อย';
     }
   } catch (Throwable $e) { $notice=$e->getMessage(); $noticeType='error'; }
 } elseif($action==='delete'){
   $id=(int)($_POST['id']??0);
   if($id>0){$p->prepare('DELETE FROM tags WHERE id=?')->execute([$id]);$notice='ลบรายการ Tag เรียบร้อย';}
 } elseif($action==='close'){
   $id=(int)$_POST['id'];$cd=$_POST['closed_date']?:date('Y-m-d');$p->prepare("UPDATE tags SET status='CLOSED',closed_date=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$cd,$id]);$notice='ปิด Tag เรียบร้อย';
 } elseif($action==='reopen'){
   $id=(int)$_POST['id'];$p->prepare("UPDATE tags SET status='OPEN',closed_date='',updated_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$id]);$notice='เปิด Tag กลับมาเพื่อติดตาม';
 }
}
$filter=$_GET['status']??'ALL';$params=[];$sql="SELECT * FROM tags";if($filter==='OPEN'||$filter==='CLOSED'){$sql.=" WHERE status=?";$params[]=$filter;}$sql.=" ORDER BY CASE WHEN status='OPEN' THEN 0 ELSE 1 END,tag_date DESC,id DESC";
$q=$p->prepare($sql);$q->execute($params);$tags=$q->fetchAll();
require 'includes/header.php';?>
<div class="hero"><div class="hero-copy"><h1>รับ Tag และ <span>ปิด Tag 5 ส.</span></h1><p>ทุกเดือนรับ Tag → ติดตาม → ปิดจบ → สรุป</p></div><div class="hero-right"><strong>TAG CONTROL</strong><small>ติดตามจนปิดจบ</small></div></div>
<?php if($notice):?><div class="<?=($noticeType==='error'?'bg-red-100 text-red-800':'bg-emerald-100 text-emerald-800')?> rounded-xl p-4 mb-4 font-bold"><?=($noticeType==='error'?'⚠️ ':'✅ ')?><?=h($notice)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data" class="card p-5 mb-5"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=h((string)($editTag['id']??''))?>"><div class="rounded-2xl border-2 border-indigo-200 bg-indigo-50 p-4 mb-5" id="tagPaperImportPanel">
 <div class="flex flex-wrap items-center justify-between gap-3 mb-3"><div><h3 class="font-black text-indigo-900 text-lg">📷 รับ Tag จากภาพถ่าย — เติมข้อมูลอัตโนมัติ</h3><p class="text-sm text-indigo-800">เลือกรูปแบบฟอร์ม Tag ที่ถ่ายมา ระบบจะช่วยอ่านข้อความและเติมช่องด้านล่างให้ ตรวจแก้ได้ทุกช่องก่อนบันทึก</p></div><span class="rounded-full bg-white border border-indigo-200 px-3 py-1 text-xs font-bold text-indigo-800">OCR • ไทย + อังกฤษ</span></div>
 <div class="grid md:grid-cols-2 gap-4 items-start"><div><label class="block font-bold mb-2">ภาพถ่ายแบบฟอร์ม Tag ต้นฉบับ</label><input id="tagSourceImage" type="file" name="source_photo_file" accept="image/jpeg,image/png,image/webp" class="block w-full border rounded-xl bg-white p-3"><p class="text-xs text-slate-600 mt-1">JPG / PNG / WEBP • ไม่เกิน 5 MB • ระบบจะเก็บภาพต้นฉบับกับรายการ Tag นี้แยกจากรูป Before/After</p><div id="tagSourcePreview" class="mt-3"></div><button type="button" id="tagReadOcr" class="mt-3 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white px-4 py-3 font-black">🔎 อ่านภาพและเติมข้อมูลอัตโนมัติ</button><div id="tagOcrStatus" class="mt-2 text-sm font-bold text-indigo-800" aria-live="polite">เลือกรูปก่อน แล้วกดอ่านภาพ</div></div>
 <div><label class="block font-bold mb-2">ข้อความที่ระบบอ่านได้ (ตรวจสอบได้)</label><textarea id="tagOcrRaw" rows="9" class="w-full border rounded-xl p-3 bg-white text-sm" placeholder="ข้อความจากภาพจะปรากฏที่นี่ เพื่อให้ตรวจทานกับรูปต้นฉบับ"></textarea><div id="tagOcrDuplicate" class="hidden mt-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900"></div><p class="text-xs text-amber-800 mt-2">ลายมือไทยและเครื่องหมายในช่องติ๊กอาจอ่านผิดได้ โดยเฉพาะประเภท Tag และประเภทจุดบกพร่อง กรุณาตรวจ/แก้ก่อนบันทึกทุกครั้ง</p></div></div>
 </div>
 <div class="section-title mb-4"><?= $editTag ? '✏️ แก้ไข Tag '.h($editTag['tag_no']) : '＋ รับ Tag ใหม่' ?></div>
<div class="grid md:grid-cols-4 xl:grid-cols-8 gap-3">
<div><label>Tag No.</label><input name="tag_no" required class="w-full border rounded-xl p-3" placeholder="TAG-0001" value="<?=h((string)($editTag['tag_no']??''))?>"></div>
<div><label>แผนก</label><select id="tagDepartment" name="department" required class="w-full border rounded-xl p-3"><option value="">เลือกแผนก</option><?php foreach($departments as $d):?><option value="<?=h($d)?>" <?=((string)($editTag['department']??'')===$d?'selected':'')?>><?=h($d)?></option><?php endforeach;?><?php if($editTag && !in_array($editTag['department'],$departments,true)):?><option selected value="<?=h($editTag['department'])?>"><?=h($editTag['department'])?></option><?php endif;?></select></div>
<div><label>หน่วย</label><select id="tagUnit" name="unit_no" class="w-full border rounded-xl p-3"><option value="">เลือกหน่วย</option><?php foreach(($unitMap[(string)($editTag['department']??'')]??[]) as $u):?><option value="<?=h($u)?>" <?=((string)($editTag['unit_no']??'')===$u?'selected':'')?>><?=h($u)?></option><?php endforeach;?><?php if($editTag && !in_array((string)$editTag['unit_no'],($unitMap[(string)$editTag['department']]??[]),true)):?><option selected value="<?=h((string)$editTag['unit_no'])?>"><?=h((string)$editTag['unit_no'])?></option><?php endif;?></select></div>
<div><label>วันที่รับ Tag</label><input name="tag_date" type="date" value="<?=h((string)($editTag['tag_date']??date('Y-m-d')))?>" class="w-full border rounded-xl p-3"></div>
<div><label>กำหนดปิด</label><input name="due_date" type="date" value="<?=h((string)($editTag['due_date']??''))?>" class="w-full border rounded-xl p-3"></div>
<div><label>วันที่ปิด</label><input name="closed_date" type="date" value="<?=h((string)($editTag['closed_date']??''))?>" class="w-full border rounded-xl p-3"></div>
<div><label>ผู้รับผิดชอบ/ผู้ตรวจ</label><input list="tagAuditorOptions" name="auditor" class="w-full border rounded-xl p-3" value="<?=h((string)($editTag['auditor']??''))?>" placeholder="เลือกหรือพิมพ์ชื่อ"><datalist id="tagAuditorOptions"><?php foreach($auditors as $a):?><option value="<?=h($a)?>"><?php endforeach;?></datalist></div>
<div class="flex items-end gap-2"><button class="w-full bg-orange-500 text-white rounded-xl p-3 font-black">💾 <?= $editTag?'บันทึกการแก้ไข':'บันทึก Tag' ?></button><?php if($editTag):?><a href="tag_manage.php" class="rounded-xl border px-3 py-3">ยกเลิก</a><?php endif;?></div>
</div><div class="mt-3"><label>จุดบกพร่องที่ตรวจพบ / Note</label><input name="note" class="w-full border rounded-xl p-3" placeholder="ระบุจุดบกพร่องตามแบบฟอร์ม Tag" value="<?=h((string)($editTag['note']??''))?>"></div>
<div class="mt-4 rounded-xl border border-orange-200 bg-orange-50 p-4">
 <div class="font-black text-orange-900 mb-3">ข้อมูลตามแบบฟอร์ม PLANT PATROL 5S &amp; AM TAG</div>
 <div class="mb-3"><label class="block mb-2">ประเภท Tag</label><div class="flex flex-wrap gap-4">
  <label class="inline-flex items-center gap-2 rounded-lg border border-red-300 bg-red-50 px-4 py-2 font-bold text-red-700"><input type="radio" name="tag_type" value="RED" <?=((string)($editTag['tag_type']??'')==='RED'?'checked':'')?>> Tag แดง</label>
  <label class="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 font-bold text-slate-700"><input type="radio" name="tag_type" value="WHITE" <?=((string)($editTag['tag_type']??'')==='WHITE'?'checked':'')?>> Tag ขาว</label>
  <span class="text-xs text-slate-600 self-center">เลือกประเภทให้ตรงกับป้ายจริง</span>
 </div></div>
 <label class="block mb-2">ประเภทจุดบกพร่องที่ตรวจพบ (เลือกได้หลายข้อ)</label>
 <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-2 text-sm">
 <?php $defectLabels=['1'=>'ก่อให้เกิดการชำรุด','2'=>'Basic Condition ไม่ดี','3'=>'ยากลำบากในการทำงาน','4'=>'ก่อให้เกิดความสกปรก','5'=>'ก่อให้เกิดของเสีย','6'=>'มากเกินความจำเป็น / ระเกะระกะ','7'=>'ก่อให้เกิดอันตราย','8'=>'ก่อให้เกิดการเปลืองพลังงาน','9'=>'ความปลอดภัย','10'=>'สิ่งแวดล้อม']; foreach($defectLabels as $key=>$label): ?>
 <label class="flex items-start gap-2 rounded-lg border bg-white p-2"><input class="mt-1" type="checkbox" name="defect_types[]" value="<?=h($key)?>" <?=in_array($key,array_map('strval',$savedDefectTypes),true)?'checked':''?>><span><?=h($key.'. '.$label)?></span></label>
 <?php endforeach; ?>
 </div>
 <div class="mt-3"><label>ข้อเสนอแนะในการดำเนินการ</label><textarea name="suggestion" rows="3" class="w-full border rounded-xl p-3" placeholder="ข้อเสนอแนะในการแก้ไขจุดบกพร่อง"><?=h((string)($editTag['suggestion']??''))?></textarea></div>
 <div class="grid md:grid-cols-2 gap-3 mt-3"><div><label>ติด Tag โดย</label><input name="issued_by" class="w-full border rounded-xl p-3" value="<?=h((string)($editTag['issued_by']??''))?>" placeholder="ชื่อผู้ติด Tag"></div><div><label>ผู้รับ Tag</label><input name="receiver" class="w-full border rounded-xl p-3" value="<?=h((string)($editTag['receiver']??''))?>" placeholder="ชื่อผู้รับ Tag / ผู้รับผิดชอบพื้นที่"></div></div>
 <p class="text-xs text-orange-800 mt-2">ข้อมูลส่วนนี้จะดึงไปเติมในแบบฟอร์มพิมพ์อัตโนมัติ รวมถึงรูป Before/After ของรายการ Tag เดียวกัน</p>
</div>
<div class="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-4"><div class="font-black text-emerald-800 mb-3">ส่วนดำเนินการแก้ไข — สำหรับผู้ดูแลแผนกกรอก</div><div class="grid md:grid-cols-2 gap-3"><div><label>รายละเอียดการแก้ไข / Corrective Action</label><textarea name="corrective_action" rows="3" class="w-full border rounded-xl p-3" placeholder="ระบุวิธีแก้ไขและการป้องกันการเกิดซ้ำ"><?=h((string)($editTag['corrective_action']??''))?></textarea></div><div><label>ผลการตรวจยืนยัน / Verification</label><textarea name="verification_note" rows="3" class="w-full border rounded-xl p-3" placeholder="ผลตรวจหลังแก้ไข / หลักฐานยืนยัน"><?=h((string)($editTag['verification_note']??''))?></textarea></div><div><label>ผู้ดำเนินการแก้ไข</label><input name="corrective_by" class="w-full border rounded-xl p-3" value="<?=h((string)($editTag['corrective_by']??''))?>" placeholder="ชื่อผู้รับผิดชอบการแก้ไข"></div><div><label>วันที่ดำเนินการแก้ไข</label><input name="corrective_date" type="date" class="w-full border rounded-xl p-3" value="<?=h((string)($editTag['corrective_date']??''))?>"></div></div><p class="text-xs text-emerald-700 mt-2">ข้อมูลจากภาพสามารถแก้ไขได้ทุกช่องก่อนบันทึก ส่วนนี้ใช้บันทึกความคืบหน้าการแก้ไข</p></div>
<div class="grid md:grid-cols-2 gap-4 mt-4">
 <div class="rounded-xl border border-red-200 bg-red-50 p-4"><label class="font-bold text-red-700">📷 รูปก่อนแก้ไข (Before) — เลือกได้หลายรูป</label><input type="file" name="before_photo[]" multiple accept="image/jpeg,image/png,image/webp" class="block w-full mt-2"><p class="text-xs text-slate-500 mt-1">JPG / PNG / WEBP • ไม่เกิน 5 MB ต่อรูป • สูงสุด 10 รูป</p><div id="beforePreview" class="flex flex-wrap gap-2 mt-3"></div></div>
 <div class="rounded-xl border border-green-200 bg-green-50 p-4"><label class="font-bold text-green-700">📷 รูปหลังแก้ไข (After) — เลือกได้หลายรูป</label><input type="file" name="after_photo[]" multiple accept="image/jpeg,image/png,image/webp" class="block w-full mt-2"><p class="text-xs text-slate-500 mt-1">JPG / PNG / WEBP • ไม่เกิน 5 MB ต่อรูป • สูงสุด 10 รูป</p><div id="afterPreview" class="flex flex-wrap gap-2 mt-3"></div></div>
</div>
<?php if($editTag && !empty($editTag['source_photo'])):?><div class="mt-4 rounded-xl border border-indigo-200 bg-indigo-50 p-3"><div class="font-bold mb-2">ภาพแบบฟอร์มต้นฉบับเดิม</div><?php foreach(tag_photo_paths($editTag['source_photo']) as $photo):?><a href="<?=h($photo)?>" target="_blank" class="inline-block mr-2 mb-2"><img src="<?=h($photo)?>" alt="ภาพ Tag ต้นฉบับ" style="width:150px;max-height:150px;object-fit:contain;border:1px solid #ddd;border-radius:8px;background:#fff"></a><?php endforeach;?><p class="text-xs text-slate-600">หากไม่เลือกรูปใหม่ ระบบจะเก็บภาพต้นฉบับนี้ไว้</p></div><?php endif;?><?php if($editTag):?><div class="grid md:grid-cols-2 gap-4 mt-4"><?php foreach(['before_photo'=>'รูปก่อนแก้ไขเดิม','after_photo'=>'รูปหลังแก้ไขเดิม'] as $col=>$label):?><div><div class="font-bold mb-2"><?=h($label)?></div><?php foreach(tag_photo_paths($editTag[$col]??'') as $photo):?><a href="<?=h($photo)?>" target="_blank" class="inline-block mr-2 mb-2"><img src="<?=h($photo)?>" style="width:90px;height:70px;object-fit:cover;border-radius:8px;border:1px solid #ddd"></a><?php endforeach;?></div><?php endforeach;?></div><p class="text-sm text-slate-500 mt-2">หากไม่เลือกรูปใหม่ ระบบจะเก็บรูปเดิมไว้</p><?php endif;?></form>

<div class="flex gap-2 mb-4 no-print"><a href="?status=ALL" class="px-4 py-2 rounded-lg border">ทั้งหมด</a><a href="?status=OPEN" class="px-4 py-2 rounded-lg border text-red-600">ยังไม่ปิด</a><a href="?status=CLOSED" class="px-4 py-2 rounded-lg border text-emerald-600">ปิดแล้ว</a><a target="_blank" href="tag_print.php" class="px-4 py-2 rounded-lg bg-slate-900 text-white font-bold">🖨 พิมพ์สรุป</a></div>
<div class="card p-5"><div class="section-title mb-4">🏷 รายการ Tag</div><div class="overflow-x-auto"><table id="tagTable" class="display w-full"><thead><tr><th>Tag No.</th><th>แผนก</th><th>หน่วย</th><th>วันที่รับ</th><th>กำหนดปิด</th><th>วันที่ปิด</th><th>รูปก่อน</th><th>รูปหลัง</th><th>สถานะ</th><th>Note</th><th>การแก้ไข</th><th>จัดการ</th></tr></thead><tbody>
<?php foreach($tags as $r):?><tr><td><div class="font-bold"><?=h($r['tag_no'])?></div><?php if(($r['tag_type']??'')==='RED'):?><span class="inline-block mt-1 px-2 py-1 rounded-full text-xs font-black bg-red-100 text-red-700">Tag แดง</span><?php elseif(($r['tag_type']??'')==='WHITE'):?><span class="inline-block mt-1 px-2 py-1 rounded-full text-xs font-black bg-slate-100 text-slate-700">Tag ขาว</span><?php else:?><span class="inline-block mt-1 px-2 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800">ยังไม่ระบุประเภท</span><?php endif;?></td><td><?=h($r['department'])?></td><td><?=h($r['unit_no'])?></td><td><?=h($r['tag_date'])?></td><td><?=h($r['due_date'])?></td><td><?=h($r['closed_date'])?></td><td><?php foreach(tag_photo_paths($r['before_photo'] ?? '') as $photo):?><a href="<?=h($photo)?>" target="_blank" class="inline-block mr-1 mb-1"><img src="<?=h($photo)?>" alt="Before" style="width:64px;height:48px;object-fit:cover;border-radius:6px"></a><?php endforeach;?></td><td><?php foreach(tag_photo_paths($r['after_photo'] ?? '') as $photo):?><a href="<?=h($photo)?>" target="_blank" class="inline-block mr-1 mb-1"><img src="<?=h($photo)?>" alt="After" style="width:64px;height:48px;object-fit:cover;border-radius:6px"></a><?php endforeach;?></td><td><?php if($r['status']==='CLOSED'):?><span class="good px-2 py-1 rounded-full font-bold">ปิดจบ</span><?php else:?><span class="bad px-2 py-1 rounded-full font-bold">ยังไม่ปิด</span><?php endif;?></td><td><?=h($r['note'])?></td><td><?=h($r['corrective_action']??'')?><?php if(!empty($r['corrective_by'])):?><div class="text-xs text-slate-500">ผู้แก้ไข: <?=h($r['corrective_by'])?> <?=h($r['corrective_date']??'')?></div><?php endif;?><?php if(!empty($r['verification_note'])):?><div class="text-xs text-emerald-700">ยืนยัน: <?=h($r['verification_note'])?></div><?php endif;?></td><td>
<a href="tag_manage.php?edit=<?=$r['id']?>" class="inline-block text-blue-700 font-bold mr-2">✏️ แก้ไข</a> <a href="tag_form_print.php?id=<?=$r['id']?>" target="_blank" class="inline-block text-orange-700 font-bold mr-2">🖨 พิมพ์แบบฟอร์ม</a>
<?php if($r['status']==='OPEN'):?><form method="post" class="inline"><input type="hidden" name="action" value="close"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="text-emerald-700 font-bold">✓ ปิด Tag</button></form><?php else:?><form method="post" class="inline"><input type="hidden" name="action" value="reopen"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="text-red-600 font-bold">↻ เปิดติดตาม</button></form><?php endif;?> <form method="post" class="inline" onsubmit="return confirm('ยืนยันลบรายการ Tag นี้ใช่หรือไม่? การลบไม่สามารถย้อนกลับได้');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="text-red-700 font-bold ml-2">🗑 ลบ</button></form></td></tr><?php endforeach;?>
</tbody></table></div></div>
<script>$(function(){$('#tagTable').DataTable({pageLength:25,scrollX:true,order:[[6,'asc']],language:{search:'ค้นหา:',lengthMenu:'แสดง _MENU_',paginate:{next:'ถัดไป',previous:'ก่อนหน้า'}}})});</script>
<script>
window.tagUnitMap = <?=json_encode($unitMap, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?>;
const tagUnitMap = window.tagUnitMap;
document.getElementById('tagDepartment')?.addEventListener('change',function(){
 const dept=this.value, sel=document.getElementById('tagUnit'), previous=sel.value;
 const units=tagUnitMap[dept]||[];
 sel.innerHTML='<option value="">เลือกหน่วย</option>';
 units.forEach(function(unit){const o=document.createElement('option');o.value=unit;o.textContent=unit;sel.appendChild(o);});
 if(units.includes(previous)) sel.value=previous;
 if(!units.length){const o=document.createElement('option');o.value='';o.textContent='ไม่มีหน่วยในข้อมูลเดิม';sel.appendChild(o);}
});
</script>
<script>
document.querySelectorAll('input[type=file][name="before_photo[]"],input[type=file][name="after_photo[]"]').forEach(function(inp){
 inp.addEventListener('change',function(){
  const id=inp.name.indexOf('before_photo')===0?'beforePreview':'afterPreview';
  const box=document.getElementById(id); box.innerHTML='';
  const files=Array.from(inp.files||[]);
  if(files.length>10){alert('แนบได้ไม่เกิน 10 รูปต่อช่อง');inp.value='';return;}
  for(const file of files){
   if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>5*1024*1024){alert('ทุกภาพต้องเป็น JPG, PNG หรือ WEBP และมีขนาดไม่เกิน 5 MB');inp.value='';box.innerHTML='';return;}
  }
  files.forEach(function(file){
   const img=document.createElement('img');img.alt='ตัวอย่างรูป';img.className='h-32 w-32 object-cover rounded-lg border bg-white p-1';img.src=URL.createObjectURL(file);box.appendChild(img);
  });
 });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
<script>
(function(){
 const input=document.getElementById('tagSourceImage');
 const readBtn=document.getElementById('tagReadOcr');
 const status=document.getElementById('tagOcrStatus');
 const rawBox=document.getElementById('tagOcrRaw');
 const preview=document.getElementById('tagSourcePreview');
 const duplicate=document.getElementById('tagOcrDuplicate');
 if(!input||!readBtn) return;
 let imageUrl='';
 const knownDepartments=Array.from(document.querySelectorAll('#tagDepartment option')).map(o=>o.value).filter(Boolean);
 const unitMap=window.tagUnitMap||{};
 const knownTags=<?=json_encode(array_map(static function($r){return ['id'=>(int)$r['id'],'tag_no'=>(string)$r['tag_no'],'department'=>(string)$r['department'],'unit_no'=>(string)$r['unit_no']];},$tags), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?>;
 const currentEditId=<?=json_encode((int)$editId)?>;
 input.addEventListener('change',function(){
   preview.innerHTML=''; duplicate.classList.add('hidden');
   const f=input.files&&input.files[0]; if(!f) return;
   if(!['image/jpeg','image/png','image/webp'].includes(f.type)||f.size>5*1024*1024){alert('กรุณาใช้รูป JPG, PNG หรือ WEBP ขนาดไม่เกิน 5 MB');input.value='';return;}
   if(imageUrl) URL.revokeObjectURL(imageUrl); imageUrl=URL.createObjectURL(f);
   const im=document.createElement('img'); im.src=imageUrl; im.alt='ภาพแบบฟอร์ม Tag ต้นฉบับ'; im.style.cssText='max-width:100%;max-height:280px;border:1px solid #cbd5e1;border-radius:10px;background:white;padding:4px'; preview.appendChild(im);
   status.textContent='เลือกรูปแล้ว พร้อมอ่านข้อความ';
 });
 function thaiDigits(s){const th='๐๑๒๓๔๕๖๗๘๙';return String(s||'').replace(/[๐-๙]/g,c=>String(th.indexOf(c)));}
 function normalize(s){return thaiDigits(s).toUpperCase().replace(/[\s\-_.:;,()\[\]{}]/g,'');}
 function findNearby(text, labels, max=80){
   const lines=String(text).split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
   for(let i=0;i<lines.length;i++){
     const ln=normalize(lines[i]);
     if(labels.some(l=>ln.includes(normalize(l)))){
       let result=lines[i];
       if(i+1<lines.length) result+=' '+lines[i+1];
       result=result.replace(/^(?:.*?(?:จุดบกพร่องที่ตรวจพบ|หมายเลข\s*Tag|พื้นที่กลุ่มย่อย|แผนก|วันที่ออก\s*Tag|ติด\s*Tag\s*โดย|ผู้รับ\s*Tag|ข้อเสนอแนะในการดำเนินการ)\s*[:：]?)/i,'').trim();
       result=result.replace(/(?:แผนก|พื้นที่กลุ่มย่อย|หมายเลข\s*Tag|วันที่ออก\s*Tag|ติด\s*Tag\s*โดย|ผู้รับ\s*Tag|ข้อเสนอแนะในการดำเนินการ).*$/i,'').trim();
       if(result && result.length<=max && !/^(?:วันที่|กำหนด|ประเภท|ประจำเดือน)/.test(result)) return result;
     }
   }
   return '';
 }
 function isoDate(raw){
   const m=thaiDigits(raw).match(/(\d{1,2})\s*[\/.-]\s*(\d{1,2})\s*[\/.-]\s*(\d{2,4})/); if(!m)return '';
   let d=Number(m[1]),mo=Number(m[2]),y=Number(m[3]); if(y<100)y+= y>=60?2500:2000; if(y>=2400)y-=543;
   if(mo<1||mo>12||d<1||d>31)return ''; const dt=new Date(Date.UTC(y,mo-1,d)); if(dt.getUTCFullYear()!==y||dt.getUTCMonth()!==mo-1||dt.getUTCDate()!==d)return '';
   return String(y).padStart(4,'0')+'-'+String(mo).padStart(2,'0')+'-'+String(d).padStart(2,'0');
 }
 function setField(name,value){const el=document.querySelector('[name="'+name+'"]');if(el&&value!==undefined&&value!==null&&String(value).trim()!==''){el.value=String(value).trim();el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return true;}return false;}
 function setSelect(el,value){if(!el||!value)return false;let opt=Array.from(el.options).find(o=>normalize(o.value)===normalize(value));if(!opt){opt=new Option(value,value,true,true);el.add(opt);}el.value=opt.value;el.dispatchEvent(new Event('change',{bubbles:true}));return true;}
 function parseTagNo(text){
   const labels=[/หมายเลข\s*tag/i,/หมายเลข\s*tag/i,/tag\s*(?:no\.?|number)/i];
   for(const re of labels){const i=text.search(re);if(i>=0){const part=text.slice(i,i+100);let m=part.match(/(?:หมายเลข\s*tag|tag\s*(?:no\.?|number))[^A-Z0-9]{0,20}([A-Z]{1,6}\s*[-]?\s*\d{1,8}|\d{1,8})/i);if(m)return formatTagNo(m[1]);}}
   return '';
 }
 function formatTagNo(v){let x=String(v||'').toUpperCase().replace(/\s+/g,'').replace(/[^A-Z0-9-]/g,'');if(!x)return '';if(/^\d+$/.test(x))return 'TAG-'+x.padStart(3,'0');if(/^TAG\d+$/.test(x))return 'TAG-'+x.slice(3);return x;}
 function extractDepartment(text){const n=normalize(text);let candidates=knownDepartments.slice().sort((a,b)=>normalize(b).length-normalize(a).length);for(const d of candidates){const nd=normalize(d);if(nd.length>=2&&n.includes(nd))return d;}const aliases={'WHEEL':'WHL','WHEELL':'WHL'};for(const [a,d] of Object.entries(aliases)){if(n.includes(a)&&knownDepartments.some(x=>normalize(x)===normalize(d)))return knownDepartments.find(x=>normalize(x)===normalize(d));}return '';}
 function detectTypeFromImage(file){
   return new Promise(resolve=>{const img=new Image();img.onload=()=>{try{const c=document.createElement('canvas');c.width=900;c.height=Math.round(900*img.height/img.width);const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(img,0,0,c.width,c.height);const w=c.width,h=c.height;
     const ink=(rx,ry,rw,rh)=>{const X=Math.max(0,Math.round(rx*w)),Y=Math.max(0,Math.round(ry*h)),W=Math.max(2,Math.round(rw*w)),H=Math.max(2,Math.round(rh*h));const d=x.getImageData(X,Y,Math.min(W,w-X),Math.min(H,h-Y)).data;let n=0,total=d.length/4;for(let i=0;i<d.length;i+=4){const lum=(d[i]+d[i+1]+d[i+2])/3;if(lum<95)n++;}return n/Math.max(1,total);};
     // The stock PLANT PATROL form puts the Tag White/Red checkboxes on the same row.
     const white=ink(.355,.535,.018,.025),red=ink(.445,.535,.018,.025); if(Math.abs(white-red)>.11)resolve(white>red?'WHITE':'RED');else resolve('');
   }catch(e){resolve('');}};img.onerror=()=>resolve('');img.src=URL.createObjectURL(file);});
 }
 readBtn.addEventListener('click',async function(){
   const f=input.files&&input.files[0];if(!f){alert('กรุณาเลือกรูปแบบฟอร์ม Tag ก่อน');return;}
   if(!window.Tesseract){status.textContent='โหลดเครื่องมืออ่านข้อความไม่สำเร็จ กรุณาตรวจอินเทอร์เน็ต หรือกรอกข้อมูลเองในช่องด้านล่าง';return;}
   readBtn.disabled=true;readBtn.classList.add('opacity-60');status.textContent='กำลังอ่านตัวพิมพ์และลายมือ อาจใช้เวลาสักครู่…';
   try{
     const result=await Tesseract.recognize(f,'tha+eng',{logger:m=>{if(m.status==='recognizing text')status.textContent='กำลังอ่านข้อความ '+Math.round((m.progress||0)*100)+'%';}});
     const text=thaiDigits(result.data.text||'');rawBox.value=text;
     let filled=[];
     const tagNo=parseTagNo(text);if(tagNo&&setField('tag_no',tagNo))filled.push('Tag No.');
     const dept=extractDepartment(text);const deptEl=document.getElementById('tagDepartment');
     if(dept&&setSelect(deptEl,dept)){filled.push('แผนก');const unitEl=document.getElementById('tagUnit');unitEl.innerHTML='<option value="">เลือกหน่วย</option>'; (unitMap[dept]||[]).forEach(u=>unitEl.add(new Option(u,u)));}
     let unit='';const unitMatch=text.match(/(?:พื้นที่\s*กลุ่มย่อย|กลุ่มย่อย|พื้นที่กลุ่ม|unit\s*(?:no\.?)?)\s*[:：#-]?\s*([0-9]{1,4}[A-Z]?)/i);if(unitMatch)unit=unitMatch[1];
     if(!unit){const lines=text.split(/\r?\n/);for(let i=0;i<lines.length;i++){if(/กลุ่มย่อย|พื้นที่/i.test(lines[i])){const m=lines.slice(i,i+2).join(' ').match(/\b(\d{1,4})\b/);if(m){unit=m[1];break;}}}}
     if(unit){const uel=document.getElementById('tagUnit');if(setSelect(uel,unit))filled.push('หน่วย');}
     const dateContext=text.match(/(?:วันที่ออก\s*Tag|วันที่ออก|ออก\s*Tag)[\s\S]{0,100}/i);let dateRaw=dateContext&&dateContext[0].match(/\d{1,2}\s*[\/.-]\s*\d{1,2}\s*[\/.-]\s*\d{2,4}/);if(!dateRaw)dateRaw=text.match(/\d{1,2}\s*[\/.-]\s*\d{1,2}\s*[\/.-]\s*\d{2,4}/);
     const dateValue=dateRaw?isoDate(dateRaw[0]):'';if(dateValue&&setField('tag_date',dateValue))filled.push('วันที่รับ Tag');
     const dueContext=text.match(/(?:วันที่คาดว่าจะแล้วเสร็จ|กำหนดปิด|กำหนดเสร็จ)[\s\S]{0,90}/i);const dueRaw=dueContext&&dueContext[0].match(/\d{1,2}\s*[\/.-]\s*\d{1,2}\s*[\/.-]\s*\d{2,4}/);const dueValue=dueRaw?isoDate(dueRaw[0]):'';if(dueValue&&setField('due_date',dueValue))filled.push('กำหนดปิด');
     const checkMarks=Array.from(text.matchAll(/[✓✔☑√]\s*(10|[1-9])(?:\s*[.．])/g)).map(m=>m[1]);if(checkMarks.length){document.querySelectorAll('input[name=\"defect_types[]\"]').forEach(el=>{el.checked=checkMarks.includes(el.value);});filled.push('ประเภทจุดบกพร่องที่ OCR พบเครื่องหมาย (ตรวจยืนยันอีกครั้ง)');}
     const note=findNearby(text,['จุดบกพร่องที่ตรวจพบ','จุดบกพร่องที่ตรวจพบ'],100);if(note&&setField('note',note))filled.push('จุดบกพร่อง');
     const suggestion=findNearby(text,['ข้อเสนอแนะในการดำเนินการ'],180);if(suggestion&&setField('suggestion',suggestion))filled.push('ข้อเสนอแนะ');
     const issued=findNearby(text,['ติด Tag โดย','ติด Tag โดย'],70);if(issued&&setField('issued_by',issued))filled.push('ผู้ติด Tag');
     const receiver=findNearby(text,['ผู้รับ Tag'],70);if(receiver&&setField('receiver',receiver))filled.push('ผู้รับ Tag');
     const type=await detectTypeFromImage(f);if(type){const r=document.querySelector('input[name="tag_type"][value="'+type+'"]');if(r){r.checked=true;filled.push('ประเภท Tag (ตรวจยืนยันอีกครั้ง)');}}
     const found=knownTags.find(t=>Number(t.id)!==Number(currentEditId)&&normalize(t.tag_no)===normalize(tagNo));if(found){duplicate.classList.remove('hidden');duplicate.textContent='พบหมายเลข '+String(found.tag_no)+' อยู่ในระบบแล้ว: '+String(found.department)+' / หน่วย '+String(found.unit_no)+'. หากเป็น Tag เดียวกัน แนะนำกดแก้ไขรายการเดิม ไม่ควรสร้างรายการซ้ำ.';}
     status.textContent='อ่านเสร็จแล้ว เติมข้อมูลได้ '+filled.length+' ช่อง: '+(filled.join(', ')||'ยังไม่พบข้อมูลที่มั่นใจพอ');
     if(filled.length===0)status.textContent+=' — ตรวจข้อความด้านขวาและกรอก/แก้ไขช่องด้วยตนเอง';
   }catch(err){console.error(err);status.textContent='อ่านข้อความไม่สำเร็จ กรุณาลองภาพที่ชัดขึ้น หรือกรอกข้อมูลด้วยตนเอง';}
   finally{readBtn.disabled=false;readBtn.classList.remove('opacity-60');}
 });
})();
</script>
<?php require 'includes/footer.php';?>
