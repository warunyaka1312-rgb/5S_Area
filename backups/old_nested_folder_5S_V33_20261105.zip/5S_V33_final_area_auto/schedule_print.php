<?php
require_once 'config.php';
function thdate($d){if(!$d)return ''; $p=explode('-',$d); if(count($p)!==3)return $d; $y=(int)$p[0]; $y=$y>2400?$y:$y+543; return $p[2].'/'.$p[1].'/'.$y;}
function unit_count($area){return count(array_filter(array_map('trim',explode(',',(string)$area)),fn($x)=>$x!==''));}
function dcls($d){$day=(int)substr((string)$d,-2);return $day===22?'d22':($day===23?'d23':($day===24?'d24':($day===25?'d25':'')));}
function team_cycle_default($month,$year){$offset=(($year-2569)*12)+($month-10);return ($offset%2===0)?'A':'B';}
function setting_get($p,$key,$default=''){ $st=$p->prepare('SELECT value FROM app_settings WHERE key=?');$st->execute([$key]);$v=$st->fetchColumn();return $v===false?$default:$v; }
$p=db();
/* V34 schedule enhancements: status + per-row department/date colors. */
function ensure_schedule_columns($p){
  $cols=[]; foreach($p->query('PRAGMA table_info(audit_plans)') as $c){$cols[$c['name']]=true;}
  $defs=['status'=>"TEXT NOT NULL DEFAULT 'รอตรวจ'",'date_color'=>"TEXT NOT NULL DEFAULT '#ffffff'",'department_color'=>"TEXT NOT NULL DEFAULT '#ffffff'"];
  foreach($defs as $name=>$def){if(!isset($cols[$name]))$p->exec("ALTER TABLE audit_plans ADD COLUMN {$name} {$def}");}
}
ensure_schedule_columns($p);
$month=(int)($_GET['month']??9); $year=(int)($_GET['year']??2569); $size=strtoupper($_GET['size']??'A4'); if(!in_array($size,['A4','A3'],true))$size='A4';
$months=[1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$requestedTeam=strtoupper(trim((string)($_GET['team']??'')));
$activeTeam=in_array($requestedTeam,['A','B'],true)?$requestedTeam:team_cycle_default($month,$year); // Respect the team selected on the planning page; otherwise use the monthly default.
require_once __DIR__.'/includes/auto_schedule_status.php';
try { sync_monthly_audit_plan_statuses($p,$month,$year); } catch(Throwable $syncError) { /* keep print available */ }
$q=$p->prepare('SELECT * FROM audit_plans WHERE active=1 AND month=? AND year=? AND team=? ORDER BY sort_no,id');$q->execute([$month,$year,$activeTeam]);$rows=$q->fetchAll();
$groups=[];$idx=[];foreach($rows as $r){$sort=(int)($r['sort_no']??0);$key='sort:'.$sort;if(!isset($idx[$key])){$idx[$key]=count($groups);$groups[]=['sort_no'=>$sort,'name'=>trim((string)$r['auditor_name']),'rows'=>[]];}if($groups[$idx[$key]]['name']==='' && trim((string)$r['auditor_name'])!=='')$groups[$idx[$key]]['name']=trim((string)$r['auditor_name']);$groups[$idx[$key]]['rows'][]=$r;}
while(count($groups)<20)$groups[]=['sort_no'=>999999+count($groups),'name'=>'','rows'=>[['id'=>0,'auditor_name'=>'','department'=>'','inspection_date'=>'','inspection_time'=>'','area_5s'=>'','unit_count'=>0]]];
$groups=array_slice($groups,0,20);
$teamPeople=0; foreach($groups as $g){ if(trim((string)($g['name']??''))!=='') $teamPeople++; }
$totalUnits=0;foreach($groups as $g)foreach($g['rows'] as $r)$totalUnits+=unit_count($r['area_5s']??'');
$monthName=$months[$month]??'';
require 'includes/header.php';
?>
<style>
*{box-sizing:border-box}
body{font-family:Tahoma,Arial,sans-serif;background:#f1f5f9;color:#102a56;margin:0}
.poster-print{width:100%;max-width:1400px;margin:0 auto;background:#fff;border:1px solid #d7dee8;border-radius:10px;overflow:hidden;box-shadow:0 10px 30px rgba(15,23,42,.10)}
.poster-head{background:linear-gradient(105deg,#ff4d00 0%,#ff6500 58%,#ff9b00 100%);color:#fff;padding:16px 22px 12px;text-align:center}
.poster-title{font-size:24px;font-weight:1000;line-height:1.25}.poster-sub{font-size:13px;font-weight:900;margin-top:5px}.poster-meta{display:flex;justify-content:center;gap:10px;margin-top:9px;flex-wrap:wrap}.pill{background:#fff;color:#173b70;border-radius:999px;padding:5px 15px;font-size:14px;font-weight:950}.pill.dark{background:#173b70;color:#fff}.team-current{font-size:28px!important;padding:9px 28px!important;min-width:150px;text-align:center;background:#fff!important;color:#173b70!important;border:2px solid rgba(255,255,255,.85);box-shadow:0 2px 8px rgba(0,0,0,.18)}
.poster-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:12px;background:#fff}.poster-table th{color:#fff;background:#ff5a00;padding:8px 5px;border:1px solid #fff;font-weight:950;text-align:center}.poster-table td{border:1px solid #9aa9bb;padding:5px 5px;text-align:center;line-height:1.12;vertical-align:middle;background:#fff}.poster-table .nm,.poster-table .dp,.poster-table .area{text-align:left}.poster-table .nm{font-weight:900;color:#173b70;background:#fff;border-top-color:transparent!important;border-bottom-color:transparent!important}.poster-table .no{width:5%}.poster-table .nm{width:23%}.poster-table .dp{width:16%}.poster-table .date{width:13%}.poster-table .time{width:13%}.poster-table .area{width:24%}.poster-table .unit{width:5%;font-weight:950;color:#173b70}.poster-table .status{width:11%;font-weight:900}.status{font-size:14px!important;font-weight:1000!important;padding:7px 6px!important;text-align:center;white-space:nowrap;border-radius:6px}.status.wait{background:#fff7ed!important;color:#9a3412!important;border:2px solid #fdba74!important}.status.postpone{background:#fff1f2!important;color:#be123c!important;border:2px solid #fda4af!important}.status.done{background:#ecfdf5!important;color:#166534!important;border:2px solid #86efac!important}.status.partial{background:#fff7ed!important;color:#9a3412!important;border:2px solid #fdba74!important}
.stack{display:flex;flex-direction:column;gap:3px}.stack>div,.stack>b{min-height:19px;line-height:19px}.d22{background:#f8dced!important}.d23{background:#cfeaf8!important}.d24{background:#d8f4d2!important}.d25{background:#e7daf5!important}.poster-table td.no,.poster-table td.nm{background:#fff!important}
.poster-total{display:grid;grid-template-columns:1fr 90px;background:#ffd98a;border:1px solid #ff9b00;border-top:2px solid #ff6500;font-size:18px;font-weight:1000;color:#111827}.poster-total .label{padding:9px;text-align:center}.poster-total .value{padding:9px;text-align:center;border-left:1px solid #ff9b00}
.print-actions{display:flex;justify-content:flex-end;gap:7px;flex-wrap:wrap;margin-bottom:10px}.pa{border:0;border-radius:8px;padding:8px 12px;font-weight:900;cursor:pointer;text-decoration:none;display:inline-block}.pa.blue{background:#1677e8;color:#fff}.pa.orange{background:#ff5a00;color:#fff}.pa.green{background:#0b9b58;color:#fff}
@media print{
 @page{size:<?=$size==='A3'?'A3':'A4'?> landscape;margin:5mm}
 body{background:#fff!important}.no-print,.sidebar,.topbar,.footer{display:none!important}.main{margin:0!important;padding:0!important}
 .poster-print{max-width:none;width:100%;border:1px solid #111;border-radius:0;box-shadow:none}
 .poster-head{padding:8px 12px 7px}.poster-title{font-size:18px}.team-current{font-size:16px!important;padding:4px 14px!important;min-width:90px}.poster-sub{font-size:9px;margin-top:3px}.poster-meta{margin-top:5px;gap:6px}.pill{font-size:9px;padding:3px 9px}
 .poster-table{font-size:8px}.poster-table th{padding:4px 2px;font-size:8px}.poster-table td{padding:3px 2px}.poster-table .status{font-size:8px!important;padding:3px 2px!important}.stack{gap:1px}.stack>div,.stack>b{min-height:14px;line-height:14px}.poster-total{font-size:11px;grid-template-columns:1fr 55px}.poster-total .label,.poster-total .value{padding:5px}
}
</style>
<div class="no-print print-actions"><a class="pa blue" href="schedule_manage.php?month=<?=$month?>&year=<?=$year?>&team=<?=h($activeTeam)?>">✏️ กลับหน้าแก้ไข</a><button class="pa orange" onclick="window.print()">🖨 พิมพ์ <?=$size?></button><button class="pa green" onclick="downloadPoster()">🖼️ บันทึก PNG</button></div>
<div class="poster-print" id="posterPrint">
  <div class="poster-head"><div class="poster-title">📅 แผนการตรวจ 5 ส. ประจำเดือน <?=$monthName?> <?=$year?></div><div class="poster-sub">รายชื่อทีมตรวจ <?=$teamPeople?> คน • แผนกและหน่วยพื้นที่ 5 ส. แยกตามทีม • สลับชุด A/B เดือนละ 1 ครั้ง</div><div class="poster-meta"><span class="pill team-current">ทีม <?=$activeTeam?></span><span class="pill">ทีมตรวจ <?=$teamPeople?> คน</span><span class="pill">รวม <?=$totalUnits?> หน่วย</span></div></div>
  <table class="poster-table"><thead><tr><th class="no">ลำดับ</th><th class="nm">ชื่อ - สกุล (ทีมตรวจ)</th><th class="dp">แผนก</th><th class="date">วันที่ตรวจ</th><th class="time">เวลา</th><th class="area">หน่วยพื้นที่ 5 ส.</th><th class="unit">หน่วย</th><th class="status">สถานะ</th></tr></thead><tbody>
  <?php foreach($groups as $gi=>$g):$grows=$g['rows'];$first=$grows[0];$date=$first['inspection_date']??'';$time=$first['inspection_time']??'';$dc=dcls($date);$dateColor=$first['date_color']??'#ffffff';if(!preg_match('/^#[0-9a-fA-F]{6}$/',$dateColor))$dateColor='#ffffff';$allowedStatuses=['รอตรวจ','เลื่อนการตรวจ','ตรวจบางส่วน','ตรวจแล้ว'];$statusCounts=['รอตรวจ'=>0,'เลื่อนการตรวจ'=>0,'ตรวจบางส่วน'=>0,'ตรวจแล้ว'=>0];foreach($grows as $sr){$sv=trim((string)($sr['status']??''));if(isset($statusCounts[$sv]))$statusCounts[$sv]++;}arsort($statusCounts);$status=(string)array_key_first($statusCounts);if($statusCounts[$status]===0)$status='รอตรวจ';$statusClass=$status==='ตรวจแล้ว'?'done':($status==='ตรวจบางส่วน'?'partial':($status==='เลื่อนการตรวจ'?'postpone':'wait'));?>
    <tr>
      <td><?=($gi+1)?></td>
      <td class="nm"><?=h($g['name'])?></td>
      <td class="dp <?=$dc?>"><div class="stack"><?php foreach($grows as $r):?><div style="background:<?=h($r['department_color']??'#ffffff')?>;padding:2px 3px;border-radius:3px"><?=h($r['department']??'')?></div><?php endforeach;?></div></td>
      <td class="<?=$dc?>" style="background:<?=h($dateColor)?>!important"><?=h(thdate($date))?></td>
      <td class="<?=$dc?>" style="background:<?=h($dateColor)?>!important"><?=h($time)?></td>
      <td class="area <?=$dc?>"><div class="stack"><?php foreach($grows as $r):?><div><?=h($r['area_5s']??'')?></div><?php endforeach;?></div></td>
      <td><div class="stack"><?php foreach($grows as $r):?><b><?=unit_count($r['area_5s']??'')?></b><?php endforeach;?></div></td>
      <td class="status <?=$statusClass?>"><?=$status?></td>
    </tr>
  <?php endforeach;?></tbody></table>
  <div class="poster-total"><div class="label">รวมหน่วยพื้นที่ 5 ส.</div><div class="value"><?=$totalUnits?></div></div>
</div>
<script>
async function downloadPoster(){if(typeof html2canvas==='undefined'){alert('ยังไม่ได้โหลดตัวสร้างรูป');return;}try{const c=await html2canvas(document.getElementById('posterPrint'),{scale:2,backgroundColor:'#fff',useCORS:true,logging:false});const a=document.createElement('a');a.download='5S_Schedule_<?=$month?>_<?=$year?>_Team<?=$activeTeam?>.png';a.href=c.toDataURL('image/png');a.click();}catch(e){alert('สร้างรูปไม่สำเร็จ กรุณาใช้ปุ่มพิมพ์แทน');}}
</script><script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<?php require 'includes/footer.php';?>
