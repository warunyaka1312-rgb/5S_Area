<?php
require_once 'config.php';

$department = $_GET['department'] ?? 'Production';
$view = $_GET['view'] ?? 'month';
$month = $_GET['month'] ?? 'กันยายน';
$yearInput = (int)($_GET['year'] ?? date('Y'));
$chart = $_GET['chart'] ?? 'split';
$size = strtoupper($_GET['size'] ?? 'A4');

if (!in_array($department, ['Production','Office'], true)) $department = 'Production';
if (!in_array($size, ['A4','A3'], true)) $size = 'A4';
if (!in_array($chart, ['split','unit','group'], true)) $chart = 'split';

$yearDb = $yearInput >= 2400 ? $yearInput - 543 : $yearInput;
$thaiYear = $yearDb + 543;
$target = target_pct($department);

$months = [
    'มกราคม'=>1,'กุมภาพันธ์'=>2,'มีนาคม'=>3,'เมษายน'=>4,
    'พฤษภาคม'=>5,'มิถุนายน'=>6,'กรกฎาคม'=>7,'สิงหาคม'=>8,
    'กันยายน'=>9,'ตุลาคม'=>10,'พฤศจิกายน'=>11,'ธันวาคม'=>12
];
$monthNo = $months[$month] ?? (int)date('n');

if ($view === 'year') {
    $start = sprintf('%04d-01-01', $yearDb);
    $end = sprintf('%04d-12-31', $yearDb);
    $periodLabel = 'ปี ' . $thaiYear;
} else {
    $start = sprintf('%04d-%02d-01', $yearDb, $monthNo);
    $end = date('Y-m-t', strtotime($start));
    $periodLabel = ($month ?: array_search($monthNo, $months, true)) . ' ' . $thaiYear;
}

$scoreTable = $department === 'Office' ? 'office_scores' : 'scores';
$critTable  = $department === 'Office' ? 'office_criteria' : 'criteria';

/*
 * Master area list is the source of truth for group/unit labels.
 * Only active areas belonging to the selected department are considered.
 */
$areasQ = db()->prepare("
    SELECT id, group_name, unit_no, area_name
    FROM areas
    WHERE active=1 AND department=?
    ORDER BY group_name COLLATE NOCASE, CAST(unit_no AS INTEGER), unit_no
");
$areasQ->execute([$department]);
$areas = $areasQ->fetchAll();

$totalActiveAreas = count($areas);

/*
 * Latest audit per active area in the selected period.
 * We intentionally keep the area master rows separate from audit rows,
 * so an unscored/missing unit is never silently lost.
 */
$auditQ = db()->prepare("
    SELECT au.id, au.area_id, au.audit_date, au.created_at, au.updated_at
    FROM audits au
    WHERE au.department=? AND au.audit_date BETWEEN ? AND ?
    ORDER BY au.audit_date DESC, au.id DESC
");
$auditQ->execute([$department, $start, $end]);

$latestAuditByArea = [];
foreach ($auditQ as $ar) {
    $aid = (int)$ar['area_id'];
    if (!isset($latestAuditByArea[$aid])) {
        $latestAuditByArea[$aid] = $ar;
    }
}

$summaryFn = $department === 'Office' ? 'office_audit_summary' : 'production_audit_summary';
$unitRows = [];
$missingUnits = [];

foreach ($areas as $area) {
    $areaId = (int)$area['id'];

    $group = display_area_group((string)$area['group_name']);
    if ($group === '') $group = trim((string)$area['group_name']);
    if ($group === '') $group = 'ไม่ระบุกลุ่ม';

    $unit = trim((string)$area['unit_no']);
    if ($unit === '') {
        $displayName = trim((string)$area['area_name']);
        if ($displayName === '') $displayName = $group;
    } else {
        // รายงานกราฟให้ใช้รูปแบบเดียวกันทุกหน่วย: กลุ่ม - หน่วย XX
        $displayName = $group . ' - หน่วย ' . $unit;
    }

    if (!isset($latestAuditByArea[$areaId])) {
        $missingUnits[] = $displayName;
        continue;
    }

    $audit = $latestAuditByArea[$areaId];
    $sum = $summaryFn(db(), (int)$audit['id']);

    /* An audit with no answered scored item is treated as missing score. */
    if (($sum['max'] ?? 0) <= 0) {
        $missingUnits[] = $displayName;
        continue;
    }

    $unitRows[] = [
        'group' => $group,
        'unit' => $unit,
        'area' => trim((string)$area['area_name']),
        'label' => $displayName,
        'pct' => round((float)$sum['pct'], 2),
        'audit_id' => (int)$audit['id'],
        'audit_date' => (string)$audit['audit_date'],
        'answered' => (int)($sum['answered'] ?? 0)
    ];
}

/* All scored units: below target first, then passing, each low-to-high. */
$belowRows = array_values(array_filter($unitRows, fn($r) => (float)$r['pct'] < (float)$target));
$passRows  = array_values(array_filter($unitRows, fn($r) => (float)$r['pct'] >= (float)$target));
$sortRows = function (&$rows): void {
    usort($rows, function($a,$b) {
        $cmp = ((float)$a['pct'] <=> (float)$b['pct']);
        return $cmp !== 0 ? $cmp : strnatcasecmp((string)$a['label'], (string)$b['label']);
    });
};
$sortRows($belowRows);
$sortRows($passRows);

$avg = count($unitRows) ? round(array_sum(array_column($unitRows,'pct')) / count($unitRows), 2) : 0;
$passed = count($passRows);
$below = count($belowRows);
$missingCount = count($missingUnits);

/* Optional grouped view remains available, but the main/print path is split unit view. */
$groupRows = [];
if ($chart === 'group') {
    $groups = [];
    foreach ($unitRows as $r) {
        $g = $r['group'];
        if (!isset($groups[$g])) $groups[$g] = ['sum'=>0,'n'=>0];
        $groups[$g]['sum'] += (float)$r['pct'];
        $groups[$g]['n']++;
    }
    foreach ($groups as $g=>$x) {
        $groupRows[] = [
            'label'=>$g,
            'pct'=>$x['n'] ? round($x['sum']/$x['n'],2) : 0,
            'unitCount'=>$x['n']
        ];
    }
    $belowGroup = array_values(array_filter($groupRows, fn($r)=>(float)$r['pct']<(float)$target));
    $passGroup = array_values(array_filter($groupRows, fn($r)=>(float)$r['pct']>=(float)$target));
    $sortRowsGroup=function (&$rows):void{
        usort($rows,function($a,$b){
            $cmp=((float)$a['pct']<=>(float)$b['pct']);
            return $cmp!==0?$cmp:strnatcasecmp($a['label'],$b['label']);
        });
    };
    $sortRowsGroup($belowGroup); $sortRowsGroup($passGroup);
}

$title = 'คะแนน 5 ส. — ' . $department . ' / ' . $periodLabel;
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=h($title)?></title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<style>
*{box-sizing:border-box}
:root{--orange:#ff5a00;--navy:#0b1220;--ink:#172238;--muted:#64748b;--line:#dbe3ee;--good:#16a34a;--bad:#dc2626;--warn:#ff5a00}
html,body{margin:0;padding:0;background:#eef3f8;color:var(--ink);font-family:Tahoma,"Noto Sans Thai",Arial,sans-serif}
.sheet{width:100%;min-height:100vh;background:#fff;margin:0 auto;padding:9mm 12mm 7mm}
.top{display:flex;align-items:flex-start;justify-content:space-between;gap:12mm;border-bottom:4px solid var(--orange);padding-bottom:4.5mm;margin-bottom:4.5mm}
.brand{font-size:21pt;font-weight:900;white-space:nowrap}.brand span{color:var(--orange)}
.title{font-size:23pt;font-weight:900;text-align:right;line-height:1.2}.subtitle{font-size:10.5pt;color:var(--muted);margin-top:2mm;text-align:right}
.badges{display:flex;gap:3.5mm;margin-bottom:4mm;flex-wrap:wrap}.badge{border:1px solid var(--line);border-radius:10px;padding:2.2mm 4.5mm;background:#f8fafc;font-size:10pt;font-weight:800}.badge strong{font-size:14pt;margin-left:2mm}.badge.good strong{color:var(--good)}.badge.bad strong{color:var(--bad)}.badge.target{border-color:#ffd7bf;background:#fff7f1}.badge.target strong{color:var(--orange)}
.chart-card{border:1px solid var(--line);border-radius:14px;padding:4mm 5mm;margin-bottom:6mm;background:#fff;break-inside:avoid}
.chart-head{display:flex;justify-content:space-between;align-items:flex-start;gap:8mm;margin-bottom:2mm}.chart-head h2{font-size:18pt;margin:0;font-weight:900}.chart-head p{margin:1mm 0 0;color:var(--muted);font-size:10.5pt}
.chart-wrap{position:relative;width:100%;height:calc(max(300px, var(--bars, 10) * 26px + 100px))}
.chart-wrap canvas{width:100%!important;height:100%!important}
.charts-grid{display:block}
.missing{border:1px solid #fecaca;background:#fff7f7;border-radius:12px;padding:3mm 4mm;margin:4mm 0 6mm}.missing h3{margin:0 0 2mm;color:var(--bad);font-size:13pt}.missing-list{font-size:10pt;line-height:1.8;color:#7f1d1d}
.note{font-size:9.5pt;color:var(--muted);margin-top:2mm}
.footer{display:flex;justify-content:space-between;border-top:1px solid var(--line);margin-top:3.5mm;padding-top:2.5mm;color:var(--muted);font-size:8.8pt}
.actions{position:fixed;right:12px;top:12px;z-index:99;display:flex;gap:7px}.actions button,.actions a{background:#fff;border:1px solid #cbd5e1;border-radius:9px;padding:9px 12px;font-weight:800;color:var(--ink);text-decoration:none;cursor:pointer}.actions button:hover,.actions a:hover{border-color:var(--orange);color:var(--orange)}
@page A4Landscape{size:A4 landscape;margin:0}
@page A3Landscape{size:A3 landscape;margin:0}
body.a4{page:A4Landscape} body.a3{page:A3Landscape}
/* Capture/print is composed as one landscape sheet with the two score charts side by side. */
body.capture-a3{width:420mm;background:#fff;overflow:hidden}
body.capture-a3 .sheet{width:420mm;height:297mm;min-height:297mm;padding:5mm 6mm 4mm;overflow:hidden;display:flex;flex-direction:column}
body.capture-a3 .charts-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:3mm;align-items:stretch;flex:1 1 0;height:0;min-height:0;overflow:hidden}
body.capture-a3 .chart-card{height:100%;margin:0;min-width:0;min-height:0;display:flex;flex-direction:column;overflow:hidden;padding:2mm 2.5mm;break-inside:avoid}
body.capture-a3 .chart-wrap{width:100%;height:auto!important;min-height:0!important;flex:1 1 0;overflow:hidden}
body.capture-a3 .chart-wrap canvas{display:block;width:100%!important;height:100%!important}
body.capture-a3 .top{gap:6mm;padding-bottom:2.5mm;margin-bottom:2.5mm;border-bottom-width:1mm}
body.capture-a3 .brand{font-size:18pt} body.capture-a3 .title{font-size:20pt} body.capture-a3 .subtitle{font-size:8pt}
body.capture-a3 .badges{gap:1.5mm;margin-bottom:2mm;flex-wrap:nowrap}
body.capture-a3 .badge{font-size:7pt;padding:1mm 2mm;border-radius:2mm;white-space:nowrap}
body.capture-a3 .badge strong{font-size:9pt}
body.capture-a3 .missing{flex:0 0 auto;max-height:17mm;padding:1.5mm 2mm;margin:1mm 0 2mm;border-radius:2mm;overflow:hidden}
body.capture-a3 .missing h3{font-size:7.5pt;margin-bottom:1mm} body.capture-a3 .missing-list{font-size:6.5pt;line-height:1.15;max-height:9mm;overflow:hidden}
body.capture-a3 .chart-head{margin-bottom:1.5mm;gap:2mm} body.capture-a3 .chart-head h2{font-size:14pt;font-weight:900} body.capture-a3 .chart-head p{font-size:9pt;font-weight:700}
body.capture-a3 .note{font-size:7pt;font-weight:700;margin-top:1mm}
body.capture-a3 .footer{margin-top:1.5mm;padding-top:1mm;font-size:6pt}
@media print{
  html,body{background:#fff!important;width:100%;height:100%;margin:0;padding:0}
  .actions{display:none!important}
  .sheet{width:100%;height:100vh;min-height:0;margin:0;box-shadow:none;overflow:hidden;display:flex;flex-direction:column;padding:4mm 5mm 3mm}
  body.a3 .sheet{width:420mm;height:297mm;min-height:297mm;padding:5mm 6mm 4mm}
  body.a4 .sheet{width:297mm;height:210mm;min-height:210mm;padding:3mm 4mm 2mm}
  .top{flex:0 0 auto;gap:6mm;padding-bottom:2.5mm;margin-bottom:2.5mm;border-bottom-width:1mm}
  body.a3 .brand{font-size:18pt} body.a3 .title{font-size:20pt} body.a3 .subtitle{font-size:8pt}
  body.a4 .brand{font-size:12pt} body.a4 .title{font-size:13pt} body.a4 .subtitle{font-size:6pt}
  .badges{flex:0 0 auto;gap:1.5mm;margin-bottom:2mm;flex-wrap:nowrap}
  .badge{font-size:7pt;padding:1mm 2mm;border-radius:2mm;white-space:nowrap}
  .badge strong{font-size:9pt}
  body.a4 .badge{font-size:5.5pt;padding:.6mm 1mm} body.a4 .badge strong{font-size:7pt}
  .missing{flex:0 0 auto;max-height:17mm;padding:1.5mm 2mm;margin:1mm 0 2mm;border-radius:2mm;break-inside:avoid;overflow:hidden}
  .missing h3{font-size:7.5pt;margin-bottom:1mm} .missing-list{font-size:6.5pt;line-height:1.15;max-height:9mm;overflow:hidden}
  body.a4 .missing h3{font-size:6pt} body.a4 .missing-list{font-size:5pt}
  .charts-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:3mm;align-items:stretch;flex:1 1 0;height:0;min-height:0;overflow:hidden}
  .chart-card{height:100%;break-inside:avoid;break-after:auto!important;page-break-after:auto!important;margin:0;min-width:0;min-height:0;padding:2mm 2.5mm;display:flex;flex-direction:column;overflow:hidden}
  .chart-head{flex:0 0 auto;gap:2mm;margin-bottom:1mm}
  .chart-head h2{font-size:14pt;font-weight:900;margin:0} .chart-head p{font-size:9pt;font-weight:700;margin-top:.7mm}
  body.a4 .chart-head h2{font-size:10pt} body.a4 .chart-head p{font-size:7pt}
  .chart-wrap{width:100%;height:auto!important;min-height:0!important;flex:1 1 0;overflow:hidden}
  .chart-wrap canvas{display:block;width:100%!important;height:100%!important}
  .note{font-size:7pt;font-weight:700;margin-top:1mm;flex:0 0 auto}
  body.a4 .note{font-size:6pt}
  body.a4 .missing{max-height:13mm} body.a4 .missing-list{max-height:6mm;font-size:5pt}
  .footer{flex:0 0 auto;margin-top:1.5mm;padding-top:1mm;font-size:6pt}
  .chart-card:only-child{grid-column:1/-1}
}
</style>
</head>
<body class="<?=strtolower($size)?>">
<div class="actions no-print">
  <button onclick="preparePrint()">🖨 พิมพ์ <?=$size?></button>
  <?php if($size==='A4'): ?><a target="_blank" href="?department=<?=urlencode($department)?>&view=<?=urlencode($view)?>&month=<?=urlencode($month)?>&year=<?=$yearInput?>&chart=split&size=A3">📄 A3</a><?php else: ?><a target="_blank" href="?department=<?=urlencode($department)?>&view=<?=urlencode($view)?>&month=<?=urlencode($month)?>&year=<?=$yearInput?>&chart=split&size=A4">📄 A4</a><?php endif; ?>
  <?php if($chart==='group'): ?><a href="?department=<?=urlencode($department)?>&view=<?=urlencode($view)?>&month=<?=urlencode($month)?>&year=<?=$yearInput?>&chart=split&size=<?=$size?>">📊 รายหน่วย</a><?php else: ?><a href="?department=<?=urlencode($department)?>&view=<?=urlencode($view)?>&month=<?=urlencode($month)?>&year=<?=$yearInput?>&chart=group&size=<?=$size?>">📊 รายกลุ่ม</a><?php endif; ?>
  <button onclick="downloadAllPNG()">⬇ PNG</button>
  <button onclick="saveFullPagePNG()">📸 บันทึกภาพทั้งหน้า</button>
</div>

<div class="sheet">
  <div class="top">
    <div>
      <div class="brand">5S <span>SMART | ALUMET</span></div>
      <div class="subtitle" style="text-align:left">ระบบประเมินมาตรฐานกิจกรรม 5 ส.</div>
    </div>
    <div>
      <div class="title"><?=h($title)?></div>
      <div class="subtitle">ข้อมูลจากฐานข้อมูลจริง • ชื่อหน่วยจาก Master • ✓ ผ่าน / ✗ ต่ำกว่าเป้าหมาย</div>
    </div>
  </div>

  <div class="badges">
    <div class="badge">หน่วยทั้งหมด <strong><?=$totalActiveAreas?></strong></div>
    <div class="badge">มีคะแนน <strong><?=count($unitRows)?></strong></div>
    <div class="badge bad">ยังไม่มีคะแนน <strong><?=$missingCount?></strong></div>
    <div class="badge good">ผ่านเป้าหมาย <strong><?=$passed?></strong></div>
    <div class="badge bad">ต่ำกว่าเป้าหมาย <strong><?=$below?></strong></div>
    <div class="badge">คะแนนเฉลี่ย <strong><?=number_format($avg,2)?>%</strong></div>
    <div class="badge target">เป้าหมาย <strong><?=number_format($target,1)?>%</strong></div>
  </div>

<?php if ($missingCount): ?>
  <div class="missing">
    <h3>หน่วยที่ยังไม่มีคะแนนในช่วงเวลานี้ (ไม่ถูกนำไปคำนวณคะแนน)</h3>
    <div class="missing-list"><?=h(implode(' • ', $missingUnits))?></div>
  </div>
<?php endif; ?>

<?php
$chartSets=[];
if($chart==='group'){
    $chartSets=[['key'=>'group_below','title'=>'กราฟคะแนนรายกลุ่ม • ต่ำกว่าเป้าหมาย','rows'=>$belowGroup,'color'=>'bad'],
                ['key'=>'group_pass','title'=>'กราฟคะแนนรายกลุ่ม • ผ่านเป้าหมาย','rows'=>$passGroup,'color'=>'good']];
} else {
    $chartSets=[['key'=>'unit_below','title'=>'กราฟคะแนนรายหน่วย • ต่ำกว่าเป้าหมาย','rows'=>$belowRows,'color'=>'bad'],
                ['key'=>'unit_pass','title'=>'กราฟคะแนนรายหน่วย • ผ่านเป้าหมาย','rows'=>$passRows,'color'=>'good']];
}
$chartIndex=0;
$maxChartBars = max(1, count($chartSets[0]['rows']), count($chartSets[1]['rows']));
?>
<div class="charts-grid">
<?php foreach($chartSets as $set):
    if(!$set['rows']) continue;
    $countBars=count($set['rows']);
    /* Give both split charts the same plot height so both occupy the single landscape page evenly. */
    $payload = [
        'labels'=>array_map(function($r) use ($chart){
            if($chart==='group') return [$r['label'], 'จำนวนหน่วย '.$r['unitCount']];
            $group = trim((string)$r['group']);
            $unit = trim((string)$r['unit']);
            $full = trim((string)$r['label']);
            // Keep the standard group + unit label; wrap only long group names to avoid clipping.
            if ($unit !== '' && function_exists('mb_strlen') && mb_strlen($group, 'UTF-8') > 22) {
                return [$group, 'หน่วย '.$unit];
            }
            return [$full];
        }, $set['rows']),
        'values'=>array_map(fn($r)=>(float)$r['pct'],$set['rows']),
        'target'=>(float)$target,
        'department'=>$department,
        'period'=>$periodLabel,
        'count'=>$countBars,
        'type'=>$set['color']
    ];
    $payloadJson=json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
?>
  <div class="chart-card">
    <div class="chart-head">
      <div>
        <h2><?=h($set['title'])?></h2>
        <p><?=h($department.' • '.$periodLabel.' • เรียงคะแนนน้อย → มาก • 1 แท่ง = 1 '.($chart==='group'?'กลุ่ม':'หน่วย'))?></p>
      </div>
    </div>
    <div class="chart-wrap" style="--bars: <?=$countBars?>"><canvas id="chart<?=$chartIndex?>"></canvas></div>
    <div class="note">เส้นประสีแดง = เป้าหมาย <?=number_format($target,1)?>% • ชื่อหน่วยใช้จาก Master โดยตรง</div>
    <script>
    (function(){
      const P=<?=$payloadJson?>, c=document.getElementById('chart<?=$chartIndex?>');
      const valueColor=P.type==='good'?'rgba(22,163,74,.88)':'rgba(220,38,38,.88)';
      const borderColor=P.type==='good'?'#16a34a':'#dc2626';
      const barSize=P.count<=10?30:(P.count<=18?24:20);
      const screenTickSize=P.count<=18?15:13;
      const vText=v=>v.toFixed(2)+'%';
      const scoreLabelPlugin={id:'scoreLabels<?=$chartIndex?>',afterDatasetsDraw(chart){
        const meta=chart.getDatasetMeta(0),ds=chart.data.datasets[0],ctx=chart.ctx;
        const mode=window.__fiveSOutputMode||'screen';
        const labelFont=mode==='A3'?(P.count>30?15:(P.count>18?16:18)):mode==='A4'?(P.count>20?11:13):14;
        const reserve=mode==='A3'?86:(mode==='A4'?68:78);
        meta.data.forEach((bar,i)=>{
          const text=vText(Number(ds.data[i]));
          const x=Math.min(bar.x+7,chart.chartArea.right-reserve);
          ctx.save();ctx.font='800 '+labelFont+'px Tahoma,Arial,sans-serif';ctx.fillStyle='#111827';ctx.textAlign='left';ctx.textBaseline='middle';ctx.lineJoin='round';ctx.lineWidth=3;ctx.strokeStyle='rgba(255,255,255,.96)';ctx.strokeText(text,x,bar.y);ctx.fillText(text,x,bar.y);ctx.restore();
        });
      }};
      const chartInstance=new Chart(c,{type:'bar',data:{labels:P.labels,datasets:[
        {label:'คะแนน %',data:P.values,backgroundColor:valueColor,borderColor:borderColor,borderWidth:1,borderRadius:7,barThickness:barSize,maxBarThickness:barSize},
        {type:'line',label:'เป้าหมาย '+P.target+'%',data:P.values.map(()=>P.target),borderColor:'#ef4444',borderDash:[9,6],borderWidth:3,pointRadius:0,fill:false}
      ]},options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,animation:false,scales:{
        x:{min:0,max:100,grid:{color:'rgba(148,163,184,.22)'},ticks:{font:{size:13,weight:'700'},callback:v=>v+'%'},title:{display:true,text:'คะแนน (%)',font:{size:14,weight:'800'}}},
        y:{grid:{display:false},ticks:{font:{size:screenTickSize,weight:'800'},padding:P.count<=18?8:4},afterFit:axis=>{const mode=window.__fiveSOutputMode||'screen';axis.width=mode==='A3'?290:(mode==='A4'?220:280);}}
      },plugins:{
        legend:{position:'top',labels:{font:{size:14,weight:'800'},usePointStyle:true,boxWidth:16,padding:14}},
        tooltip:{callbacks:{
          title:items=>{const l=items[0].label;return Array.isArray(l)?l.join(' / '):l},
          label:c=>c.datasetIndex===1?' เป้าหมาย '+P.target+'%':' คะแนน '+Number(c.parsed.x).toFixed(2)+'%'
        }}
      },layout:{padding:{left:5,right:84,top:4,bottom:4}}},plugins:[scoreLabelPlugin]});
      window.__fiveSGraphCharts=window.__fiveSGraphCharts||[];
      window.__fiveSGraphCharts.push({chart:chartInstance,count:P.count,screenBarSize:barSize,screenTickSize:screenTickSize});
    })();
    </script>
  </div>
<?php $chartIndex++; endforeach; ?>
</div>

<?php if(!$chartSets[0]['rows'] && !$chartSets[1]['rows']): ?>
  <div class="chart-card"><div class="chart-head"><h2>ยังไม่มีข้อมูลคะแนนในช่วงเวลาที่เลือก</h2></div></div>
<?php endif; ?>

  <div class="footer"><span>5S SMART SCORE SYSTEM | ALUMET</span><span><?=date('d/m/Y H:i')?></span></div>
</div>
<script>
function canvasWithHeading(source,title,subtitle=''){
  if(!source || !source.width || !source.height) throw new Error('ไม่พบภาพกราฟ');
  const out=document.createElement('canvas');
  const w=source.width, pad=Math.max(18,Math.round(w*0.024));
  const titleSize=Math.max(19,Math.min(34,Math.round(w/34)));
  const subSize=Math.max(12,Math.min(21,Math.round(w/58)));
  const measure=document.createElement('canvas').getContext('2d');
  const maxW=w-pad*2;
  const wrap=(text,font)=>{
    measure.font=font; const lines=[]; let line='';
    String(text||'').split(/\s+/).forEach(word=>{
      const candidate=line?line+' '+word:word;
      if(line && measure.measureText(candidate).width>maxW){lines.push(line);line=word;}else{line=candidate;}
    });
    if(line)lines.push(line); return lines;
  };
  const titleLines=wrap(title,'900 '+titleSize+'px Tahoma, Arial, sans-serif');
  const subLines=subtitle?wrap(subtitle,'600 '+subSize+'px Tahoma, Arial, sans-serif'):[];
  const titleLineH=Math.round(titleSize*1.25), subLineH=Math.round(subSize*1.35);
  const headH=Math.max(82,18+titleLines.length*titleLineH+(subLines.length?8+subLines.length*subLineH:0)+20);
  out.width=w;out.height=source.height+headH;
  const ctx=out.getContext('2d');
  ctx.fillStyle='#ffffff';ctx.fillRect(0,0,out.width,out.height);
  ctx.fillStyle='#ff5a00';ctx.fillRect(0,0,out.width,9);
  ctx.fillStyle='#13213a';ctx.textBaseline='top';ctx.font='900 '+titleSize+'px Tahoma, Arial, sans-serif';
  let y=17;titleLines.forEach(line=>{ctx.fillText(line,pad,y,maxW);y+=titleLineH;});
  if(subLines.length){y+=4;ctx.fillStyle='#64748b';ctx.font='600 '+subSize+'px Tahoma, Arial, sans-serif';subLines.forEach(line=>{ctx.fillText(line,pad,y,maxW);y+=subLineH;});}
  ctx.strokeStyle='#dbe3ee';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(pad,headH-4);ctx.lineTo(w-pad,headH-4);ctx.stroke();
  ctx.drawImage(source,0,headH);
  return out;
}

function downloadAllPNG(){
  const cards=[...document.querySelectorAll('.chart-card')];
  if(!cards.length){alert('ไม่พบกราฟสำหรับบันทึก');return;}
  let index=0;
  cards.forEach(card=>{
    const source=card.querySelector('.chart-wrap canvas');
    if(!source)return;
    const h=card.querySelector('.chart-head h2');
    const p=card.querySelector('.chart-head p');
    const title=h?h.textContent.trim():('กราฟ '+(index+1));
    const subtitle=p?p.textContent.trim():'';
    try{
      const image=canvasWithHeading(source,title,subtitle);
      const a=document.createElement('a');a.href=image.toDataURL('image/png',1);
      a.download='5S_<?=$department?>_<?=$thaiYear?>_กราฟ_'+(index+1)+'_พร้อมหัวข้อ.png';
      document.body.appendChild(a);a.click();a.remove();index++;
    }catch(e){alert('ไม่สามารถบันทึกกราฟพร้อมหัวข้อได้: '+e.message);}
  });
}
function setGraphOutputLayout(mode){
  window.__fiveSOutputMode=mode;
  (window.__fiveSGraphCharts||[]).forEach(item=>{
    const c=item.chart, n=item.count;
    if(!c || !c.data.datasets[0]) return;
    // Fit both split charts to the remaining landscape-page height; reduce bars when a chart has many units.
    const bar = mode==='A3' ? (n<=12?24:(n<=24?18:(n<=36?14:12))) : mode==='A4' ? (n<=10?14:(n<=20?11:9)) : item.screenBarSize;
    c.data.datasets[0].barThickness=bar;
    c.data.datasets[0].maxBarThickness=bar;
    c.options.scales.y.ticks.font.size=mode==='A3'?(n<=12?17:(n<=24?16:15)):mode==='A4'?(n<=10?12:(n<=20?11:10)):item.screenTickSize;
    c.options.scales.y.ticks.padding=mode==='screen'?(n<=18?8:3):1;
    c.options.scales.y.afterFit=axis=>{axis.width=mode==='A3'?290:(mode==='A4'?220:280);};
    c.options.scales.x.ticks.font.size=mode==='A3'?13:mode==='A4'?10:13;
    c.options.scales.x.title.font.size=mode==='A3'?13:mode==='A4'?10:14;
    c.options.plugins.legend.labels.font.size=mode==='A3'?14:mode==='A4'?10:14;
    c.resize(); c.update('none');
  });
}
function preparePrint(){
  const mode=document.body.classList.contains('a3')?'A3':'A4';
  setGraphOutputLayout(mode);
  requestAnimationFrame(()=>requestAnimationFrame(()=>setTimeout(()=>{
    (window.__fiveSGraphCharts||[]).forEach(item=>{if(item.chart){item.chart.resize();item.chart.update('none');}});
    window.print();
  },120)));
}
window.addEventListener('beforeprint',()=>{
  const mode=document.body.classList.contains('a3')?'A3':'A4';
  setGraphOutputLayout(mode);
});
window.addEventListener('afterprint',()=>setGraphOutputLayout('screen'));
async function saveFullPagePNG(){
  const sheet=document.querySelector('.sheet');
  if(!sheet){ alert('ไม่พบพื้นที่สำหรับบันทึกภาพ'); return; }
  if(typeof html2canvas !== 'function'){
    alert('ไม่พบระบบบันทึกภาพ กรุณาเชื่อมต่ออินเทอร์เน็ตแล้วกด Ctrl+F5');
    return;
  }
  const btn=[...document.querySelectorAll('.actions button')].find(b=>b.textContent.includes('บันทึกภาพทั้งหน้า'));
  const oldText=btn?btn.textContent:'';
  try{
    if(btn){btn.disabled=true;btn.textContent='⏳ กำลังสร้างภาพ A3...';}
    document.body.classList.add('capture-a3');
    setGraphOutputLayout('A3');
    if(document.fonts && document.fonts.ready) await document.fonts.ready;
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    (window.__fiveSGraphCharts||[]).forEach(item=>{if(item.chart){item.chart.resize();item.chart.update('none');}});
    await new Promise(r=>setTimeout(r,350));
    const canvas=await html2canvas(sheet,{
      backgroundColor:'#ffffff',scale:2,useCORS:true,allowTaint:false,logging:false,imageTimeout:15000,
      width:sheet.offsetWidth,height:sheet.offsetHeight,windowWidth:sheet.offsetWidth,windowHeight:sheet.offsetHeight,scrollX:0,scrollY:0
    });
    const filename='5S_<?=$department?>_<?=$thaiYear?>_<?=$view==='year'?'รายปี':$month?>_A3_แนวนอน.png';
    if(canvas.toBlob){
      const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('สร้างไฟล์ภาพไม่สำเร็จ')),'image/png'));
      const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }else{
      const a=document.createElement('a');a.href=canvas.toDataURL('image/png',1);a.download=filename;a.click();
    }
  }catch(e){
    alert('บันทึกภาพไม่สำเร็จ: '+e.message);
  }finally{
    document.body.classList.remove('capture-a3');
    setGraphOutputLayout('screen');
    if(btn){btn.disabled=false;btn.textContent=oldText;}
  }
}
</script>
</body>
</html>
