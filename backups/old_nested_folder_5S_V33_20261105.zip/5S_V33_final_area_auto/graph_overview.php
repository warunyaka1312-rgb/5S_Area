<?php
require_once 'config.php';
$title='ภาพรวมคะแนนทุกกลุ่ม — Production + Office';
$p=db();
$months=[1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$latestDate=(string)$p->query("SELECT MAX(audit_date) FROM audits WHERE department IN ('Production','Office')")->fetchColumn();
$defaultYear=$latestDate!==''?(int)substr($latestDate,0,4):(int)date('Y');
$defaultMonth=$latestDate!==''?(int)substr($latestDate,5,2):(int)date('n');
$month=(int)($_GET['month']??$defaultMonth);
$yearInput=(int)($_GET['year']??$defaultYear);
$year=$yearInput>=2400?$yearInput-543:$yearInput;
if($month<1||$month>12)$month=$defaultMonth;
if($year<2000||$year>2200)$year=$defaultYear;
$monthName=$months[$month]??$months[$defaultMonth];
$start=sprintf('%04d-%02d-01',$year,$month);
$end=date('Y-m-t',strtotime($start));
$prodTarget=target_pct('Production');
$officeTarget=target_pct('Office');

/** Return all active areas for a department, including those not yet scored in the selected period. */
function overview_group_rows(PDO $p,string $dept,string $start,string $end):array{
    $scoreTable=$dept==='Office'?'office_scores':'scores';
    $critTable=$dept==='Office'?'office_criteria':'criteria';
    $q=$p->prepare("SELECT a.id AS area_id,a.group_name,a.unit_no,a.area_name,
                           au.id AS audit_id,s.score1,s.score2,s.score3,c.max_score
                    FROM areas a
                    LEFT JOIN audits au ON au.area_id=a.id AND au.department=? AND au.audit_date BETWEEN ? AND ?
                    LEFT JOIN {$scoreTable} s ON s.audit_id=au.id
                    LEFT JOIN {$critTable} c ON c.id=s.criterion_id
                    WHERE a.active=1 AND a.department=?
                    ORDER BY a.group_name COLLATE NOCASE,CAST(a.unit_no AS INTEGER),a.unit_no");
    $q->execute([$dept,$start,$end,$dept]);
    $acc=[];
    foreach($q as $r){
        $id=(int)$r['area_id'];
        if(!isset($acc[$id])){
            $group=display_area_group((string)($r['group_name']??''));
            $unit=trim((string)($r['unit_no']??''));
            $name=trim((string)($r['area_name']??''));
            if($name==='')$name=$group.($unit!==''?' / หน่วย '.$unit:'');
            $acc[$id]=['area_id'=>$id,'department'=>$dept,'group'=>$group,'unit'=>$unit,'name'=>$name,
                       'label'=>$dept.' • '.$name,'score'=>0.0,'max'=>0.0,'audits'=>[],'target'=>target_pct($dept)];
        }
        if($r['audit_id']!==null){
            $v=score_avg($r['score1'],$r['score2'],$r['score3']);
            if($v!==null && $r['max_score']!==null){
                $acc[$id]['score']+=(float)$v;
                $acc[$id]['max']+=(float)$r['max_score'];
                $acc[$id]['audits'][(int)$r['audit_id']]=1;
            }
        }
    }
    $rows=[];
    foreach($acc as $r){
        $r['avg']=$r['max']>0?round($r['score']/$r['max']*100,2):null;
        $r['audit_count']=count($r['audits']);
        unset($r['audits']);
        $rows[]=$r;
    }
    // Put scored units from low to high first for action, then show every unscored active unit.
    usort($rows,function($a,$b){
        if($a['avg']===null && $b['avg']!==null)return 1;
        if($a['avg']!==null && $b['avg']===null)return -1;
        if($a['avg']!==null && $b['avg']!==null && $a['avg']!=$b['avg'])return $a['avg']<=>$b['avg'];
        $g=strnatcasecmp((string)$a['group'],(string)$b['group']);
        return $g!==0?$g:strnatcasecmp((string)$a['unit'],(string)$b['unit']);
    });
    return $rows;
}
$prodRows=overview_group_rows($p,'Production',$start,$end);
$officeRows=overview_group_rows($p,'Office',$start,$end);
$allRows=array_merge($prodRows,$officeRows);
$totalUnits=count($allRows);
$prodScored=count(array_filter($prodRows,fn($r)=>$r['avg']!==null));
$officeScored=count(array_filter($officeRows,fn($r)=>$r['avg']!==null));
$scored=$prodScored+$officeScored;
$missing=$totalUnits-$scored;
$prodTotalScore=array_sum(array_column(array_filter($prodRows,fn($r)=>$r['avg']!==null),'score'));
$prodTotalMax=array_sum(array_column(array_filter($prodRows,fn($r)=>$r['avg']!==null),'max'));
$officeTotalScore=array_sum(array_column(array_filter($officeRows,fn($r)=>$r['avg']!==null),'score'));
$officeTotalMax=array_sum(array_column(array_filter($officeRows,fn($r)=>$r['avg']!==null),'max'));
$prodAvg=$prodTotalMax>0?$prodTotalScore/$prodTotalMax*100:null;
$officeAvg=$officeTotalMax>0?$officeTotalScore/$officeTotalMax*100:null;
$labels=array_column($allRows,'label');
$values=array_map(fn($r)=>$r['avg'],$allRows);
$targets=array_column($allRows,'target');
$departments=array_column($allRows,'department');
$chartRows=array_map(fn($r)=>['label'=>$r['label'],'name'=>$r['name'],'department'=>$r['department'],'avg'=>$r['avg'],'target'=>$r['target']],$allRows);
require 'includes/header.php';
?>
<style>
.overview-page{font-family:Tahoma,"Noto Sans Thai",Arial,sans-serif;color:#172238}
.overview-toolbar{display:flex;align-items:end;gap:10px;flex-wrap:wrap;background:#fff;border:1px solid #dce3ec;border-radius:14px;padding:15px;margin-bottom:14px;box-shadow:0 3px 12px rgba(15,23,42,.04)}
.overview-field{display:flex;flex-direction:column;gap:5px;font-size:12px;font-weight:900;color:#475569}.overview-field select,.overview-field input{height:40px;min-width:135px;border:1px solid #cbd5e1;border-radius:9px;padding:0 10px;background:#fff;color:#172238;font-weight:700}
.overview-btn{height:40px;border:0;border-radius:9px;padding:0 15px;display:inline-flex;align-items:center;justify-content:center;gap:7px;background:#f45b0b;color:#fff;text-decoration:none;font-weight:900;cursor:pointer}.overview-btn.secondary{background:#172238}.overview-btn.green{background:#15803d}
.overview-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-bottom:14px}.overview-kpi{background:#fff;border:1px solid #e0e7ef;border-radius:14px;padding:16px;min-height:100px;box-shadow:0 3px 10px rgba(15,23,42,.04)}.overview-kpi .label{font-size:12px;color:#64748b;font-weight:800}.overview-kpi .value{font-size:27px;font-weight:950;margin-top:5px;color:#172238}.overview-kpi .sub{font-size:11px;color:#64748b;margin-top:3px}.overview-kpi.orange{border-top:4px solid #f45b0b}.overview-kpi.green{border-top:4px solid #16a34a}.overview-kpi.blue{border-top:4px solid #2563eb}.overview-kpi.gray{border-top:4px solid #94a3b8}
.overview-card{background:#fff;border:1px solid #dce3ec;border-radius:16px;padding:18px;box-shadow:0 5px 18px rgba(15,23,42,.05)}.overview-card h2{font-size:23px;font-weight:950;margin:0 0 5px;color:#10213a}.overview-muted{color:#64748b;font-size:12px}.overview-chart-wrap{position:relative;width:100%;margin-top:14px}.overview-chart-wrap canvas{width:100%!important;height:100%!important}.overview-legend{display:flex;gap:16px;flex-wrap:wrap;margin-top:12px;font-size:12px;color:#475569;font-weight:800}.overview-dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}
.overview-missing{margin-top:14px;border:1px solid #fed7aa;border-radius:12px;background:#fff7ed;padding:13px}.overview-missing h3{margin:0 0 8px;font-size:15px;font-weight:950;color:#9a3412}.overview-missing-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.overview-missing ul{margin:0;padding-left:20px;font-size:12px;line-height:1.8;color:#7c2d12}.overview-note{font-size:12px;color:#64748b;margin-top:12px;line-height:1.6}
@media(max-width:1050px){.overview-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.overview-card{padding:12px}.overview-card h2{font-size:19px}}
@media(max-width:600px){.overview-kpis{grid-template-columns:1fr 1fr}.overview-kpi{padding:12px}.overview-kpi .value{font-size:22px}.overview-missing-grid{grid-template-columns:1fr}.overview-field{flex:1}.overview-field select,.overview-field input{width:100%;min-width:0}}
@media print{.overview-toolbar,.overview-actions,.sidebar,.topbar,.footer{display:none!important}.main{margin:0!important;padding:0!important}.overview-card,.overview-kpi{box-shadow:none!important;break-inside:avoid}.overview-chart-wrap{break-inside:avoid}}
</style>
<div class="overview-page">
  <div class="overview-toolbar no-print">
    <a class="overview-btn secondary" href="index.php">← กลับ Dashboard</a>
    <form method="get" class="flex items-end gap-2 flex-wrap">
      <label class="overview-field">เดือน<select name="month"><?php foreach($months as $n=>$th): ?><option value="<?=$n?>" <?=$month===$n?'selected':''?>><?=$th?></option><?php endforeach; ?></select></label>
      <label class="overview-field">ปี ค.ศ.<input type="number" name="year" min="2000" max="2200" value="<?=$year?>"></label>
      <button class="overview-btn" type="submit">🔎 แสดงภาพรวม</button>
    </form>
    <button class="overview-btn green" type="button" onclick="downloadOverview()">⬇ ดาวน์โหลดกราฟ PNG</button>
    <button class="overview-btn secondary" type="button" onclick="window.print()">🖨 พิมพ์ / Save PDF</button>
  </div>

  <div class="overview-kpis">
    <div class="overview-kpi orange"><div class="label">หน่วยทั้งหมดใน Master</div><div class="value"><?=$totalUnits?></div><div class="sub">Production + Office</div></div>
    <div class="overview-kpi green"><div class="label">มีคะแนนในเดือนที่เลือก</div><div class="value"><?=$scored?></div><div class="sub">Production <?=$prodScored?> • Office <?=$officeScored?></div></div>
    <div class="overview-kpi gray"><div class="label">ยังไม่มีคะแนน</div><div class="value"><?=$missing?></div><div class="sub">ยังแสดงไว้ในกราฟ ไม่ซ่อนหน่วย</div></div>
    <div class="overview-kpi blue"><div class="label">คะแนนเฉลี่ย Production</div><div class="value"><?=$prodAvg===null?'—':number_format($prodAvg,2).'%'?></div><div class="sub">เป้าหมาย <?=number_format($prodTarget,1)?>%</div></div>
    <div class="overview-kpi orange"><div class="label">คะแนนเฉลี่ย Office</div><div class="value"><?=$officeAvg===null?'—':number_format($officeAvg,2).'%'?></div><div class="sub">เป้าหมาย <?=number_format($officeTarget,1)?>%</div></div>
  </div>

  <section class="overview-card">
    <div class="flex flex-wrap justify-between items-start gap-3">
      <div><h2>📊 ภาพรวมคะแนนทุกกลุ่ม — Production + Office</h2><div class="overview-muted"><?=$monthName?> <?=$year?> • เรียงตามแผนกและคะแนนต่ำไปสูง • แสดงทุกหน่วยที่เปิดใช้งานจาก Master</div></div>
    </div>
    <div id="overviewChartWrap" class="overview-chart-wrap"><canvas id="overviewChart"></canvas></div>
    <div class="overview-legend">
      <span><i class="overview-dot" style="background:#16a34a"></i>ผ่านเป้าหมายของแผนก</span>
      <span><i class="overview-dot" style="background:#dc2626"></i>ต่ำกว่าเป้าหมายของแผนก</span>
      <span><i class="overview-dot" style="background:#94a3b8"></i>ยังไม่มีคะแนนในเดือนที่เลือก</span>
      <span><i class="overview-dot" style="background:#ef4444"></i>เส้นประ = เป้าหมาย Production <?=number_format($prodTarget,1)?>% / Office <?=number_format($officeTarget,1)?>%</span>
    </div>
    <?php $prodMissing=array_values(array_filter($prodRows,fn($r)=>$r['avg']===null)); $officeMissing=array_values(array_filter($officeRows,fn($r)=>$r['avg']===null)); ?>
    <?php if($missing>0): ?>
    <div class="overview-missing"><h3>⚠ หน่วยที่ยังไม่มีคะแนนในเดือนนี้ (ยังแสดงอยู่ในกราฟ)</h3><div class="overview-missing-grid"><div><strong>🏭 Production — <?=count($prodMissing)?> หน่วย</strong><ul><?php foreach($prodMissing as $r): ?><li><?=h($r['name'])?></li><?php endforeach; ?><?php if(!$prodMissing): ?><li>ครบทุกหน่วยแล้ว</li><?php endif; ?></ul></div><div><strong>🏢 Office — <?=count($officeMissing)?> หน่วย</strong><ul><?php foreach($officeMissing as $r): ?><li><?=h($r['name'])?></li><?php endforeach; ?><?php if(!$officeMissing): ?><li>ครบทุกหน่วยแล้ว</li><?php endif; ?></ul></div></div></div>
    <?php endif; ?>
    <div class="overview-note">หมายเหตุ: คะแนนคำนวณจากรายการตรวจที่มีคะแนนจริงในช่วงเวลาที่เลือก ส่วนหน่วยที่ยังไม่มีคะแนนจะแสดงเป็นสีเทาและระบุสถานะชัดเจน ไม่แทนคะแนนว่างด้วย 0% • ข้อมูลมาจากฐานข้อมูลเดิมและไม่มีการแก้ไขข้อมูลต้นทางจากหน้านี้</div>
  </section>
</div>
<script>
const OVERVIEW_ROWS=<?=json_encode($chartRows,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
const OVERVIEW_PROD_TARGET=<?=json_encode($prodTarget)?>;
const OVERVIEW_OFFICE_TARGET=<?=json_encode($officeTarget)?>;
let overviewChart=null;
function drawOverview(){
  const wrap=document.getElementById('overviewChartWrap');
  const rows=OVERVIEW_ROWS;
  // No artificial height cap: every active unit remains visible, even on large departments.
  const height=Math.max(650,rows.length*29+180);
  wrap.style.height=height+'px';
  const labels=rows.map(r=>r.label);
  const values=rows.map(r=>r.avg===null?null:Number(r.avg));
  const colors=rows.map(r=>r.avg===null?'rgba(148,163,184,.55)':(Number(r.avg)>=Number(r.target)?'rgba(22,163,74,.9)':'rgba(220,38,38,.9)'));
  const borders=rows.map(r=>r.avg===null?'#94a3b8':(Number(r.avg)>=Number(r.target)?'#16a34a':'#dc2626'));
  const prodTargetLine=rows.map(r=>r.department==='Production'?Number(r.target):null);
  const officeTargetLine=rows.map(r=>r.department==='Office'?Number(r.target):null);
  overviewChart=new Chart(document.getElementById('overviewChart'),{
    type:'bar',
    data:{labels:labels,datasets:[
      {label:'คะแนนเฉลี่ย %',data:values,backgroundColor:colors,borderColor:borders,borderWidth:1,borderRadius:6,barThickness:18,maxBarThickness:22},
      {type:'line',label:'เป้าหมาย Production '+Number(OVERVIEW_PROD_TARGET).toFixed(1)+'%',data:prodTargetLine,borderColor:'#ef4444',borderDash:[7,5],borderWidth:2,pointRadius:0,spanGaps:false},
      {type:'line',label:'เป้าหมาย Office '+Number(OVERVIEW_OFFICE_TARGET).toFixed(1)+'%',data:officeTargetLine,borderColor:'#f97316',borderDash:[3,5],borderWidth:2,pointRadius:0,spanGaps:false}
    ]},
    options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,animation:false,layout:{padding:{left:3,right:90,top:8,bottom:8}},
      scales:{x:{min:0,max:100,grid:{color:'rgba(148,163,184,.2)'},ticks:{font:{size:12,weight:'700'},callback:v=>v+'%'},title:{display:true,text:'คะแนน (%)',font:{size:13,weight:'800'}}},
      y:{grid:{display:false},ticks:{autoSkip:false,padding:7,color:'#334155',font:{family:'Tahoma',size:12,weight:'700'},callback:function(value){return String(this.getLabelForValue(value)).split(' • ');}},afterFit:axis=>{axis.width=390;}}},
      plugins:{legend:{position:'top',labels:{font:{family:'Tahoma',size:12,weight:'800'},usePointStyle:true,boxWidth:12,padding:14}},tooltip:{callbacks:{title:items=>items.length?items[0].label:'',label:ctx=>{const r=rows[ctx.dataIndex];if(ctx.datasetIndex===0)return r.avg===null?' ยังไม่มีคะแนนในเดือนที่เลือก':' คะแนน '+Number(r.avg).toFixed(2)+'% (เป้าหมาย '+Number(r.target).toFixed(1)+'%)';return ctx.raw===null?'':(' '+ctx.dataset.label+'');}}}},
      interaction:{mode:'index',intersect:false}
    },
    plugins:[{id:'overviewValueLabels',afterDatasetsDraw(chart){
      const ctx=chart.ctx,meta=chart.getDatasetMeta(0);ctx.save();ctx.textBaseline='middle';
      meta.data.forEach((bar,i)=>{const r=rows[i]; if(!r)return;
        if(r.avg===null){ctx.font='italic 11px Tahoma';ctx.fillStyle='#64748b';ctx.textAlign='left';ctx.fillText('ยังไม่มีคะแนน',chart.chartArea.left+8,bar.y);}
        else{ctx.font='800 12px Tahoma';ctx.fillStyle='#172238';ctx.textAlign='left';ctx.fillText(Number(r.avg).toFixed(2)+'%',Math.min(bar.x+7,chart.chartArea.right-62),bar.y);}
      });ctx.restore();
    }}]
  });
}
function downloadOverview(){if(!overviewChart)return;const a=document.createElement('a');a.href=overviewChart.toBase64Image('image/png',1);a.download='5S_Overview_Production_Office_<?=$year?>_<?=sprintf('%02d',$month)?>.png';a.click();}
drawOverview();
</script>
<?php require 'includes/footer.php'; ?>
