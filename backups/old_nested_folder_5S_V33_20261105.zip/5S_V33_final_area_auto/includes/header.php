<?php require_once __DIR__.'/../config.php'; ?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=h($title??"Dashboard 5 ส.")?> | 5S SMART</title>
<link rel="icon" type="image/svg+xml" href="assets/5s-smart-favicon.svg">
<link rel="apple-touch-icon" href="assets/5s-smart-favicon.svg">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<?php
$currentPage=basename($_SERVER['PHP_SELF']??'');
$currentDepartment=$_GET['department']??'';
function nav_active(string $page, ?string $department=null):string{
    global $currentPage,$currentDepartment;
    if($currentPage!==$page) return '';
    if($department!==null && $currentDepartment!==$department) return '';
    return 'active';
}
?>
<style>
*{box-sizing:border-box}
:root{--orange:#ff5a00;--orange2:#ff7a00;--navy:#0b1220;--navy2:#172238;--bg:#f4f7fb;--ink:#111827}
body{margin:0;font-family:Tahoma,"Noto Sans Thai",Arial,sans-serif;background:var(--bg);color:var(--ink)}
.app{min-height:100vh}
.topbar{height:72px;background:linear-gradient(90deg,#ff4f00,#ff6b00);color:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 22px;position:sticky;top:0;z-index:50;box-shadow:0 4px 18px rgba(0,0,0,.12)}
.brand-mini{display:flex;align-items:center;gap:12px;font-weight:900;font-size:20px}
.brand-mini img{width:42px;height:42px;background:#fff;border-radius:10px;padding:3px}
.sidebar{background:linear-gradient(180deg,#09111f 0%,#121d30 100%);color:#dbe5f4;width:250px;min-height:calc(100vh - 72px);position:fixed;left:0;top:72px;bottom:0;overflow:auto}
.side-logo{padding:22px 18px 18px;border-bottom:1px solid rgba(255,255,255,.12)}
.side-logo img{width:180px;background:#fff;border-radius:12px;padding:5px}
.side-sub{font-size:11px;color:#94a3b8;margin-top:7px}
.nav{padding:12px 10px 22px}
/* High-contrast enterprise section headers for the sidebar navigation */
.nav-title{position:relative;display:block;font-size:12.5px;line-height:1.4;color:#ffd2b8;font-weight:900;padding:10px 9px 10px 25px;text-transform:none;letter-spacing:.15px;background:linear-gradient(90deg,rgba(255,90,0,.22) 0%,rgba(255,90,0,.07) 100%);border:1px solid rgba(255,122,0,.16);border-left:4px solid #ff5a00;border-radius:0 9px 9px 0;margin:15px 0 7px;min-height:38px;box-shadow:inset 0 1px 0 rgba(255,255,255,.035)}
.nav-title:before{content:"";position:absolute;left:9px;top:50%;transform:translateY(-50%);width:7px;height:7px;border-radius:50%;background:#ff7833;box-shadow:0 0 0 3px rgba(255,120,51,.14)}
.nav-title:first-child{margin-top:3px}
.nav a{min-height:42px;line-height:1.4}.nav a span{flex:1}
.nav a{display:flex;gap:11px;align-items:center;padding:11px 12px;border-radius:10px;color:#cbd5e1;text-decoration:none;font-size:14px;font-weight:700}
.nav a:hover{background:rgba(255,90,0,.18);color:#fff}.nav a.active{background:#fff1e8;color:#173b70;box-shadow:inset 5px 0 0 #ff5a00;font-weight:900}
.main{margin-left:250px;min-height:calc(100vh - 72px);padding:24px}
.wrap{max-width:1550px;margin:auto}
.hero{background:linear-gradient(100deg,#fff 0%,#fff 57%,#172238 57%,#0b1220 100%);border-radius:18px;border:1px solid #e5e7eb;min-height:118px;display:flex;align-items:center;justify-content:space-between;padding:16px 26px;margin-bottom:20px;overflow:hidden}
.hero-copy h1{font-size:30px;margin:0;font-weight:900;color:#172238}.hero-copy h1 span{color:var(--orange)}
.hero-copy p{margin:6px 0 0;color:#64748b}.hero-right{color:#fff;text-align:right}.hero-right strong{display:block;font-size:23px;color:#ff7a00}.hero-right small{color:#dbe5f4}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;box-shadow:0 8px 25px rgba(15,23,42,.06)}
.card-orange{border:2px solid var(--orange);box-shadow:0 10px 25px rgba(255,90,0,.09)}
.chart-card{height:370px;display:flex;flex-direction:column}.chart-wrap{position:relative;height:285px;min-height:285px}.chart-wrap canvas{width:100%!important;height:100%!important}
.section-title{font-size:20px;font-weight:900;color:#172238}
.score-big{font-size:42px;line-height:1;font-weight:900;color:#ef4b13}
.kpi-icon{width:44px;height:44px;border-radius:12px;background:#fff1e8;color:var(--orange);display:flex;align-items:center;justify-content:center;font-size:24px}
.print-actions{display:flex;gap:8px;flex-wrap:wrap}.print-btn{background:#fff;border:1px solid #cbd5e1;border-radius:10px;padding:8px 12px;font-weight:800;color:#172238;text-decoration:none}.print-btn:hover{border-color:#ff5a00;color:#ff5a00}.footer{background:#0b1220;color:#cbd5e1;margin:24px -24px -24px;padding:18px 24px;font-size:12px}
.good{background:#dcfce7;color:#166534}.warn{background:#fef3c7;color:#92400e}.bad{background:#fee2e2;color:#991b1b}
input,select,textarea{outline:none}
.dataTables_wrapper .dataTables_filter input,.dataTables_wrapper .dataTables_length select{border:1px solid #cbd5e1;border-radius:8px;padding:5px 8px}
.mobile-menu{display:none}
/* Keep the duplicate quick-navigation panel hidden on desktop.
   It is opened only by the hamburger control on narrow screens. */
#mobileNav{display:none!important}
#mobileNav.mobile-nav-open{display:block!important}
@media(min-width:1024px){#mobileNav,#mobileNav.mobile-nav-open{display:none!important}}
@media(max-width:1023px){.sidebar{display:none}.main{margin-left:0;padding:14px}.mobile-menu{display:block}.hero{background:#fff}.hero-right{display:none}}
@media(max-width:640px){.topbar{padding:0 12px}.hero-copy h1{font-size:23px}.hero-copy p{font-size:12px}.score-big{font-size:34px}.chart-card{height:330px}.chart-wrap{height:245px;min-height:245px}}
@media print{.no-print{display:none!important}.sidebar,.topbar{display:none!important}.main{margin:0;padding:0}.card{box-shadow:none}.footer{display:none}.print-page{display:block!important}.print-chart{break-inside:avoid}}
</style>
</head>
<body>
<div class="app">
<header class="topbar no-print">
  <div class="brand-mini"><button class="mobile-menu bg-white/15 rounded-lg px-3 py-2" onclick="document.getElementById('mobileNav').classList.toggle('mobile-nav-open')" aria-controls="mobileNav" aria-expanded="false">☰</button><img src="assets/5s-smart-logo.svg" alt="5S SMART"><span>5S SMART <b class="opacity-80">| ALUMET</b></span></div>
  <div class="hidden md:flex items-center gap-6 text-sm font-bold"><span>📅 <?=date('d F Y')?></span><span>👤 Somjat⌄</span><span>↪ ออกจากระบบ</span></div>
</header>
<div id="mobileNav" class="fixed top-[72px] left-0 right-0 z-40 bg-slate-950 p-4 no-print">
  <div class="grid grid-cols-2 gap-2 text-sm"><a class="bg-orange-500 text-white rounded-lg p-3" href="index.php">🏠 Dashboard</a><a class="bg-slate-800 text-white rounded-lg p-3" href="production_score.php">🏭 Production</a><a class="bg-slate-800 text-white rounded-lg p-3" href="office_score.php">🏢 Office</a><a class="bg-slate-800 text-white rounded-lg p-3" href="reports.php">📊 รายงาน</a><a class="bg-slate-800 text-white rounded-lg p-3" href="org_3month_summary.php">📌 สรุปองค์กร / 3 เดือน</a><a class="bg-orange-500 text-white rounded-lg p-3" href="board_title.php">🏷 ป้ายชื่อบอร์ด 5ส.</a><a class="bg-orange-500 text-white rounded-lg p-3" href="import.php">📥 นำเข้าผลตรวจ</a><a class="bg-slate-800 text-white rounded-lg p-3" href="backup.php">💾 Backup</a><a class="bg-orange-500 text-white rounded-lg p-3" href="tag_dashboard.php">🏷 TAG 5 ส.</a></div>
</div>
<aside class="sidebar no-print">
  <div class="side-logo"><img src="assets/5s-smart-logo.svg" alt="5S SMART"><div class="side-sub">CLEAN WORKPLACE • BRIGHT TOMORROW</div></div>
  <nav class="nav">
    <div class="nav-title">เริ่มต้นใช้งาน</div>
    <a class="<?=nav_active('index.php')?>" href="index.php">🏠 <span>ภาพรวมระบบ (Dashboard)</span></a>
    <a class="<?=nav_active('setup_check.php')?>" href="setup_check.php">🛠️ <span>ตรวจความพร้อมระบบ</span></a>

    <div class="nav-title">1. ตรวจ 5 ส. — Production</div>
    <a class="<?=nav_active('production_score.php')?>" href="production_score.php">📝 <span>บันทึกคะแนน Production</span></a>
    <a class="<?=nav_active('production_criteria.php')?>" href="production_criteria.php">📋 <span>หัวข้อตรวจ Production</span></a>
    <a class="<?=nav_active('reports.php','Production')?>" href="reports.php?department=Production">📊 <span>กราฟและ Ranking Production</span></a>

    <div class="nav-title">2. ตรวจ 5 ส. — Office</div>
    <a class="<?=nav_active('office_score.php')?>" href="office_score.php">📝 <span>บันทึกคะแนน Office</span></a>
    <a class="<?=nav_active('office_criteria.php')?>" href="office_criteria.php">📋 <span>หัวข้อตรวจ Office</span></a>
    <a class="<?=nav_active('office_reports.php')?>" href="office_reports.php">📊 <span>กราฟและ Ranking Office</span></a>

    <div class="nav-title">3. แผนตรวจและเอกสาร</div>
    <a class="<?=nav_active('schedule_manage.php')?>" href="schedule_manage.php">📅 <span>จัดตารางแผนตรวจ</span></a>
    <a class="<?=nav_active('schedule_print.php')?>" href="schedule_print.php" target="_blank">🖨️ <span>พิมพ์แผนตรวจ</span></a>
    <a class="<?=nav_active('inspection_form.php')?>" href="inspection_form.php">📄 <span>พิมพ์ใบตรวจ 5 ส.</span></a>
    <a class="<?=nav_active('completion_summary.php')?>" href="completion_summary.php">✅ <span>สรุปผลการตรวจ</span></a>
    <a class="<?=nav_active('period_report.php')?>" href="period_report.php">🗓️ <span>รายงานรายเดือน / รายปี</span></a>
    <a class="<?=nav_active('org_3month_summary.php')?>" href="org_3month_summary.php">📌 <span>สรุปองค์กร / เปรียบเทียบ 3 เดือน</span></a>
    <a class="<?=nav_active('board_title.php')?>" href="board_title.php">🏷️ <span>ป้ายชื่อบอร์ด 5 ส.</span></a>

    <div class="nav-title">4. TAG 5 ส.</div>
    <a class="<?=nav_active('tag_dashboard.php')?>" href="tag_dashboard.php">📊 <span>Dashboard สถานะ TAG</span></a>
    <a class="<?=nav_active('tag_manage.php')?>" href="tag_manage.php">🏷️ <span>รับ TAG / ติดตาม / ปิด TAG</span></a>
    <a class="<?=nav_active('tag_print.php')?>" href="tag_print.php" target="_blank">🖨️ <span>พิมพ์สรุป TAG</span></a>
    <a class="<?=nav_active('tag_blank_form_print.php')?>" href="tag_blank_form_print.php" target="_blank">📄 <span>พิมพ์แบบฟอร์ม TAG เปล่า</span></a>
    <a class="<?=nav_active('tag_form_print.php')?>" href="tag_form_print.php">🖨️ <span>พิมพ์แบบฟอร์ม TAG จากข้อมูล</span></a>

    <div class="nav-title">5. ข้อมูลพื้นฐานและผู้ตรวจ</div>
    <a class="<?=nav_active('master_data.php')?>" href="master_data.php">🏢 <span>จัดการแผนก / กลุ่ม / หน่วย</span></a>
    <a class="<?=nav_active('history.php')?>" href="history.php">👥 <span>ประวัติผู้ตรวจ / ผลตรวจ</span></a>
    <a class="<?=nav_active('auditor_12month.php')?>" href="auditor_12month.php">📆 <span>ประวัติผู้ตรวจ 12 เดือน</span></a>
    <a class="<?=nav_active('verify.php')?>" href="verify.php">🔎 <span>ตรวจสอบความถูกต้องของข้อมูล</span></a>
    <a class="<?=nav_active('settings.php')?>" href="settings.php">🎯 <span>ตั้งค่าเป้าหมายคะแนน</span></a>

    <div class="nav-title">6. นำเข้า / ส่งออก / สำรองข้อมูล</div>
    <a class="<?=nav_active('import.php')?>" href="import.php">📥 <span>นำเข้าผลตรวจจากไฟล์</span></a>
    <a class="<?=nav_active('legacy.php')?>" href="legacy.php">📚 <span>ข้อมูล Excel เดิม</span></a>
    <a class="<?=nav_active('export.php')?>" href="export.php">📤 <span>ส่งออก Excel</span></a>
    <a class="<?=nav_active('backup.php')?>" href="backup.php">💾 <span>สำรอง / กู้คืนข้อมูล</span></a>
  </nav>
</aside>
<main class="main"><div class="wrap">
