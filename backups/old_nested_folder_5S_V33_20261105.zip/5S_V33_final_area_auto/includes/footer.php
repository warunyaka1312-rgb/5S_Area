</div>
<footer class="footer mt-8 no-print">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div>5S SMART SCORE SYSTEM &nbsp;|&nbsp; ALUMET © 2026 &nbsp;|&nbsp; Version V30</div>
    <div class="text-orange-400 font-black italic">Clean Today • Better Tomorrow</div>
  </div>
</footer>
</main>
</div>
</body></html>