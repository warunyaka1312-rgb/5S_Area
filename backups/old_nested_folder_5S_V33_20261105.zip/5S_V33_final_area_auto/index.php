<?php
require_once 'config.php';
$title='Dashboard 5 ส.';
$p=db();
$department=$_GET['department']??'Production';
if(!in_array($department,['Production','Office'],true))$department='Production';
$view=$_GET['view']??'month';
$year=(int)($_GET['year']??date('Y'));
$month=(int)($_GET['month']??0);
/* ถ้าไม่ได้ระบุเดือน ให้เปิดเดือนล่าสุดที่มีข้อมูลจริงของประเภทที่เลือก
   เพื่อไม่ให้ Dashboard ดูเหมือนข้อมูลหายเมื่อขึ้นเดือนใหม่ */
if(!isset($_GET['month'])){
    $latestQ=$p->prepare("SELECT MAX(audit_date) FROM audits WHERE department=?");
    $latestQ->execute([$department]);
    $latestDate=(string)$latestQ->fetchColumn();
    if($latestDate!==''){
        $year=(int)substr($latestDate,0,4);
        $month=(int)substr($latestDate,5,2);
    }else{
        $month=(int)date('n');
    }
}
if($month<1 || $month>12)$month=(int)date('n');
$months=[1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$monthName=$months[$month]??$months[(int)date('n')];
$target=target_pct($department);$prodTarget=target_pct('Production');$officeTarget=target_pct('Office');
$critTable=$department==='Office'?'office_criteria':'criteria';
$scoreTable=$department==='Office'?'office_scores':'scores';

function dashboard_groups(PDO $p,string $dept,string $start,string $end,string $scoreTable,string $critTable):array{
    $q=$p->prepare("SELECT a.id,a.group_name,a.area_name,au.audit_date,s.score1,s.score2,s.score3,c.max_score
                    FROM audits au
                    JOIN areas a ON a.id=au.area_id
                    JOIN {$scoreTable} s ON s.audit_id=au.id
                    JOIN {$critTable} c ON c.id=s.criterion_id
                    WHERE au.department=? AND au.audit_date BETWEEN ? AND ?
                    ORDER BY a.group_name,a.unit_no");
    $q->execute([$dept,$start,$end]);
    $tmp=[];
    foreach($q as $r){
        $key=$r['area_name'];
        $v=score_avg($r['score1'],$r['score2'],$r['score3']);
        if($v===null)continue;
        if(!isset($tmp[$key]))$tmp[$key]=['group_name'=>$r['area_name'],'score'=>0,'max'=>0,'audits'=>[]];
        $tmp[$key]['score']+=(float)$v;
        $tmp[$key]['max']+=(float)$r['max_score'];
        $tmp[$key]['audits'][$r['id']]=1;
    }
    $out=[];
    foreach($tmp as $r)$out[]=['group_name'=>$r['group_name'],'avg'=>$r['max']?round($r['score']/$r['max']*100,2):0,'n'=>count($r['audits'])];
    usort($out,fn($a,$b)=>$b['avg']<=>$a['avg']);
    return $out;
}
function dashboard_stats(PDO $p,string $dept,string $start,string $end,string $scoreTable,string $critTable):array{
    $rows=dashboard_groups($p,$dept,$start,$end,$scoreTable,$critTable);
    $s=0;$m=0;$audits=[];
    $q=$p->prepare("SELECT au.id FROM audits au WHERE au.department=? AND au.audit_date BETWEEN ? AND ?");
    $q->execute([$dept,$start,$end]);$audits=$q->fetchAll(PDO::FETCH_COLUMN);
    if($audits){
        $in=implode(',',array_fill(0,count($audits),'?'));
        $q=$p->prepare("SELECT s.score1,s.score2,s.score3,c.max_score FROM {$scoreTable} s JOIN {$critTable} c ON c.id=s.criterion_id WHERE s.audit_id IN ($in)");
        $q->execute($audits);
        foreach($q as $r){$v=score_avg($r['score1'],$r['score2'],$r['score3']);if($v!==null){$s+=(float)$v;$m+=(float)$r['max_score'];}}
    }
    return ['avg'=>$m?round($s/$m*100,2):0,'groups'=>count($rows),'audits'=>count($audits),'rows'=>$rows];
}
$start=sprintf('%04d-%02d-01',$year,$month);$end=date('Y-m-t',strtotime($start));
$prod=dashboard_stats($p,'Production',$start,$end,'scores','criteria');
$off=dashboard_stats($p,'Office',$start,$end,'office_scores','office_criteria');
$deptData=$department==='Office'?$off['rows']:$prod['rows'];
$score=$department==='Office'?$off['avg']:$prod['avg'];
$passGroups=0;$lowGroups=0;foreach($deptData as $r){if($r['avg']>=target_pct($department))$passGroups++;else$lowGroups++;}
$trend=[];for($m=1;$m<=12;$m++){ $st=sprintf('%04d-%02d-01',$year,$m);$en=date('Y-m-t',strtotime($st));$z=dashboard_stats($p,$department,$st,$en,$scoreTable,$critTable);$trend[]=$z['avg']?:null;}
// TAG dashboard chart must use the live Tag records, not the imported historical summary table.
// This keeps the chart synchronized with the Receive/Close Tag page after every save, edit, close, or reopen.
$tagOpen=0; $tagClosed=0;
try {
    $tagCounts=$p->query("SELECT SUM(CASE WHEN UPPER(TRIM(status))='CLOSED' OR TRIM(closed_date)<>'' THEN 1 ELSE 0 END) AS closed_count, SUM(CASE WHEN UPPER(TRIM(status))='CLOSED' OR TRIM(closed_date)<>'' THEN 0 ELSE 1 END) AS open_count FROM tags")->fetch(PDO::FETCH_ASSOC) ?: [];
    $tagClosed=(int)($tagCounts['closed_count']??0);
    $tagOpen=(int)($tagCounts['open_count']??0);
} catch (Throwable $e) {
    // If Tag tables are not initialized yet, display zero rather than using unrelated historical summary totals.
    $tagClosed=0; $tagOpen=0;
}
require 'includes/header.php';
?>
<style>
.v14{font-family:Tahoma,"Noto Sans Thai",Arial,sans-serif}.v14-toolbar{background:#fff;border:1px solid #dce3ec;border-radius:10px;padding:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;box-shadow:0 2px 8px rgba(15,23,42,.05)}.v14-toolbar .mode{display:flex;border:1px solid #cbd5e1;border-radius:7px;overflow:hidden}.v14-toolbar .mode a{padding:10px 14px;font-weight:900;text-decoration:none;color:#172238;background:#fff}.v14-toolbar .mode a.on{background:#ff5a00;color:#fff}.v14-filter{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:800;color:#334155}.v14-filter select,.v14-filter input{height:38px;border:1px solid #cbd5e1;border-radius:7px;padding:0 10px;background:#fff;font-weight:700}.v14-btn{height:40px;border:0;border-radius:8px;padding:0 17px;color:#fff;font-weight:900;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:6px}.v14-orange{background:#ff5a00}.v14-green{background:#10a65a}.v14-blue{background:#1769e8}.v14-purple{background:#7137e8}.v14-kpis{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-top:10px}.v14-kpi{background:#fff;border:1px solid #dfe6ef;border-radius:10px;padding:11px 13px;display:flex;gap:11px;align-items:center;min-height:90px;box-shadow:0 2px 8px rgba(15,23,42,.04)}.v14-kpi .ico{width:48px;height:48px;border-radius:12px;background:#fff0e6;display:flex;align-items:center;justify-content:center;font-size:25px}.v14-kpi .lbl{font-size:11px;color:#64748b;font-weight:800}.v14-kpi .val{font-size:27px;font-weight:950;line-height:1.1;color:#172238}.v14-kpi .sub{font-size:10px;color:#64748b}.v14-grid2{display:grid;grid-template-columns:1fr;gap:18px;margin-top:14px}.v14-card{background:#fff;border:1px solid #dfe6ef;border-radius:12px;padding:15px;box-shadow:0 2px 10px rgba(15,23,42,.05)}.v14-card h2{font-size:20px;margin:0 0 9px;font-weight:950;color:#13213a}.v14-chart{height:560px;position:relative}.v14-grid2 .v14-card{min-height:620px}.v14-grid2 .v14-chart{height:560px}.v14-grid3{display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:10px;margin-top:10px}.v14-table{width:100%;border-collapse:collapse;font-size:11px}.v14-table th{background:#edf3f9;color:#334155;padding:7px;text-align:left}.v14-table td{padding:6px 7px;border-bottom:1px solid #e7edf3}.v14-table td:last-child,.v14-table th:last-child{text-align:right}@media(max-width:1200px){.v14-kpis{grid-template-columns:repeat(3,1fr)}.v14-grid3{grid-template-columns:1fr}}@media(max-width:800px){.v14-grid2{grid-template-columns:1fr}.v14-kpis{grid-template-columns:repeat(2,1fr)}}@media(max-width:560px){.v14-kpis{grid-template-columns:1fr}}
</style>
<div class="v14">
<div class="v14-toolbar no-print">
 <div class="mode"><a class="<?=$view==='month'?'on':''?>" href="?view=month&department=<?=$department?>&year=<?=$year?>&month=<?=$month?>">รายเดือน</a><a class="<?=$view==='year'?'on':''?>" href="?view=year&department=<?=$department?>&year=<?=$year?>&month=<?=$month?>">รายปี</a><a class="<?=$view==='all'?'on':''?>" href="?view=all&department=<?=$department?>&year=<?=$year?>&month=<?=$month?>">รวมทั้งหมด</a></div>
 <form class="flex flex-wrap items-center gap-2" method="get"><input type="hidden" name="view" value="<?=$view?>">
 <div class="v14-filter">ประเภท:<select name="department"><option value="Production" <?=$department==='Production'?'selected':''?>>Production</option><option value="Office" <?=$department==='Office'?'selected':''?>>Office</option></select></div>
 <div class="v14-filter">เดือน:<select name="month"><?php foreach($months as $m=>$n):?><option value="<?=$m?>" <?=$month===$m?'selected':''?>><?=$n?></option><?php endforeach;?></select></div>
 <div class="v14-filter">ปี:<input name="year" type="number" value="<?=$year?>" style="width:95px"></div><button class="v14-btn v14-orange">🔎 แสดงข้อมูล</button></form>
 <a class="v14-btn v14-green" href="graph_print.php?department=Production&view=month&month=<?=urlencode($monthName)?>&year=<?=$year?>&chart=split&size=A4" target="_blank">🖨 Production</a><a class="v14-btn v14-green" href="graph_print.php?department=Office&view=month&month=<?=urlencode($monthName)?>&year=<?=$year?>&chart=split&size=A4" target="_blank">🖨 Office</a><a class="v14-btn v14-blue" href="backup.php">💾 Backup</a><a class="v14-btn v14-purple" href="settings.php">⚙ เป้าหมาย</a>
</div>
<div class="v14-kpis">
 <div class="v14-kpi"><div class="ico">📋</div><div><div class="lbl">หัวข้อตรวจ</div><div class="val"><?=($department==='Production'?35:21)?></div><div class="sub">ข้อ</div></div></div>
 <div class="v14-kpi"><div class="ico">👥</div><div><div class="lbl">พื้นที่ / หน่วยที่มีข้อมูล</div><div class="val"><?=count($deptData)?></div><div class="sub">หน่วย</div></div></div>
 <div class="v14-kpi"><div class="ico">🏆</div><div><div class="lbl">คะแนนเฉลี่ยรวม</div><div class="val"><?=number_format($score,2)?>%</div><div class="sub">เป้าหมาย <?=number_format($target,1)?>%</div></div></div>
 <div class="v14-kpi"><div class="ico">✓</div><div><div class="lbl">ผ่านเป้าหมาย</div><div class="val"><?=$passGroups?></div><div class="sub">หน่วย</div></div></div>
 <div class="v14-kpi"><div class="ico">✕</div><div><div class="lbl">ต่ำกว่าเป้าหมาย</div><div class="val"><?=$lowGroups?></div><div class="sub">หน่วย</div></div></div>
 <div class="v14-kpi"><div class="ico">📅</div><div><div class="lbl">ข้อมูลล่าสุด</div><div class="val"><?=h($monthName)?></div><div class="sub"><?=$year?></div></div></div>
</div>
<div class="v14-grid2">
 <div class="v14-card"><div class="flex justify-between items-center gap-2"><h2>🏭 กราฟ Production — <?=$monthName?> <?=$year?></h2><div class="flex gap-1 no-print"><button class="border rounded px-2 py-1 text-xs font-bold" onclick="copyChart('prod','Production')">📋 คัดลอกรูป</button><button class="border rounded px-2 py-1 text-xs font-bold" onclick="downloadChart('prod','Production')">⬇ PNG</button></div></div><div class="v14-chart"><canvas id="prod"></canvas></div></div>
 <div class="v14-card"><div class="flex justify-between items-center gap-2"><h2>🏢 กราฟ Office — <?=$monthName?> <?=$year?></h2><div class="flex gap-1 no-print"><button class="border rounded px-2 py-1 text-xs font-bold" onclick="copyChart('office','Office')">📋 คัดลอกรูป</button><button class="border rounded px-2 py-1 text-xs font-bold" onclick="downloadChart('office','Office')">⬇ PNG</button></div></div><div class="v14-chart"><canvas id="office"></canvas></div></div>
</div>
<div class="v14-grid3">
 <div class="v14-card"><h2>📈 แนวโน้มคะแนนเฉลี่ยรายเดือน — <?=$department?> <?=$year?></h2><div class="v14-chart"><canvas id="trend"></canvas></div></div>
 <div class="v14-card"><h2>🏷 TAG 5 ส.</h2><div class="v14-chart"><canvas id="tag"></canvas></div></div>
 <div class="v14-card"><h2>🏆 คะแนนสูงสุด</h2><table class="v14-table"><thead><tr><th>อันดับ</th><th>พื้นที่</th><th>คะแนน</th></tr></thead><tbody><?php foreach(array_slice($deptData,0,5) as $i=>$r):?><tr><td><?=$i+1?></td><td><?=h($r['group_name'])?></td><td><b><?=number_format($r['avg'],2)?>%</b></td></tr><?php endforeach;?></tbody></table></div>
</div>
</div>
<script>
const PROD_TARGET=<?=json_encode($prodTarget)?>, OFFICE_TARGET=<?=json_encode($officeTarget)?>; const chartRefs={};
const prod=<?=json_encode($prod['rows'],JSON_UNESCAPED_UNICODE)?>,off=<?=json_encode($off['rows'],JSON_UNESCAPED_UNICODE)?>,trend=<?=json_encode($trend)?>;
function makeBar(id,rows,target){
  const canvas=document.getElementById(id);
  const wrap=canvas.parentElement;
  // Make each dashboard graph large enough to show every unit clearly.
  const dynamicHeight=Math.max(520, Math.min(1500, rows.length*30+150));
  wrap.style.height=dynamicHeight+'px';
  const labels=rows.map(x=>x.group_name);
  const values=rows.map(x=>Number(x.avg));
  const colors=rows.map(x=>Number(x.avg)>=Number(target)?'rgba(22,163,74,.88)':'rgba(220,38,38,.88)');
  const borders=rows.map(x=>Number(x.avg)>=Number(target)?'#16a34a':'#dc2626');
  chartRefs[id]=new Chart(canvas,{
    type:'bar',
    data:{
      labels:labels,
      datasets:[
        {label:'คะแนนเฉลี่ย %',data:values,backgroundColor:colors,borderColor:borders,borderWidth:1,borderRadius:7,barThickness:20,maxBarThickness:24},
        {label:'เป้าหมาย '+target+'%',type:'line',data:rows.map(()=>target),borderColor:'#ef4444',borderDash:[7,5],borderWidth:3,pointRadius:0}
      ]
    },
    options:{
      indexAxis:'y',
      responsive:true,
      maintainAspectRatio:false,
      layout:{padding:{left:4,right:85,top:8,bottom:8}},
      scales:{
        x:{min:0,max:100,grid:{color:'rgba(148,163,184,.22)'},ticks:{font:{size:13,weight:'800'},callback:v=>v+'%'},title:{display:true,text:'คะแนน (%)',font:{size:14,weight:'900'}}},
        y:{grid:{display:false},ticks:{font:{size:13,weight:'800',family:'Tahoma'},color:'#334155',padding:8,autoSkip:false,callback:function(value){
          const label=this.getLabelForValue(value);
          if(String(label).includes(' / ')) return String(label).split(' / ');
          return label;
        }},afterFit:axis=>{axis.width=300;}}
      },
      plugins:{
        legend:{position:'top',labels:{font:{size:13,weight:'900'},usePointStyle:true,boxWidth:14}},
        tooltip:{callbacks:{
          title:function(items){return items.length?items[0].label:'';},
          label:function(ctx){
            if(ctx.datasetIndex===1) return ' เป้าหมาย '+Number(target).toFixed(1)+'%';
            return ' คะแนนเฉลี่ย '+Number(ctx.parsed.x).toFixed(2)+'%';
          }
        }}
      }
    },
    plugins:[{
      id:'labels_'+id,
      afterDatasetsDraw(ch){
        const ctx=ch.ctx,meta=ch.getDatasetMeta(0),d=ch.data.datasets[0];
        ctx.save();ctx.fillStyle='#172238';ctx.font='900 13px Tahoma';ctx.textAlign='left';ctx.textBaseline='middle';
        meta.data.forEach((b,i)=>ctx.fillText(Number(d.data[i]).toFixed(2)+'%',Math.min(b.x+10,ch.chartArea.right-66),b.y));
        ctx.restore();
      }
    }]
  });
}
makeBar('prod',prod,PROD_TARGET);makeBar('office',off,OFFICE_TARGET);
function canvasWithHeading(source,title,subtitle=''){
  if(!source || !source.width || !source.height) throw new Error('ไม่พบภาพกราฟ');
  const out=document.createElement('canvas');
  const w=source.width, pad=Math.max(18,Math.round(w*0.024));
  const titleSize=Math.max(19,Math.min(34,Math.round(w/34)));
  const subSize=Math.max(12,Math.min(21,Math.round(w/58)));
  const measure=document.createElement('canvas').getContext('2d');
  const maxW=w-pad*2;
  const wrap=(text,font)=>{
    measure.font=font; const lines=[]; let line='';
    String(text||'').split(/\s+/).forEach(word=>{
      const candidate=line?line+' '+word:word;
      if(line && measure.measureText(candidate).width>maxW){lines.push(line);line=word;}else{line=candidate;}
    });
    if(line)lines.push(line); return lines;
  };
  const titleLines=wrap(title,'900 '+titleSize+'px Tahoma, Arial, sans-serif');
  const subLines=subtitle?wrap(subtitle,'600 '+subSize+'px Tahoma, Arial, sans-serif'):[];
  const titleLineH=Math.round(titleSize*1.25), subLineH=Math.round(subSize*1.35);
  const headH=Math.max(82,18+titleLines.length*titleLineH+(subLines.length?8+subLines.length*subLineH:0)+20);
  out.width=w;out.height=source.height+headH;
  const ctx=out.getContext('2d');
  ctx.fillStyle='#ffffff';ctx.fillRect(0,0,out.width,out.height);
  ctx.fillStyle='#ff5a00';ctx.fillRect(0,0,out.width,9);
  ctx.fillStyle='#13213a';ctx.textBaseline='top';ctx.font='900 '+titleSize+'px Tahoma, Arial, sans-serif';
  let y=17;titleLines.forEach(line=>{ctx.fillText(line,pad,y,maxW);y+=titleLineH;});
  if(subLines.length){y+=4;ctx.fillStyle='#64748b';ctx.font='600 '+subSize+'px Tahoma, Arial, sans-serif';subLines.forEach(line=>{ctx.fillText(line,pad,y,maxW);y+=subLineH;});}
  ctx.strokeStyle='#dbe3ee';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(pad,headH-4);ctx.lineTo(w-pad,headH-4);ctx.stroke();
  ctx.drawImage(source,0,headH);
  return out;
}

function chartImageWithHeading(id,name){
  const chart=chartRefs[id];if(!chart||!chart.canvas)throw new Error('ไม่พบกราฟ '+name);
  const card=chart.canvas.closest('.v14-card');const heading=card?card.querySelector('h2'):null;
  const title=heading?heading.textContent.trim():('กราฟ '+name+' — <?=h($monthName)?> <?=$year?>');
  return canvasWithHeading(chart.canvas,title,'5S SMART | ALUMET • คะแนนเฉลี่ยและเป้าหมาย '+(name==='Office'?OFFICE_TARGET:PROD_TARGET)+'%');
}
function downloadChart(id,name){try{const image=chartImageWithHeading(id,name),a=document.createElement('a');a.href=image.toDataURL('image/png',1);a.download='5S_'+name+'_<?=h($monthName)?>_<?=$year?>_พร้อมหัวข้อ.png';document.body.appendChild(a);a.click();a.remove();}catch(e){alert('ไม่สามารถบันทึกกราฟพร้อมหัวข้อได้: '+e.message);}}
async function copyChart(id,name){try{const image=chartImageWithHeading(id,name);const blob=await new Promise((resolve,reject)=>image.toBlob(b=>b?resolve(b):reject(new Error('สร้างไฟล์ภาพไม่สำเร็จ')),'image/png'));await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);alert('คัดลอกรูปกราฟ '+name+' พร้อมหัวข้อแล้ว สามารถกด Ctrl+V ใน LINE ได้');}catch(e){downloadChart(id,name);alert('ไม่สามารถคัดลอกภาพได้ ระบบดาวน์โหลด PNG พร้อมหัวข้อให้แทนครับ');}}

const trendLabels=<?=json_encode(array_values($months),JSON_UNESCAPED_UNICODE)?>;
const trendTarget=(<?=json_encode($department)?>==='Office'?OFFICE_TARGET:PROD_TARGET);
const trendHasData=trend.filter(v=>v!==null).length;
new Chart(document.getElementById('trend'),{type:'line',data:{labels:trendLabels,datasets:[{label:'คะแนนเฉลี่ย %',data:trend,borderColor:'#16a34a',backgroundColor:'rgba(22,163,74,.12)',fill:true,tension:.25,spanGaps:false,pointRadius:trend.map(v=>v===null?0:5),pointHoverRadius:7,pointBackgroundColor:trend.map(v=>v===null?'transparent':'#16a34a'),pointBorderColor:trend.map(v=>v===null?'transparent':'#166534')},{label:'เป้าหมาย '+trendTarget+'%',data:Array(12).fill(trendTarget),borderColor:'#ef4444',borderDash:[6,4],pointRadius:0}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},scales:{y:{min:0,max:100,ticks:{callback:v=>v+'%'}}},plugins:{title:{display:true,text:'มีข้อมูล '+trendHasData+' เดือน จาก 12 เดือน',font:{size:11,weight:'700'},color:'#64748b',padding:{bottom:4}},tooltip:{callbacks:{label:function(ctx){return ctx.datasetIndex===1?' เป้าหมาย '+trendTarget.toFixed(1)+'%':(ctx.parsed.y===null?' ไม่มีข้อมูล':' คะแนนเฉลี่ย '+Number(ctx.parsed.y).toFixed(2)+'%');}}}}},plugins:[{id:'trendValueLabels',afterDatasetsDraw:function(chart){const ctx=chart.ctx,meta=chart.getDatasetMeta(0),data=chart.data.datasets[0].data;ctx.save();ctx.font='700 10px Tahoma';ctx.fillStyle='#166534';ctx.textAlign='center';meta.data.forEach((pt,i)=>{const v=data[i];if(v!==null){ctx.fillText(Number(v).toFixed(1)+'%',pt.x,pt.y-10);}});ctx.restore();}}]});
new Chart(document.getElementById('tag'),{type:'bar',data:{labels:['ปิดจบ','ยังไม่ปิด'],datasets:[{label:'จำนวน Tag',data:[<?=json_encode($tagClosed)?>,<?=json_encode($tagOpen)?>],backgroundColor:['#16a34a','#ef4444'],borderRadius:6,maxBarThickness:90}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:(ctx)=>' '+ctx.label+': '+Number(ctx.raw).toLocaleString('th-TH')+' รายการ'}}},scales:{y:{beginAtZero:true,ticks:{precision:0}},x:{grid:{display:false}}}},plugins:[{id:'tagCountLabels',afterDatasetsDraw(chart){const ctx=chart.ctx;ctx.save();ctx.font='bold 13px Tahoma';ctx.fillStyle='#172238';ctx.textAlign='center';ctx.textBaseline='bottom';chart.getDatasetMeta(0).data.forEach((bar,i)=>{ctx.fillText(Number(chart.data.datasets[0].data[i]).toLocaleString('th-TH'),bar.x,bar.y-7);});ctx.restore();}}]});
</script>
<?php require 'includes/footer.php';?>
