<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
$title='ผู้ตรวจ / ประวัติการตรวจ 12 เดือน';
$p=db();
$year=(int)($_GET['year']??(date('Y')+543)); if($year<2500||$year>2700)$year=date('Y')+543;
$team=(string)($_GET['team']??'A'); if(!in_array($team,['A','B','ALL'],true))$team='A';
$months=['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];

/* V37: 1 เดือน = 4 รอบตรวจ. เก็บแยกรอบ 1-4 เพื่อไม่ทำลายข้อมูลเดิม */
$p->exec("CREATE TABLE IF NOT EXISTS auditor_12month_rounds(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 history_year INTEGER NOT NULL,
 history_month INTEGER NOT NULL,
 team TEXT NOT NULL,
 auditor_name TEXT NOT NULL,
 round_no INTEGER NOT NULL,
 checked INTEGER NOT NULL DEFAULT 0,
 inspection_date TEXT NOT NULL DEFAULT '',
 department TEXT NOT NULL DEFAULT '',
 updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(history_year,history_month,team,auditor_name,round_no)
)");

function back12(int $y,string $t,string $m='saved'):never{header('Location: auditor_12month.php?year='.$y.'&team='.urlencode($t).'&msg='.urlencode($m));exit;}
$msg='';$err='';
try{
  // Migrate old V36 monthly counts into round 1-4 once, for continuity.
  $p->exec("CREATE TABLE IF NOT EXISTS auditor_12month_migrated(flag INTEGER PRIMARY KEY CHECK(flag=1))");
  $has=$p->query("SELECT 1 FROM auditor_12month_migrated WHERE flag=1 LIMIT 1")->fetchColumn();
  if(!$has){
    $old=$p->query("SELECT history_year,history_month,team,auditor_name,inspection_count,inspection_dates,departments FROM auditor_monthly_history");
    $ins=$p->prepare("INSERT OR IGNORE INTO auditor_12month_rounds(history_year,history_month,team,auditor_name,round_no,checked,inspection_date,department) VALUES(?,?,?,?,?,?,?,?)");
    foreach($old as $r){$cnt=max(0,min(4,(int)$r['inspection_count']));$dates=array_values(array_filter(array_map('trim',explode(',',$r['inspection_dates']??''))));$deps=array_values(array_filter(array_map('trim',explode(',',$r['departments']??''))));for($i=1;$i<=4;$i++)$ins->execute([(int)$r['history_year'],(int)$r['history_month'],$r['team'],$r['auditor_name'],$i,$i<=$cnt?1:0,$dates[$i-1]??'',$deps[$i-1]??'']);}
    $p->exec("INSERT INTO auditor_12month_migrated(flag) VALUES(1)");
  }
}catch(Throwable $e){$err=$e->getMessage();}

/**
 * V38: ชื่อผู้ตรวจใช้ audit_plans (แผนตรวจ 5 ส.) เป็น Master เท่านั้น
 * ไม่สร้างชื่อใหม่จากหน้านี้ และไม่แก้ชื่อจากประวัติแยกอีกต่อไป
 * 1 เดือน = 4 รอบ โดยเรียงจากวันที่ตรวจจริงในแผนตรวจ (R1-R4)
 */
function syncAuditorsFromSchedule(PDO $p, int $y, string $t): void {
    if (!in_array($t, ['A','B'], true)) return;
    $sql = "SELECT id,month,TRIM(auditor_name) auditor_name,TRIM(inspection_date) inspection_date,TRIM(department) department
            FROM audit_plans
            WHERE active=1 AND year=? AND team=? AND TRIM(auditor_name)<>'' AND month BETWEEN 1 AND 12
            ORDER BY month, id";
    $q=$p->prepare($sql); $q->execute([$y,$t]);
    $by=[];
    foreach($q as $r){
        $m=(int)$r['month']; $name=trim((string)$r['auditor_name']);
        if($name==='') continue;
        $key=$m.'|'.$name;
        if(!isset($by[$key])) $by[$key]=[];
        $date=trim((string)$r['inspection_date']);
        // 1 วันตรวจ = 1 รอบ; หลายแผนกในวันเดียวกันไม่ให้นับซ้ำ
        $found=false;
        foreach($by[$key] as $x) if($x['date']===$date){
            if($x['department']==='' && trim((string)$r['department'])!=='') $x['department']=trim((string)$r['department']);
            $found=true; break;
        }
        if(!$found && count($by[$key])<4) $by[$key][]=['date'=>$date,'department'=>trim((string)$r['department'])];
    }
    $ensure=$p->prepare("INSERT OR IGNORE INTO auditor_12month_rounds(history_year,history_month,team,auditor_name,round_no,checked,inspection_date,department) VALUES(?,?,?,?,?,0,'','')");
    $up=$p->prepare("UPDATE auditor_12month_rounds SET inspection_date=?,department=?,updated_at=CURRENT_TIMESTAMP WHERE history_year=? AND history_month=? AND team=? AND auditor_name=? AND round_no=?");
    foreach($by as $key=>$rounds){
        [$mm,$name]=explode('|',$key,2); $mm=(int)$mm;
        for($r=1;$r<=4;$r++){
            $ensure->execute([$y,$mm,$t,$name,$r]);
            $row=$rounds[$r-1]??['date'=>'','department'=>''];
            $up->execute([$row['date'],$row['department'],$y,$mm,$t,$name,$r]);
        }
    }
}

if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $a=(string)($_POST['action']??'');$y=(int)($_POST['year']??$year);$t=(string)($_POST['team']??$team);
  if(!in_array($t,['A','B','ALL'],true))$t='A';
  if($a==='sync'){
    if($t==='ALL') { syncAuditorsFromSchedule($p,$y,'A'); syncAuditorsFromSchedule($p,$y,'B'); }
    else syncAuditorsFromSchedule($p,$y,$t);
    back12($y,$t,'sync');
  }
  if($a==='toggle'){
    if($t==='ALL')throw new Exception('เลือกทีม A หรือ B ก่อนแก้ไข');
    $n=trim((string)($_POST['name']??''));$m=(int)($_POST['month']??0);$r=(int)($_POST['round']??0);$c=(int)($_POST['status']??($_POST['checked']??0)); if(!in_array($c,[0,1,2],true))$c=0;
    if($n===''||$m<1||$m>12||$r<1||$r>4)throw new Exception('ข้อมูลรอบตรวจไม่ถูกต้อง');
    // อนุญาตให้ติ๊กเฉพาะชื่อที่มีอยู่ในแผนตรวจ 5 ส. เท่านั้น
    $chk=$p->prepare("SELECT 1 FROM audit_plans WHERE active=1 AND year=? AND team=? AND TRIM(auditor_name)=? LIMIT 1");$chk->execute([$y,$t,$n]);
    if(!$chk->fetchColumn()) throw new Exception('ไม่พบชื่อผู้ตรวจในแผนตรวจ 5 ส.');
    $q=$p->prepare("INSERT INTO auditor_12month_rounds(history_year,history_month,team,auditor_name,round_no,checked,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(history_year,history_month,team,auditor_name,round_no) DO UPDATE SET checked=excluded.checked,updated_at=CURRENT_TIMESTAMP");$q->execute([$y,$m,$t,$n,$r,$c]);
    // AJAX: บันทึกโดยไม่ reload/ไม่เด้งกลับบนสุดของหน้า
    $isAjax = (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest') || (($_POST['ajax'] ?? '') === '1');
    if($isAjax){
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok'=>true,'status'=>$c,'year'=>$y,'team'=>$t,'name'=>$n,'month'=>$m,'round'=>$r],JSON_UNESCAPED_UNICODE);
      exit;
    }
    back12($y,$t);
  }
 }catch(Throwable $e){$err=$e->getMessage();}
}

// โหลดชื่อจากแผนตรวจ 5 ส. โดยตรง และสร้าง/อัปเดตรอบ R1-R4 ให้อัตโนมัติ
if($team==='ALL'){ syncAuditorsFromSchedule($p,$year,'A'); syncAuditorsFromSchedule($p,$year,'B'); }
else { syncAuditorsFromSchedule($p,$year,$team); }

$names=[];
// Master รายชื่อ = แผนตรวจ 5 ส. เท่านั้น
$q=$p->prepare($team==='ALL'
    ? "SELECT DISTINCT TRIM(auditor_name) n FROM audit_plans WHERE active=1 AND year=? AND TRIM(auditor_name)<>'' ORDER BY n"
    : "SELECT DISTINCT TRIM(auditor_name) n FROM audit_plans WHERE active=1 AND year=? AND team=? AND TRIM(auditor_name)<>'' ORDER BY n");
$team==='ALL' ? $q->execute([$year]) : $q->execute([$year,$team]);
$names=$q->fetchAll(PDO::FETCH_COLUMN);
$names=array_values(array_unique(array_map('trim',$names))); sort($names,SORT_NATURAL|SORT_FLAG_CASE);
$matrix=[];$details=[];
$sql="SELECT auditor_name,history_month,round_no,checked,inspection_date,department FROM auditor_12month_rounds WHERE history_year=?";$args=[$year];if($team!=='ALL'){$sql.=' AND team=?';$args[]=$team;}$sql.=' ORDER BY auditor_name,history_month,round_no';$q=$p->prepare($sql);$q->execute($args);
foreach($q as $r){$n=$r['auditor_name'];$m=(int)$r['history_month'];$rr=(int)$r['round_no'];$matrix[$n][$m][$rr]=(int)$r['checked'];$details[$n][$m][$rr]=[$r['inspection_date'],$r['department']];}
$totals=[];$mt=array_fill(1,12,0);$roundMt=array_fill(1,12,0);foreach($names as $n){$s=0;for($m=1;$m<=12;$m++){for($r=1;$r<=4;$r++){$c=$matrix[$n][$m][$r]??0;if($c===1){$s++;$mt[$m]++;}}}$totals[$n]=$s;}arsort($totals);$grand=array_sum($mt);$maxTotal=max(48,count($names)*48);
require __DIR__.'/includes/header.php';
?>
<style>
.a12hero{background:linear-gradient(110deg,#ff5a00,#ff8a00);color:#fff;border-radius:18px;padding:20px 24px;margin-bottom:16px}.a12hero h1{margin:0;font-size:28px;font-weight:900}.a12bar{background:#fff;border:1px solid #dbe3ef;border-radius:15px;padding:12px;display:flex;gap:9px;align-items:end;flex-wrap:wrap;margin-bottom:14px}.a12bar label{font-size:12px;font-weight:900;color:#475569}.a12bar select,.a12bar input,.a12bar button{margin-left:5px;border:1px solid #cbd5e1;border-radius:9px;padding:8px 11px;font-weight:800}.a12bar button{cursor:pointer;background:#173b70;color:#fff}.a12green{background:#16a34a!important}.a12blue{background:#1677e8!important}.a12red{background:#ef4444!important}.a12wrap{background:#fff;border:1px solid #dbe3ef;border-radius:16px;overflow:auto}.a12table{border-collapse:separate;border-spacing:0;width:100%;min-width:1500px}.a12table th,.a12table td{padding:7px;border-right:1px solid #dbe3ef;border-bottom:1px solid #dbe3ef;text-align:center}.a12table th{background:#172238;color:#fff;position:sticky;top:0;z-index:3}.a12table th.mon{background:#ff6b00}.a12table .name{position:sticky;left:0;z-index:2;background:#fff;text-align:left;min-width:250px;color:#173b70;font-weight:900}.a12table th.name{background:#172238;z-index:4}.monthcell{min-width:130px;height:58px;background:#f8fafc}.monthcell.has{background:#dcfce7}.monthcell.absent{background:#fee2e2}.rounds{display:flex;justify-content:center;gap:5px}.roundbox{display:flex;flex-direction:column;align-items:center;gap:2px}.roundbox small{font-size:9px;font-weight:900;color:#64748b}.roundbox input{width:18px;height:18px;accent-color:#16a34a;cursor:pointer}.roundbox input:checked{filter:saturate(1.3)}.roundform{margin:0;padding:0;display:block;line-height:1}.roundbtn{appearance:none;-webkit-appearance:none;cursor:pointer;pointer-events:auto}.roundbtn:disabled{opacity:.6}.roundbtn{width:20px;height:20px;border:1px solid #94a3b8;border-radius:4px;background:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:900;cursor:pointer;padding:0}.roundbtn.ok{background:#16a34a;color:#fff;border-color:#16a34a}.roundbtn.no{background:#ef4444;color:#fff;border-color:#ef4444}.tools{margin-top:4px;display:flex;gap:4px}.mini{border:0;border-radius:6px;padding:3px 6px;color:#fff;font-size:10px;font-weight:900;cursor:pointer}.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:14px 0}.kpi{background:#fff;border:1px solid #dbe3ef;border-radius:15px;padding:14px}.kpi b{font-size:25px;color:#173b70}.charts{display:grid;grid-template-columns:1.3fr 1fr;gap:14px;margin-top:14px}.chartbox{background:#fff;border:1px solid #dbe3ef;border-radius:15px;padding:14px;height:390px}.chartbox h3{margin:0 0 8px;color:#173b70}.chartarea{height:330px}.hint{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;border-radius:10px;padding:10px;margin-bottom:12px;font-weight:800}@media(max-width:900px){.charts{grid-template-columns:1fr}.kpis{grid-template-columns:1fr 1fr}}@media(max-width:600px){.kpis{grid-template-columns:1fr}.a12hero h1{font-size:22px}}

@media print{
  @page{size:A4 landscape;margin:6mm}
  body{background:#fff!important}
  .no-print,.sidebar,.topbar,.a12bar,.hint,.charts,.footer{display:none!important}
  .main{margin:0!important;padding:0!important}
  .a12hero{display:block!important;background:#fff!important;color:#111!important;border:2px solid #ff5a00!important;border-radius:0!important;padding:8px 10px!important;margin:0 0 5px!important}
  .a12hero h1{font-size:16px!important;color:#173b70!important}
  .a12hero div{font-size:8px!important;color:#475569!important}
  .kpis{display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:4px!important;margin:0 0 5px!important}
  .kpi{padding:4px!important;border:1px solid #cbd5e1!important;border-radius:4px!important;font-size:8px!important;box-shadow:none!important}
  .kpi b{font-size:11px!important}
  .a12wrap{overflow:visible!important;border:1px solid #94a3b8!important;border-radius:0!important}
  .a12table{min-width:0!important;width:100%!important;table-layout:fixed!important;font-size:6.5px!important}
  .a12table th,.a12table td{padding:2px 1px!important;border-right:1px solid #b8c4d2!important;border-bottom:1px solid #b8c4d2!important}
  .a12table th{position:static!important;font-size:6.5px!important}
  .a12table .name{position:static!important;min-width:0!important;width:18%!important;font-size:7px!important}
  .monthcell{min-width:0!important;height:30px!important}
  .rounds{gap:1px!important}
  .roundbox{gap:0!important}
  .roundbox small{font-size:4.5px!important}
  .roundbtn{width:9px!important;height:9px!important;font-size:7px!important;border-radius:2px!important}
  .a12table tfoot{display:table-row-group!important}
}
.line-export-host{position:absolute!important;left:-20000px!important;top:0!important;width:1600px!important;background:#fff!important;z-index:999999!important;visibility:visible!important;opacity:1!important}
</style>
<div class="a12hero"><h1>👥 ผู้ตรวจ / ประวัติการตรวจ 12 เดือน</h1><div>1 เดือนมีได้ <b>4 รอบตรวจ</b> • รวมสูงสุด 48 ครั้ง/คน/ปี • เทียบรายชื่อคน • ทีม A / ทีม B • รายชื่อดึงจากแผนตรวจ 5 ส. โดยตรง</div></div>
<form class="a12bar" method="get"><label>ปี <select name="year"><?php for($yy=$year-2;$yy<=$year+2;$yy++):?><option <?=$yy==$year?'selected':''?>><?=$yy?></option><?php endfor;?></select></label><label>ทีม <select name="team"><option value="A" <?=$team==='A'?'selected':''?>>ทีม A</option><option value="B" <?=$team==='B'?'selected':''?>>ทีม B</option><option value="ALL" <?=$team==='ALL'?'selected':''?>>ทุกทีม</option></select></label><button>🔎 แสดง</button></form>
<div class="hint">กดช่องรอบตรวจเพื่อเปลี่ยนสถานะ <b>□ ว่าง → ✓ มาตรวจ → ✗ ไม่มา → □ ว่าง</b> • ทุกครั้งที่กดจะบันทึกทันที • แต่ละเดือนมี 4 รอบ</div>
<?php if(isset($_GET['msg'])):?><div style="background:#ecfdf5;color:#166534;padding:10px;border-radius:9px;font-weight:900;margin-bottom:10px">✓ ดำเนินการเรียบร้อย</div><?php endif;?><?php if($err):?><div style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:9px;font-weight:900;margin-bottom:10px">⚠ <?=h($err)?></div><?php endif;?>
<div class="a12bar"><form method="post"><input type="hidden" name="action" value="sync"><input type="hidden" name="year" value="<?=$year?>"><input type="hidden" name="team" value="<?=$team?>"><button class="a12green">🔄 อัปเดตจากแผนตรวจ 5 ส.</button></form><div style="font-weight:800;color:#475569;padding:8px 4px">รายชื่อเป็นข้อมูลจากแผนตรวจ 5 ส. โดยตรง • เพิ่ม/แก้/ลบชื่อที่หน้าแผนตรวจ 5 ส.</div></div>
<div class="a12bar no-print" style="justify-content:flex-end">
  <button type="button" class="a12blue" onclick="printA12()">🖨️ พิมพ์ A4</button>
  <button type="button" class="a12green" onclick="copyA12Image()">🖼️ คัดลอกรูปส่ง LINE</button>
</div>
<div class="kpis"><div class="kpi">ผู้ตรวจ <b><?=count($names)?> คน</b></div><div class="kpi">ตรวจรวม <b><?=$grand?> ครั้ง</b></div><div class="kpi">เต็มระบบ <b><?=count($names)*48?> ครั้ง</b></div><div class="kpi">อัตราการตรวจ <b><?=count($names)?round($grand/(count($names)*48)*100,1):0?>%</b></div></div>
<div class="a12wrap"><table class="a12table"><thead><tr><th>ลำดับ</th><th class="name">ชื่อผู้ตรวจ</th><?php foreach($months as $m):?><th class="mon" colspan="1"><?=$m?><br><small>4 รอบ</small></th><?php endforeach;?><th>รวม</th><th>%</th></tr></thead><tbody>
<?php $i=0;foreach($names as $n):$i++;$total=$totals[$n]??0;$pct=round($total/48*100,1);?><tr data-auditor-row="<?=h($n)?>"><td><?=$i?></td><td class="name"><div><?=h($n)?></div><small style="color:#64748b;font-weight:700">จากแผนตรวจ 5 ส.</small></td><?php for($m=1;$m<=12;$m++):$cnt=0;$abs=0;for($r=1;$r<=4;$r++){if(($matrix[$n][$m][$r]??0)===1)$cnt++;if(($matrix[$n][$m][$r]??0)===2)$abs++;}?><td class="monthcell <?=$cnt?'has ':''?><?=$abs?'absent':''?>" data-month="<?=$m?>" data-name="<?=h($n)?>"><div class="rounds"><?php for($r=1;$r<=4;$r++):$c=$matrix[$n][$m][$r]??0;?><label class="roundbox" title="<?=$months[$m-1]?> รอบ <?=$r?><?php if(isset($details[$n][$m][$r])):?> <?=$details[$n][$m][$r][0]?> <?=$details[$n][$m][$r][1]?><?php endif;?>"><small>R<?=$r?></small><?php if($team!=='ALL'):?>
<button type="button" class="roundbtn <?=$c===1?'ok':($c===2?'no':'')?>" data-status="<?=$c?>" data-year="<?=$year?>" data-team="<?=h($team)?>" data-name="<?=h($n)?>" data-month="<?=$m?>" data-round="<?=$r?>" title="<?=$c===1?'มาตรวจแล้ว — คลิกเพื่อเป็นไม่มา':($c===2?'ไม่มา — คลิกเพื่อเคลียร์':'ยังไม่ระบุ — คลิกเพื่อบันทึกว่ามาตรวจ')?>"><?=$c===1?'✓':($c===2?'✗':'' )?></button>
<?php else:?><?=$c===1?'✓':($c===2?'✗':'□')?><?php endif;?></label><?php endfor;?></div></td><?php endfor;?><td><b><?=$total?></b></td><td><b><?=$pct?>%</b></td></tr><?php endforeach;?>
<?php if(!$names):?><tr><td colspan="16" style="padding:25px">ยังไม่มีรายชื่อในแผนตรวจ 5 ส. ของปี/ทีมที่เลือก</td></tr><?php endif;?></tbody><tfoot><tr style="background:#fff7ed;font-weight:900"><td colspan="2" style="text-align:right">รวมรายเดือน</td><?php foreach($mt as $v):?><td><?=$v?></td><?php endforeach;?><td><?=$grand?></td><td>—</td></tr></tfoot></table></div>
<div class="charts"><div class="chartbox"><h3>📊 เปรียบเทียบจำนวนครั้ง — รายชื่อคน</h3><div class="chartarea"><canvas id="pc"></canvas></div></div><div class="chartbox"><h3>📅 จำนวนการตรวจรายเดือน (4 รอบ/เดือน)</h3><div class="chartarea"><canvas id="mc"></canvas></div></div></div>
<script>
const pcChart=new Chart(document.getElementById('pc'),{type:'bar',data:{labels:<?=json_encode(array_keys($totals),JSON_UNESCAPED_UNICODE)?>,datasets:[{label:'ครั้งจาก 48',data:<?=json_encode(array_values($totals))?>}]},options:{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{beginAtZero:true,max:48,ticks:{precision:0}}}}});
const mcChart=new Chart(document.getElementById('mc'),{type:'bar',data:{labels:<?=json_encode($months,JSON_UNESCAPED_UNICODE)?>,datasets:[{label:'ครั้ง',data:<?=json_encode(array_values($mt))?>}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});

// บันทึกสถานะด้วย AJAX: ไม่ reload หน้า ไม่เด้งขึ้นบนสุด และยังเซฟลงฐานข้อมูลจริง
function refreshTotals(){
  const rows=[...document.querySelectorAll('tr[data-auditor-row]')];
  const monthTotals=Array(12).fill(0); let grand=0;
  rows.forEach(row=>{
    let total=0;
    row.querySelectorAll('.monthcell').forEach(cell=>{
      const vals=[...cell.querySelectorAll('.roundbtn')].map(b=>Number(b.dataset.status||0));
      const yes=vals.filter(v=>v===1).length;
      const no=vals.filter(v=>v===2).length;
      total+=yes;
      const mi=Number(cell.dataset.month)-1;
      monthTotals[mi]+=yes;
      cell.classList.toggle('has',yes>0);
      cell.classList.toggle('absent',yes===0 && no>0);
    });
    const totalCell=row.querySelector('td:nth-last-child(2) b');
    const pctCell=row.querySelector('td:last-child b');
    if(totalCell) totalCell.textContent=total;
    if(pctCell) pctCell.textContent=((total/48)*100).toFixed(1).replace('.0','')+'%';
    grand+=total;
  });
  document.querySelectorAll('.a12table tfoot td').forEach((td,i)=>{
    if(i>=2 && i<14) td.textContent=monthTotals[i-2];
  });
  const footCells=document.querySelectorAll('.a12table tfoot td');
  if(footCells.length>=2) footCells[footCells.length-2].textContent=grand;
  const kpis=document.querySelectorAll('.kpi b');
  if(kpis[1]) kpis[1].textContent=grand+' ครั้ง';
  if(kpis[3]) kpis[3].textContent=(rows.length?((grand/(rows.length*48))*100).toFixed(1):'0')+'%';
  pcChart.data.labels=rows.map(r=>r.dataset.auditorRow);
  pcChart.data.datasets[0].data=rows.map(r=>Number(r.querySelector('td:nth-last-child(2) b')?.textContent||0));
  pcChart.update('none');
  mcChart.data.datasets[0].data=monthTotals; mcChart.update('none');
}

document.querySelectorAll('.roundbtn').forEach(btn=>{
  btn.addEventListener('click', async (ev)=>{
    ev.preventDefault();
    if(btn.disabled) return;
    const current=Number(btn.dataset.status||0);
    const next=current===0?1:(current===1?2:0);
    const fd=new URLSearchParams();
    fd.set('action','toggle');
    fd.set('year',btn.dataset.year||'');
    fd.set('team',btn.dataset.team||'');
    fd.set('name',btn.dataset.name||'');
    fd.set('month',btn.dataset.month||'');
    fd.set('round',btn.dataset.round||'');
    fd.set('status',String(next));
    fd.set('ajax','1');
    const oldText=btn.textContent;
    btn.disabled=true;
    try{
      const res=await fetch('auditor_12month.php',{
        method:'POST',
        body:fd,
        headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json','Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        credentials:'same-origin',
        redirect:'error'
      });
      const raw=await res.text();
      let data;
      try{ data=JSON.parse(raw); }
      catch(parseErr){
        throw new Error('เซิร์ฟเวอร์ส่งข้อมูลไม่ใช่ JSON ('+res.status+')');
      }
      if(!data.ok) throw new Error(data.message||'บันทึกไม่สำเร็จ');
      const status=Number(data.status);
      btn.dataset.status=String(status);
      btn.classList.remove('ok','no');
      btn.textContent=status===1?'✓':(status===2?'✗':'');
      if(status===1) btn.classList.add('ok'); else if(status===2) btn.classList.add('no');
      refreshTotals();
    }catch(err){
      btn.textContent=oldText;
      alert('บันทึกไม่สำเร็จ: '+err.message);
    }finally{btn.disabled=false;}
  });
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
function printA12(){
  window.print();
}
async function copyA12Image(){
  const btn=document.querySelector('[onclick="copyA12Image()"]');
  const old=btn?btn.innerHTML:'';
  let clone=null;
  try{
    if(typeof html2canvas==='undefined') throw new Error('ยังโหลดตัวสร้างรูปไม่สำเร็จ');
    if(btn){btn.disabled=true;btn.innerHTML='⏳ กำลังสร้างรูป...';}
    const source=document.querySelector('.a12wrap');
    if(!source) throw new Error('ไม่พบตาราง 12 เดือน');
    clone=source.cloneNode(true);
    clone.className='a12wrap line-export-host';
    clone.style.width='1600px';
    clone.style.maxWidth='none';
    clone.style.overflow='visible';
    clone.style.border='0';
    clone.style.borderRadius='0';
    clone.querySelectorAll('.a12table').forEach(t=>{t.style.width='1600px';t.style.minWidth='1600px';});
    clone.querySelectorAll('.name').forEach(e=>{e.style.position='static';});
    clone.querySelectorAll('th,td').forEach(e=>{e.style.position='static';});
    document.body.appendChild(clone);
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    const canvas=await html2canvas(clone,{scale:2,backgroundColor:'#fff',useCORS:true,logging:false,windowWidth:1700,scrollX:0,scrollY:0});
    clone.remove();clone=null;
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png',1));
    if(!blob) throw new Error('สร้างรูปไม่สำเร็จ');
    if(navigator.clipboard && window.ClipboardItem){
      await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);
      alert('คัดลอกรูปเรียบร้อย ✓\nเปิด LINE แล้วกด Ctrl+V เพื่อส่งรูปได้เลย');
    }else{
      const a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download='ผู้ตรวจ-12เดือน-ทีม<?=$team?>-<?=$year?>.png';
      a.click();
      setTimeout(()=>URL.revokeObjectURL(a.href),1000);
      alert('เบราว์เซอร์ไม่รองรับการคัดลอกรูปโดยตรง จึงดาวน์โหลด PNG ให้แทนครับ');
    }
  }catch(e){
    if(clone) clone.remove();
    alert('คัดลอกรูปไม่สำเร็จ: '+e.message);
  }finally{
    if(btn){btn.disabled=false;btn.innerHTML=old;}
  }
}
</script>
<?php require __DIR__.'/includes/footer.php'; ?>
