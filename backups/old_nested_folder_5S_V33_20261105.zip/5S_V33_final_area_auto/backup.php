<?php
require_once 'config.php';
$action=$_GET['action']??'';
if($action==='download_db'){if(!is_file(DB_PATH)){http_response_code(404);exit('ไม่พบฐานข้อมูล');}$name='5S_SMART_backup_'.date('Ymd_His').'.sqlite';header('Content-Type: application/octet-stream');header('Content-Disposition: attachment; filename="'.$name.'"');header('Content-Length: '.filesize(DB_PATH));readfile(DB_PATH);exit;}
if($action==='json'){ $p=db();$tables=[];foreach($p->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'") as $t){$tn=$t['name'];$tables[$tn]=$p->query('SELECT * FROM "'.str_replace('"','""',$tn).'"')->fetchAll();} $data=['app'=>'5S SMART','created_at'=>date('c'),'tables'=>$tables];header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="5S_SMART_backup_'.date('Ymd_His').'.json"');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);exit;}
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_FILES['dbfile'])){if($_FILES['dbfile']['error']!==UPLOAD_ERR_OK){$msg='อัปโหลดไฟล์ไม่สำเร็จ';}else{$tmp=$_FILES['dbfile']['tmp_name'];try{$test=new PDO('sqlite:'.$tmp);$test->query('PRAGMA integrity_check')->fetchColumn();$has=$test->query("SELECT name FROM sqlite_master WHERE type='table' AND name='audits'")->fetchColumn();if(!$has)throw new Exception('ไฟล์ไม่ใช่ฐานข้อมูล 5S SMART');$backupDir=__DIR__.'/backups';if(!is_dir($backupDir))mkdir($backupDir,0775,true);copy(DB_PATH,$backupDir.'/before_restore_'.date('Ymd_His').'.sqlite');if(!copy($tmp,DB_PATH))throw new Exception('ไม่สามารถเขียนฐานข้อมูลได้');$msg='กู้คืนฐานข้อมูลเรียบร้อยแล้ว';}catch(Throwable $e){$msg='กู้คืนไม่สำเร็จ: '.$e->getMessage();}}}
$title='สำรอง / กู้คืนข้อมูล';require 'includes/header.php';
?>
<div class="hero"><div class="hero-copy"><h1>สำรอง<span>ข้อมูล 5 ส.</span></h1><p>Backup / Restore ฐานข้อมูล SQLite เพื่อป้องกันข้อมูลสูญหาย</p></div><div class="hero-right"><strong>BACKUP</strong><small>SQLite + JSON</small></div></div>
<?php if($msg):?><div class="card p-4 mb-5 bg-emerald-50 text-emerald-800 font-bold">✅ <?=h($msg)?></div><?php endif;?>
<div class="grid md:grid-cols-2 gap-5">
<div class="card p-6"><div class="section-title mb-3">💾 สำรองข้อมูล</div><p class="text-sm text-slate-600 mb-4">แนะนำให้สำรองก่อนนำเข้าข้อมูลหรือแก้ไขคะแนนจำนวนมาก</p><div class="flex flex-wrap gap-3"><a class="bg-blue-600 text-white px-5 py-3 rounded-xl font-bold" href="backup.php?action=download_db">⬇️ Backup SQLite</a><a class="bg-slate-800 text-white px-5 py-3 rounded-xl font-bold" href="backup.php?action=json">⬇️ Backup JSON</a></div></div>
<div class="card p-6"><div class="section-title mb-3">♻️ กู้คืนข้อมูล</div><p class="text-sm text-slate-600 mb-4">เลือกไฟล์ `.sqlite` ที่เคยสำรองไว้ ระบบจะสำรองฐานข้อมูลปัจจุบันก่อนกู้คืน</p><form method="post" enctype="multipart/form-data"><input type="file" name="dbfile" accept=".sqlite,.db" required class="w-full border rounded-xl p-3 mb-3"><button class="bg-orange-500 text-white px-5 py-3 rounded-xl font-bold">♻️ กู้คืนฐานข้อมูล</button></form></div>
</div>
<div class="card p-6 mt-5"><div class="section-title mb-3">📁 ไฟล์นำเข้าที่เก็บไว้</div><div class="text-sm text-slate-600">ไฟล์ต้นฉบับที่อัปโหลดจะถูกเก็บไว้ในโฟลเดอร์ <code>uploads/</code> เพื่อย้อนตรวจสอบภายหลัง</div></div>
<?php require 'includes/footer.php'; ?>
